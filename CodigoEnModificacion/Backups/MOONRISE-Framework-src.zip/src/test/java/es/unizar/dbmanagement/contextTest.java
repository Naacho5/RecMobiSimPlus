package es.unizar.dbmanagement;

import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class contextTest {
	@Test
	public void insertOneTest() throws SQLException {
		context table = new context(DBInformation.DB_MUSEUM_PATH);
		int numberOfContexts = 200;
		for (int c = 1; c <= numberOfContexts; c++) {
			table.insertOne(c);
		}
	}
}
