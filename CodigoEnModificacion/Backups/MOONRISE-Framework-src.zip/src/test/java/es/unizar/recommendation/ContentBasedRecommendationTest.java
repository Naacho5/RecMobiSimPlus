package es.unizar.recommendation;

import java.sql.SQLException;
import java.util.List;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.common.Weighting;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.junit.Assert;
import org.junit.Test;

import es.unizar.properties.DBInformation;
import es.unizar.recommendation.ContentBasedRecommendation;
import es.unizar.recommendation.CosineSimilarity;
import es.unizar.userprofileandcontextmanager.DBDataModel;

/**
 * Tests {@link ContentBasedRecommendationTest}.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class ContentBasedRecommendationTest {

	private static final String DB_PATH = DBInformation.DB_FILM_PATH;
	private static final long USER_ID = 15;
	private static final int HOW_MANY = 5;
	private static final int ITEM_ID = 1;// 11;//

	@Test // Demora mucho tiempo
	public void recommendTest() throws SQLException, TasteException {
		ContentBasedRecommendation recommender = buildRecommender();
		List<RecommendedItem> recommended = recommender.recommend(USER_ID, HOW_MANY);
		Assert.assertNotNull(recommended);
	}

	@Test
	public void estimatePreferenceTest() throws Exception {
		ContentBasedRecommendation recommender = buildRecommender();
		System.out.println("-------------- estimatePreference(long userID, long itemID) -------------------");
		float estimePreference = recommender.estimatePreference(USER_ID, ITEM_ID);
		Assert.assertNotEquals(0, estimePreference);
	}

	@Test
	public void mostSimilarItemsTest() throws Exception {
		ContentBasedRecommendation recommender = buildRecommender();
		List<RecommendedItem> similar = recommender.mostSimilarItems(ITEM_ID, HOW_MANY);
		Assert.assertNotNull(similar);
	}

	private static ContentBasedRecommendation buildRecommender() throws SQLException, TasteException {
		DBDataModel dataModel = new DBDataModel(DB_PATH);
		CosineSimilarity similarity = new CosineSimilarity(dataModel, Weighting.WEIGHTED, false);
		return new ContentBasedRecommendation(dataModel, similarity);
	}
}
