package es.unizar.dbmanagement;

import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class distanceTest {
	@Test
	public void insertOneTest() throws SQLException {
		distance table = new distance(DBInformation.DB_MUSEUM_PATH);
		table.insertOne(1, 1, 500);
		table.insertOne(1, 2, 700);
		table.insertOne(1, 3, 1000);
		table.insertOne(1, 4, 850);
		table.insertOne(2, 1, 2500);
		table.insertOne(2, 2, 2700);
		table.insertOne(2, 3, 3000);
		table.insertOne(2, 4, 2850);
		table.insertOne(3, 1, 1250);
		table.insertOne(3, 2, 1350);
		table.insertOne(3, 3, 1500);
		table.insertOne(3, 4, 1425);
	}
}
