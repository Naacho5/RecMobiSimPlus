package es.unizar.dbmanagement;

import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class featureTest {
	public static String[] NAMES = { "Title", "ArtistAndyWarhol", "ArtistEvaHesse", "ArtistJacksonPollock",
			"ArtistJasperJohns", "ArtistLeeBontecou", "ArtistRobertRauschenberg", "ArtistRoyLichtenstein",
			"ArtistClaudeMonet", "ArtistFridaKahlo", "ArtistHenriMatisse", "ArtistPabloPicasso", "ArtistPaulC�zanne",
			"ArtistSalvadorDal�", "ArtistVincentVanGogh", "ConstituentID", "ArtistBio", "NationalitySpanish",
			"NationalityFrench", "NationalityMexican", "NationalityAmerican", "NationalityDutch", "BeginDate",
			"EndDate", "Gender", "DateEarlyCenturyXIX", "DateMiddleCenturyXIX", "DateLaterCenturyXIX",
			"DateEarlyCenturyXX", "DateMiddleCenturyXX", "DateLaterCenturyXX", "DateEarlyCenturyXXI",
			"DateMiddleCenturyXXI", "DateLaterCenturyXXI", "MediumOil", "MediumEncaustic", "MediumSyntheticPolymer",
			"MediumTempera", "MediumMetal", "MediumCasein", "MediumSilk", "MediumGouache", "MediumSilkscreenInk",
			"MediumEnamel", "MediumFabric", "MediumVariousMaterials", "MediumFelt", "MediumSteel", "MediumBronze",
			"MediumWood", "MediumPlaster", "MediumGlazed", "Dimensions", "CreditLine", "AccessionNumber",
			"ClassificationPainting", "ClassificationSculpture", "Department", "DateAcquiredLittleTime",
			"DateAcquiredLongTime", "Cataloged", "Depth", "Diameter", "Height", "Weight", "Width", "Floor", "location",
			"room" };

	@Test
	public void insertOneTest() throws SQLException {
		feature table = new feature(DBInformation.DB_MUSEUM_PATH);
		for (int v = 0; v <= NAMES.length; v++) {
			table.insertOne(NAMES[v]);
		}
	}
}
