package es.unizar.recommendation;

import java.sql.SQLException;
import java.util.List;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.recommender.RandomRecommender;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.junit.Assert;
import org.junit.Test;

import es.unizar.properties.DBInformation;
import es.unizar.userprofileandcontextmanager.DBDataModel;

/**
 * Tests {@link RandomBasedRecommendationTest}.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class RandomBasedRecommendationTest {

	private static final String DB_PATH = DBInformation.DB_FILM_PATH;
	private static final long USER_ID = 15;
	private static final int HOW_MANY = 5;
	private static final int ITEM_ID = 11;

	@Test
	public void recommendTest() throws Exception {
		RandomRecommender recommender = buildRecommender();
		List<RecommendedItem> recommended = recommender.recommend(USER_ID, HOW_MANY);
		Assert.assertNotNull(recommended);
	}

	@Test
	public void estimatePreferenceTest() throws Exception {
		RandomRecommender recommender = buildRecommender();
		float estimePreference = recommender.estimatePreference(USER_ID, ITEM_ID);
		Assert.assertNotEquals(0, estimePreference);
	}

	private static RandomRecommender buildRecommender() throws SQLException, TasteException {
		DBDataModel dataModel = new DBDataModel(DB_PATH);
		return new RandomRecommender(dataModel);
	}
}
