package es.unizar.recommendation.contextaware.trajectory;

import java.io.File;

public class Literals {

	/**
	 * File paths
	 */
	public static final File file = new File("");
	public static final String PATH = file.getAbsolutePath() + File.separator + "src" + File.separator + "test"
			+ File.separator + "resources" + File.separator + "DB" + File.separator + "datasetMuseum" + File.separator;
	/**
	 * File names
	 */
	public static final String MAP = PATH + "map.txt";
	public static final String ROOM_FLOOR_4 = PATH + "room_floor4.txt";
	public static final String ROOM_FLOOR_5 = PATH + "room_floor5.txt";
	public static final String ITEM_FLOOR_4 = PATH + "item_floor4.txt";
	public static final String ITEM_FLOOR_5 = PATH + "item_floor5.txt";
	public static final String GRAPH_FLOOR_4 = PATH + "graph_floor4.txt";
	public static final String GRAPH_FLOOR_5 = PATH + "graph_floor5.txt";
	public static final String GRAPH_FLOOR_COMBINED = PATH + "graph_floor_combined.txt";
	/**
	 * Name: it is common
	 */
	public static final String NAME = "name";
	/**
	 * Map file
	 */
	public static final String NUMBER_FLOOR = "number_floor";
	public static final String FLOOR = "layout_floor_";
	public static final String FLOOR_COMBINED = "layout_combined";
	/**
	 * Item file
	 */
	public static final String NUMBER_ITEMS = "number_items";
	public static final String VERTEX_DIMENSION_HEIGHT = "vertex_dimension_height";
	public static final String VERTEX_DIMENSION_WIDTH = "vertex_dimension_width";
	public static final String ITEM_ID = "item_itemID_";
	public static final String ITEM_TITLE = "item_title_";
	public static final String ITEM_ARTIST = "item_artist_";
	public static final String ITEM_CONSTITUENTID = "item_constituentID_";
	public static final String ITEM_ARTISTBIO = "item_artistBio_";
	public static final String ITEM_NATIONALITY = "item_nationality_";
	public static final String ITEM_BEGINDATE = "item_beginDate_";
	public static final String ITEM_ENDDATE = "item_endDate_";
	public static final String ITEM_GENDER = "item_gender_";
	public static final String ITEM_DATE = "item_date_";
	public static final String ITEM_MEDIUM = "item_medium_";
	public static final String ITEM_DIMENSIONS = "item_dimensions_";
	public static final String ITEM_CREDITLINE = "item_creditLine_";
	public static final String ITEM_ACCESSIONNUMBER = "item_accessionNumber_";
	public static final String ITEM_DEPARTMENT = "item_department_";
	public static final String ITEM_DATEACQUIRED = "item_dateAcquired_";
	public static final String ITEM_CATALOGED = "item_cataloged_";
	public static final String ITEM_DEPTH = "item_depth_";
	public static final String ITEM_DIAMETER = "item_diameter_";
	public static final String ITEM_HEIGHT = "item_height_";
	public static final String ITEM_WEIGHT = "item_weight_";
	public static final String ITEM_WIDTH = "item_width_";
	public static final String ITEM_ROOM = "item_room_";
	public static final String VERTEX_LABEL = "vertex_label_";
	public static final String VERTEX_XY = "vertex_xy_";
	/**
	 * Room file
	 */
	public static final String NUMBER_ROOM = "number_room";
	public static final String ROOM_LABEL = "room_label_";
	public static final String ROOM_CORNER = "room_corner_xy_";
	public static final String ROOM_NUMBER_DOOR = "room_number_door_";
	public static final String ROOM_DOOR_XY = "room_door_xy_";
	public static final String ROOM_STAIRS_XY = "room_stairs_xy";
	public static final String NUMBER_CONNECTED_DOOR = "number_connected_door";
	public static final String CONNECTED_DOOR = "connected_door_";
	public static final String NUMBER_CONNECTED_DOOR_STAIRS = "number_connected_door_stairs";
	public static final String CONNECTED_DOOR_STAIRS = "connected_door_stairs_";
	public static final String NUMBER_CONNECTED_STAIRS = "number_connected_stairs";
	public static final String CONNECTED_STAIRS = "connected_stairs_";
	/**
	 * Graph file
	 */
	public static final String ROOM =  "room_";
	public static final String NUMBER_ITEMS_BY_ROOM = "number_items_";
	public static final String ITEM_OF_ROOM = "item_";
	public static final String NUMBER_DOORS_BY_ROOM = "number_doors_";
	public static final String DOOR_OF_ROOM = "door_";
	public static final String STAIRS_OF_ROOM = "number_stairs";
	public static final String ROOM_STAIRS = "stairs_";
}
