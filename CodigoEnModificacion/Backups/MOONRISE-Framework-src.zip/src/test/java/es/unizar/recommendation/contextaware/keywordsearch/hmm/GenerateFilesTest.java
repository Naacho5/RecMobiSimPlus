package es.unizar.recommendation.contextaware.keywordsearch.hmm;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;

import org.junit.Test;

import es.unizar.keywordsearch.hmm.GenerateFiles;
import es.unizar.properties.DBInformation;

/**
 * Tests {@link GenerateFilesTest}.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class GenerateFilesTest {

    @Test
    public static void testGenerateFiles(LinkedList<String> databasePaths) throws SQLException, FileNotFoundException, IOException {
        GenerateFiles generate = new GenerateFiles();
        generate.generateFiles(databasePaths);
    }

    public static void main(String[] args) throws SQLException, FileNotFoundException, IOException {
        //void generateFiles(LinkedList<String> databasePaths)
        LinkedList<String> databasePaths = new LinkedList<String>();
        databasePaths.add(DBInformation.DB_APP_PATH);
        databasePaths.add(DBInformation.DB_BOOK_PATH);
        databasePaths.add(DBInformation.DB_CONCERT_PATH);
        databasePaths.add(DBInformation.DB_FILM_PATH);
        databasePaths.add(DBInformation.DB_MUSIC_PATH);
        databasePaths.add(DBInformation.DB_RESTAURANT_PATH);
        testGenerateFiles(databasePaths);
    }
}
