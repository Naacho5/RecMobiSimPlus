package es.unizar.dbmanagement;

import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class ca_profileTest {

	@Test
	public void insertOneTest() throws SQLException {
		ca_profile table = new ca_profile(DBInformation.DB_MUSEUM_PATH);
		table.insertOne(1, "lazy");
		table.insertOne(2, "active");
		table.insertOne(3, "normal");
	}
}
