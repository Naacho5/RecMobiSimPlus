package es.unizar.dbmanagement;

import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class item_typeTest {
	@Test
	public void insertOneTest() throws SQLException {
		item_type table = new item_type(DBInformation.DB_MUSEUM_PATH);
		table.insertOne("museum");
	}
}
