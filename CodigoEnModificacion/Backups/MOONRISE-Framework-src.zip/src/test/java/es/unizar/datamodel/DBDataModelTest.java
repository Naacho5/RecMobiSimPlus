package es.unizar.datamodel;

import java.sql.SQLException;
import java.util.List;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.model.PreferenceArray;
import org.junit.Assert;
import org.junit.Test;

import es.unizar.properties.DBInformation;
import es.unizar.userprofileandcontextmanager.DBDataModel;

/**
 * Tests {@link DBDataModelTest}.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class DBDataModelTest {

	private DBDataModel dataModel;
	private static final String DB_PATH = DBInformation.DB_FILM_PATH;
	private static final long USER_ID = 15;
	private static final long ITEM_ID = 11;
	private static final long ITEM_ID_2 = 1;
	private static final String VARIABLE_VALUE = "Family";
	private static final String VARIABLE_VALUE_2 = "Parents";
	private static final String VARIABLE_NAME = "mood";

	public DBDataModelTest() throws SQLException {
		this.dataModel = new DBDataModel(DB_PATH);
	}

	@Test
	public void getUserIDsTest() throws TasteException {
		LongPrimitiveIterator userIDs = dataModel.getUserIDs();
		Assert.assertNotNull(userIDs);
	}

	@Test
	public void getPreferencesFromUserTest() throws TasteException {
		PreferenceArray preferenceArray = dataModel.getPreferencesFromUser(USER_ID);
		int size = preferenceArray.length();
		Assert.assertEquals(168, size);
	}

	@Test
	public void getItemIDsFromUserTest() throws TasteException {
		LongPrimitiveIterator result = dataModel.getItemIDsFromUser(USER_ID).iterator();
		Assert.assertNotNull(result);
	}

	@Test
	public void getItemIDsTest() throws TasteException {
		LongPrimitiveIterator itemIDs = dataModel.getItemIDs();
		Assert.assertNotNull(itemIDs);
	}

	@Test
	public void getPreferencesForItemTest() throws TasteException {
		PreferenceArray preferenceArray = dataModel.getPreferencesForItem(ITEM_ID);
		int size = preferenceArray.length();
		Assert.assertEquals(1, size);
	}

	@Test
	public void getPreferenceValueTest() throws TasteException {
		Float rating = dataModel.getPreferenceValue(USER_ID, ITEM_ID);
		Assert.assertEquals(new Float(4.0), rating);
	}

	@Test
	public void getNumItemsTest() throws TasteException {
		int numItems = dataModel.getNumItems();
		Assert.assertEquals(1232, numItems);
	}

	@Test
	public void getNumUsersTest() throws TasteException {
		int numUsers = dataModel.getNumUsers();
		Assert.assertEquals(121, numUsers);
	}

	@Test
	public void getNumUsersWithPreferenceForTest() throws TasteException {
		int numUsers = dataModel.getNumUsersWithPreferenceFor(ITEM_ID);
		Assert.assertEquals(1, numUsers);
	}

	@Test
	public void getNumUsersWithPreferenceFor2Test() throws TasteException {
		dataModel.getNumUsersWithPreferenceFor(ITEM_ID, ITEM_ID_2);
	}

	@Test
	public void getVariableNamesTest() throws TasteException, SQLException {
		List<String> variableNames = dataModel.getVariableNames();
		Assert.assertEquals(12, variableNames.size());
	}

	@Test
	public void getVariableNames2Test() throws TasteException {
		List<String> variableNames = dataModel.getVariableNames(VARIABLE_VALUE);
		Assert.assertNotNull(variableNames);
	}

	@Test
	public void getPossibleVariableValuesTest() throws TasteException {
		List<String> possibleVariableValues = dataModel.getPossibleVariableValues(VARIABLE_NAME);
		Assert.assertEquals(3, possibleVariableValues.size());
	}

	@Test
	public void getVariableNameAndValueTest() throws TasteException {
		List<String> variablesNameAndValue = dataModel.getVariableNameAndValue(USER_ID, ITEM_ID);
		Assert.assertEquals(12, variablesNameAndValue.size());
	}

	@Test
	public void getVariableNameAndWeightTest() throws TasteException {
		List<String> variablesNameAndWeight = dataModel.getVariableNameAndWeight(USER_ID);
		Assert.assertEquals(12, variablesNameAndWeight.size());
	}

	@Test
	public void distanceSoftVariableValuesTest() throws TasteException {
		Double distance = dataModel.distanceSoftVariableValues(VARIABLE_VALUE, VARIABLE_VALUE_2);
		Assert.assertEquals(new Double(0.5), distance);
	}

	@Test
	public void getNumberItemFeaturesTest() throws TasteException {
		int numberItemFeatures = dataModel.getNumberItemFeatures();
		Assert.assertEquals(12, numberItemFeatures);
	}

	@Test
	public void getNamesAndValuesOfFeaturesFromItemTest() throws TasteException {
		List<String> namesAndValuesOfFeatures = dataModel.getNamesAndValuesOfFeaturesFromItem(ITEM_ID);
		Assert.assertEquals(12, namesAndValuesOfFeatures.size());
	}

	@Test
	public void getItemFeatureNamesTest() throws TasteException {
		List<String> itemFeatureNames = dataModel.getItemFeatureNames();
		Assert.assertEquals(14696, itemFeatureNames.size());
	}
}
