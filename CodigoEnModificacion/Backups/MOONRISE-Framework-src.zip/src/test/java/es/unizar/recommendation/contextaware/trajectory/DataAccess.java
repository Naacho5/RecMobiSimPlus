package es.unizar.recommendation.contextaware.trajectory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Access to the values of the properties stored in to file.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class DataAccess {

    protected File file;
    protected Properties properties;

    public DataAccess(File file) {
        this.file = file;
        this.properties = new Properties();
    }

    /**
     * Gets the value of a property of the scheme file.
     *
     * @param fileName Name of the file that contain the properties.
     * @param nameProperty Name of the property.
     * @return The value of the property specified.
     */
    public String getPropertyValue(String nameProperty) {
        InputStream input = null;
        String propertyValue = null;
        try {
            input = new FileInputStream(file.getAbsoluteFile());
            properties.load(input);
            propertyValue = properties.getProperty(nameProperty);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return propertyValue;
    }
}
