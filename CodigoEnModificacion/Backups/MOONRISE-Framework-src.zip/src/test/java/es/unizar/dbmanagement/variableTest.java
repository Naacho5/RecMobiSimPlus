package es.unizar.dbmanagement;

import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class variableTest {
	public static String[] VARIABLES = { "TemperatureRoom", "NumberPeopleRoom", "NoiseLevelRoom", "Mood" };

	public static String[] TEMPERATURE_ROOM = { "warm", "hot", "cold" };
	public static String[] NUMBER_PEOPLE_ROOM = { "none", "little", "much" };
	public static String[] NOISE_LEVEL_ROOM = { "low", "medium", "high" };
	public static String[] MOOD = { "happy", "neutral", "sad" };

	@Test
	public void insertOneTest() throws SQLException {
		variable table = new variable(DBInformation.DB_MUSEUM_PATH);
		int id = 1;
		for (int v = 0; v < TEMPERATURE_ROOM.length; v++) {
			table.insertOne(id, null, VARIABLES[0], TEMPERATURE_ROOM[v], true, true);
			id++;
		}
		for (int v = 0; v < NUMBER_PEOPLE_ROOM.length; v++) {
			table.insertOne(id, null, VARIABLES[1], String.valueOf(NUMBER_PEOPLE_ROOM[v]), true, true);
			id++;
		}
		for (int v = 0; v < NOISE_LEVEL_ROOM.length; v++) {
			table.insertOne(id, null, VARIABLES[2], String.valueOf(NOISE_LEVEL_ROOM[v]), true, true);
			id++;
		}
		for (int v = 0; v < MOOD.length; v++) {
			table.insertOne(id, null, VARIABLES[3], String.valueOf(MOOD[v]), false, false);
			id++;
		}
	}
}
