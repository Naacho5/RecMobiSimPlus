package es.unizar.recommendation.contextaware;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.properties.DBInformation;
import es.unizar.userprofileandcontextmanager.DBDataModel;

/**
 * Tests {@link PostfilteringBasedRecommendationTest}.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class PostfilteringBasedRecommendationTest {

	private static final Logger log = LoggerFactory.getLogger(PostfilteringBasedRecommendationTest.class);

	public static final String TRANSPORT_WAY_VALUE = "walking";
	public static final long USER_LATITUDE = 1421;
	public static final long USER_LONGITUDE = 2169;
	public static final double THRESHOLD_RATING = 3;
	private static final int HOW_MANY = 5;
	private static final long USER_ID = 15;
	private static final int ITEM_ID = 11;

	@Test
	public void recommendTest() throws SQLException, FileNotFoundException, IOException, Exception {
		DBDataModel dataModel = new DBDataModel(DBInformation.DB_FILM_PATH);
		PostfilteringBasedRecommendation postfiltering = new PostfilteringBasedRecommendation(dataModel, THRESHOLD_RATING, DBInformation.DB_FILM_PATH, TRANSPORT_WAY_VALUE, USER_LATITUDE, USER_LONGITUDE);
		List<RecommendedItem> recommendedItems = postfiltering.recommend(USER_ID, HOW_MANY);
		
		Assert.assertNotNull(recommendedItems);
		log.debug("UserID: " + USER_ID + " are recommended the itemIDs: ");
		for (int i = 0; i < recommendedItems.size(); i++) {
			RecommendedItem itemRecommended = recommendedItems.get(i);
			log.debug(itemRecommended.getItemID() + " " + itemRecommended.getValue());
		}
	}

	@Test
	public void estimatePreferenceTest() throws Exception {
		DBDataModel dataModel = new DBDataModel(DBInformation.DB_FILM_PATH);
		PostfilteringBasedRecommendation postfiltering = new PostfilteringBasedRecommendation(dataModel, THRESHOLD_RATING, DBInformation.DB_FILM_PATH, TRANSPORT_WAY_VALUE, USER_LATITUDE, USER_LONGITUDE);
		float estimePreference = postfiltering.estimatePreference(USER_ID, ITEM_ID);
		log.debug("For the userID: " + USER_ID + " and the itemID: " + ITEM_ID + " the preference estimation: "	+ estimePreference);
	}
}
