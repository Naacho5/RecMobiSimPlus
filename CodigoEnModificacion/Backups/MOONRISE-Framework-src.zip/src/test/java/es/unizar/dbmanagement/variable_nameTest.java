package es.unizar.dbmanagement;

import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class variable_nameTest {
	public static String[] VARIABLES = { "TemperatureRoom", "NumberPeopleRoom", "NoiseLevelRoom", "Mood" };

	@Test
	public void insertOneTest() throws SQLException {
		variable_name table = new variable_name(DBInformation.DB_MUSEUM_PATH);
		for (int v = 0; v <= VARIABLES.length; v++) {
			table.insertOne(VARIABLES[v]);
		}
	}
}
