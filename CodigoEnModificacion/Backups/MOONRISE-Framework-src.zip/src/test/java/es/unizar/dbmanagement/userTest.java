package es.unizar.dbmanagement;

import java.sql.SQLException;
import java.util.concurrent.ThreadLocalRandom;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class userTest {
	public static int NUMBER_USERS = 100;

	@Test
	public void insertOneTest() throws SQLException {
		user table = new user(DBInformation.DB_MUSEUM_PATH);
		for (int id_user = 1; id_user <= NUMBER_USERS; id_user++) {
			int id_ca_profile = ThreadLocalRandom.current().nextInt(1, 4 + 1);
			table.insertOne(id_user, null, null, 0, null, id_ca_profile);
		}
	}
}
