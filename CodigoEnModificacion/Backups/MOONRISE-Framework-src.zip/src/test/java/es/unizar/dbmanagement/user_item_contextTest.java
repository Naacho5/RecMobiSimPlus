package es.unizar.dbmanagement;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class user_item_contextTest {

	public static File file = new File("");
	public static final String PATH = file.getAbsolutePath() + File.separatorChar + "src" + File.separatorChar + "test" + File.separatorChar + "resources" + File.separatorChar + "DB" + File.separatorChar + "datasetMuseum" + File.separatorChar;
	public static final String U_I_C_FILE = PATH + "user_item_context.csv";

	@Test
	public void insertOneTest() throws SQLException, IOException {
		user_item_context table = new user_item_context(DBInformation.DB_MUSEUM_PATH);
		BufferedReader br = new BufferedReader(new FileReader(new File(U_I_C_FILE)));
		String line = br.readLine();
		while ((line = br.readLine()) != null) {
			String[] array = line.split(";");
			long id_user = Long.valueOf(array[0]).longValue();
			long id_item = Long.valueOf(array[1]).longValue();
			long id_context = Long.valueOf(array[2]).longValue();
			double id_rating = Double.valueOf(array[3]).doubleValue();
			int user_provided = 1;
			table.insertOne(id_user, id_item, id_context, id_rating, null, user_provided);
		}
		br.close();
	}
}
