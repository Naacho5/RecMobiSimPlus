package es.unizar.recommendation.hybrid;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.common.Weighting;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.recommender.RandomRecommender;
import org.apache.mahout.cf.taste.impl.similarity.TanimotoCoefficientSimilarity;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;
import org.junit.Test;

import es.unizar.properties.DBInformation;
import es.unizar.recommendation.ContentBasedRecommendation;
import es.unizar.recommendation.CosineSimilarity;
import es.unizar.recommendation.hybrid.WeightedHybridRecommendation;
import es.unizar.recommendation.hybrid.votingstrategy.WeightedAdditiveStrategy;
import es.unizar.recommendation.hybrid.votingstrategy.DataStrategy;
import es.unizar.recommendation.hybrid.votingstrategy.AbstractWeightedStrategy;
import es.unizar.userprofileandcontextmanager.DBDataModel;

/**
 * Tests {@link WeightedHybridRecommendationTest}.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class WeightedHybridRecommendationTest {

    private static final String DB_PATH = DBInformation.DB_FILM_PATH;

    @Test
    public static void testMergingHybridRecommender() throws SQLException, TasteException {
        WeightedHybridRecommendation recommender = buildRecommender();
        long userID = 15;
        int howMany = 5;
        List<RecommendedItem> recommended = recommender.recommend(userID, howMany);
        System.out.println("-------------- recommend(long userID, int howMany) -------------------");
        System.out.println("UserID: " + userID + " are recommended the itemIDs: ");
        for (int i = 0; i < howMany; i++) {
            RecommendedItem itemRecommended = recommended.get(i);
            System.out.println(itemRecommended.getItemID() + " " + itemRecommended.getValue());
        }
    }

    private static WeightedHybridRecommendation buildRecommender() throws SQLException, TasteException {
        DBDataModel dataModel = new DBDataModel(DB_PATH);
        List<DataStrategy> dataVotingStrategieList = new LinkedList<DataStrategy>();

        //CollaborativeFilteringBasedRecommendation
        UserSimilarity JaccardSimilarity = new TanimotoCoefficientSimilarity(dataModel);
        UserNeighborhood neighborhood = new NearestNUserNeighborhood(2, JaccardSimilarity, dataModel);
        Recommender recommenderCollaborativeFiltering = new GenericUserBasedRecommender(dataModel, neighborhood, JaccardSimilarity);
        dataVotingStrategieList.add(new DataStrategy(recommenderCollaborativeFiltering, (float) 0.4));

        //ContentBasedRecommendation
        CosineSimilarity cosineSimilarity = new CosineSimilarity(dataModel, Weighting.WEIGHTED, false);
        Recommender recommenderContentBased = new ContentBasedRecommendation(dataModel, cosineSimilarity);
        dataVotingStrategieList.add(new DataStrategy(recommenderContentBased, (float) 0.4));

        //RandomRecommender
        Recommender recommenderRandom = new RandomRecommender(dataModel);
        dataVotingStrategieList.add(new DataStrategy(recommenderRandom, (float) 0.2));

        //AdditiveVotingStrategy, AverageVotingStrategy, LeastMiseryVotingStrategy, MostPleasureVotingStrategy
        AbstractWeightedStrategy votingStrategy = new WeightedAdditiveStrategy(dataVotingStrategieList);
        return new WeightedHybridRecommendation(votingStrategy, dataModel);
    }

    public static void testEstimatePreference() throws SQLException, TasteException {
        WeightedHybridRecommendation recommender = buildRecommender();
        long userID = 15;
        int itemID = 11;
        float estimePreference = recommender.estimatePreference(userID, itemID);
        System.out.println("-------------- estimatePreference(long userID, long itemID) -------------------");
        System.out.println("For the userID: " + userID + " and the itemID: " + itemID + " the preference estimation: " + estimePreference);
    }

    public static void main(String[] args) throws SQLException, TasteException {
        //MergingHybridRecommender: recommend(long userID, int howMany)
        testMergingHybridRecommender();

        //estimatePreference(long userId, long itemId)
        testEstimatePreference();
    }
}
