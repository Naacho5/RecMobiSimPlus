package es.unizar.database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.mahout.cf.taste.common.TasteException;
import org.junit.Assert;
import org.junit.Test;

import es.unizar.properties.DBInformation;
import es.unizar.repositorymanager.DataAccessLayer;
import es.unizar.util.VariableWeight;

/**
 * Tests {@link DataAccessLayerTest}.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class DataAccessLayerTest {

	private static final String DB_PATH = DBInformation.DB_FILM_PATH;
	private static final long ITEM_ID = 11;
	private static final long USER_ID = 15;

	@Test
	public void getItemDataTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> itemColumns = new LinkedList<String>();
		itemColumns.add("type");
		ResultSet resultSet = access.getItemData(ITEM_ID, itemColumns);
		Assert.assertNotNull(resultSet);
	}

	@Test
	public void getItemIDsTest() throws SQLException {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<Integer> list = access.getItemIDs();
		Assert.assertEquals(1232, list.size());
	}

	@Test
	public void getNumberOfItemsTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		Assert.assertEquals(1232, access.getNumberOfItems());
	}

	@Test
	public void getItemTypesTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> list = access.getItemTypes();
		Assert.assertEquals(1, list.size());
		Assert.assertEquals("film", list.get(0));
	}

	@Test
	public void getFeatureNamesAllTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> list = access.getFeatureNames();
		Assert.assertEquals(12, list.size());
	}

	@Test
	public void getFeatureValuesTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> list = access.getFeatureValues();
		Assert.assertEquals(4311, list.size());
	}

	@Test
	public void getFeatureValueFromFeatureNameTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> list = access.getFeatureValueFromFeatureName("country");
		Assert.assertEquals(38, list.size());
	}

	@Test
	public void getNumberOfFeaturesTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		Assert.assertEquals(12, access.getNumberOfFeatures());
	}

	@Test
	public void getFeatureNamesFromItemTest() throws SQLException, TasteException {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		ResultSet resultSet = (ResultSet) access.getFeatureNamesFromItem(ITEM_ID);
		Assert.assertNotNull(resultSet);
	}

	@Test
	public void getUserDataTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> userColumns = new LinkedList<String>();
		userColumns.add("age");
		userColumns.add("sex");
		userColumns.add("city_numeric");
		userColumns.add("country");
		ResultSet resultSet = access.getUserData(USER_ID, userColumns);
		Assert.assertNotNull(resultSet);
	}

	@Test
	public void getUserIDsTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		Assert.assertEquals(121, access.getUserIDs().length);
	}

	@Test
	public void getNumberOfUsersTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		Assert.assertEquals(121, access.getNumberOfUsers());
	}

	@Test
	public void getUserItemRatingTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> resultSet = access.getUserItemRating();
		Assert.assertNotNull(resultSet);
	}

	@Test
	public void getUserItemContextRatingTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		ResultSet resultSet = access.getUserItemContextRating();
		Assert.assertNotNull(resultSet);
	}

	@Test
	public void getOpinionForTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		ResultSet resultSet = access.getOpinionFor(USER_ID, ITEM_ID);
		Assert.assertNotNull(resultSet);
	}

	@Test
	public void getContextForTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		ResultSet resultSet = access.getContextFor(USER_ID, ITEM_ID);
		Assert.assertNotNull(resultSet);
	}

	@Test
	public void getContextIDForTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		long userID = access.getContextIDFor(USER_ID, ITEM_ID);
		Assert.assertNotNull(userID);
	}

	@Test
	public void getNumberOfInstancesTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		Assert.assertEquals(2296, access.getNumberOfInstances());
	}

	@Test
	public void getHashWithNumberItemsByUserTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		Map<Long, Integer> hashWithNumberItemsByUser = access.getHashWithNumberItemsByUser();
		Assert.assertEquals(121, hashWithNumberItemsByUser.size());
	}

	@Test
	public void getVariableNamesTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> list = access.getVariableNames();
		Assert.assertEquals(12, list.size());
	}

	@Test
	public void getVariableNameFromVariableValueTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		String variableValue = "Public";
		List<String> variableNames = access.getVariableNameFromVariableValue(variableValue);
		Assert.assertEquals(2, variableNames.size());
	}

	@Test
	public void getPossibleVariableValuesTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		String variableName = "mood";
		List<String> possibleVariableValues = access.getPossibleVariableValues(variableName);
		Assert.assertEquals(3, possibleVariableValues.size());
	}

	@Test
	public void getVariableNameAndValueTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> variableNameValue = access.getVariableNameAndValue(USER_ID, ITEM_ID);
		Assert.assertEquals(12, variableNameValue.size());
	}

	@Test
	public void getVariableNameAndWeightTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> variableNameWeight = access.getVariableNameAndWeight(USER_ID);
		Assert.assertEquals(12, variableNameWeight.size());
	}

	@Test
	public void setOneWeightTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		String variableName = "social";
		double currentWeight = 0.2;
		access.setOneWeight(variableName, currentWeight);
	}

	@Test
	public void setAllWeightTest() throws ClassNotFoundException, SQLException {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<VariableWeight> list = new LinkedList<VariableWeight>();
		list.add(new VariableWeight("social", 0.125));
		list.add(new VariableWeight("end_emo", 0));
		list.add(new VariableWeight("dominant_emo", 0));
		list.add(new VariableWeight("mood", 0.125));
		list.add(new VariableWeight("physical", 0.125));
		list.add(new VariableWeight("decision", 0));
		list.add(new VariableWeight("interaction", 0));
		list.add(new VariableWeight("location", 0.125));
		list.add(new VariableWeight("time", 0.125));
		list.add(new VariableWeight("daytype", 0.125));
		list.add(new VariableWeight("season", 0.125));
		list.add(new VariableWeight("weather", 0.125));
		access.setAllWeight(list);
	}

	@Test
	public void distanceSoftVariableValuesTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		String variableValue1 = "Family";
		String variableValue2 = "Parents";
		double distance = access.distanceSoftVariableValues(variableValue1, variableValue2);
		Assert.assertNotEquals(0, distance);
	}

	@Test
	public void getRadiusTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		String transportWayValue = "walking";
		long radious = access.getRadius(USER_ID, transportWayValue);
		Assert.assertEquals(500, radious);
	}

	@Test
	public void getItemLatitudeTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		long latitude = access.getItemLatitude(ITEM_ID);
		Assert.assertEquals(0, latitude);
	}

	@Test
	public void getItemLongitudeTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		long longitude = access.getItemLongitude(ITEM_ID);
		Assert.assertEquals(0, longitude);
	}

	@Test
	public void getMaximumRatingTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		Float maximumRating = access.getMaximumRating();
		Assert.assertEquals(new Float(5.0), maximumRating);
	}

	@Test
	public void getNumberItemFeaturesTest() {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		int numFeatures = access.getNumberItemFeatures();
		Assert.assertEquals(12, numFeatures);
	}

	@Test
	public void getNamesAndValuesOfFeaturesFromItemTest() throws TasteException {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> namesAndValuesOfFeaturesFromItem = access.getNamesAndValuesOfFeaturesFromItem(ITEM_ID);
		Assert.assertEquals(12, namesAndValuesOfFeaturesFromItem.size());
	}

	@Test
	public void getItemFeatureNamesTest() throws TasteException {
		DataAccessLayer access = new DataAccessLayer(DB_PATH);
		List<String> featureNames = access.getItemFeatureNames();
		Assert.assertEquals(14696, featureNames.size());
	}
}
