package es.unizar.recommendation.contextaware.push;

public class IndoorPushBasedRecommendationTest {

}
