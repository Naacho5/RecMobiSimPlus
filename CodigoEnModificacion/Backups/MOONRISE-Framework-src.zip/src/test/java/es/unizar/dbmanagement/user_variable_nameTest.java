package es.unizar.dbmanagement;

import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class user_variable_nameTest {
	public static int NUMBER_USERS = 100;
	public static String[] CONTEXT = { "TemperatureRoom", "NumberPeopleRoom", "NoiseLevelRoom", "Mood" };

	@Test
	public void insertOneTest() throws SQLException {
		user_variable_name table = new user_variable_name(DBInformation.DB_MUSEUM_PATH);
		for (int id_user = 1; id_user <= NUMBER_USERS; id_user++) {
			table.insertOne(id_user, CONTEXT[0], 0.25);
			table.insertOne(id_user, CONTEXT[1], 0.25);
			table.insertOne(id_user, CONTEXT[2], 0.25);
			table.insertOne(id_user, CONTEXT[3], 0.25);
		}
	}
}
