package es.unizar.recommendation;

import java.sql.SQLException;
import java.util.List;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.recommender.GenericItemBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.TanimotoCoefficientSimilarity;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.similarity.ItemSimilarity;
import org.junit.Assert;
import org.junit.Test;

import es.unizar.properties.DBInformation;
import es.unizar.userprofileandcontextmanager.DBDataModel;

/**
 * Tests {@link ItemBasedCollaborativeFilteringRecommendationTest}.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class ItemBasedCollaborativeFilteringRecommendationTest {

	private static final String DB_PATH = DBInformation.DB_FILM_PATH;
	private static final long USER_ID = 15;
	private static final int HOW_MANY = 5;
	private static final int ITEM_ID = 11;

	@Test
	public void recommendTest() throws Exception {
		GenericItemBasedRecommender recommender = buildRecommender();
		List<RecommendedItem> recommended = recommender.recommend(USER_ID, HOW_MANY);
		Assert.assertNotNull(recommended);
	}

	@Test
	public void mostSimilarTest() throws Exception {
		GenericItemBasedRecommender recommender = buildRecommender();
		List<RecommendedItem> similar = recommender.mostSimilarItems(ITEM_ID, HOW_MANY);
		Assert.assertNotNull(similar);
	}

	@Test
	public void estimatePreferenceTest() throws Exception {
		GenericItemBasedRecommender recommender = buildRecommender();
		float estimePreference = recommender.estimatePreference(USER_ID, ITEM_ID);
		Assert.assertNotEquals(0, estimePreference);
	}

	private GenericItemBasedRecommender buildRecommender() throws SQLException, TasteException {
		DBDataModel dataModel = new DBDataModel(DB_PATH);
		// Jaccard_coefficient
		ItemSimilarity similarity = new TanimotoCoefficientSimilarity(dataModel);
		return new GenericItemBasedRecommender(dataModel, similarity);
	}
}
