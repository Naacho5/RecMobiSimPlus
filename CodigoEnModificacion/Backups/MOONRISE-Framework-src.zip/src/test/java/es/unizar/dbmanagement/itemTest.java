package es.unizar.dbmanagement;

import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class itemTest {
	public static int NUMBER_ITEMS = 240;
	public static String TYPE = "museum";

	@Test
	public void insertOneTest() throws SQLException {
		item table = new item(DBInformation.DB_MUSEUM_PATH);
		for (int id_item = 1; id_item <= NUMBER_ITEMS; id_item++) {
			String name = null;
			table.insertOne(id_item, name, TYPE);
		}
	}
}
