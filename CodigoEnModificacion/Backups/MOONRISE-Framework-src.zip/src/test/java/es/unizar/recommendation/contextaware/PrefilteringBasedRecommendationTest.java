package es.unizar.recommendation.contextaware;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.properties.DBInformation;
import es.unizar.userprofileandcontextmanager.DBDataModel;

/**
 * Tests {@link PrefilteringBasedRecommendationTest}.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class PrefilteringBasedRecommendationTest {

	private static final Logger log = LoggerFactory.getLogger(PrefilteringBasedRecommendationTest.class);

	private static final long USER_ID = 15;
	private static final int HOW_MANY = 5;
	private static final int ITEM_ID = 11;
	private static final double THRESHOLD = 0.1;

	@Test
	public void recommendTest() throws SQLException, FileNotFoundException, IOException, Exception {
		DBDataModel dataModel = new DBDataModel(DBInformation.DB_FILM_PATH);
		// Context of the db_film.db
		List<String> context = new LinkedList<String>();
		context.add("Alone");
		context.add("Happy");
		context.add("Happy");
		context.add("Neutral");
		context.add("Healthy");
		context.add("Decision");
		context.add("First");
		context.add("Home");
		context.add("Evening");
		context.add("Weekend");
		context.add("Summer");
		context.add("Sunny");
		// Prefiltering
		PrefilteringBasedRecommendation prefiltering = new PrefilteringBasedRecommendation(dataModel, context,	THRESHOLD);
		List<RecommendedItem> recommended = prefiltering.recommend(USER_ID, HOW_MANY);

		Assert.assertNotNull(recommended);
		log.debug("UserID: " + USER_ID + " are recommended the itemIDs: ");
		for (int i = 0; i < HOW_MANY; i++) {
			RecommendedItem itemRecommended = recommended.get(i);
			log.debug(itemRecommended.getItemID() + " " + itemRecommended.getValue());
		}
	}

	@Test
	public void estimatePreferenceTest() throws Exception {
		DBDataModel dataModel = new DBDataModel(DBInformation.DB_FILM_PATH);
		// Context of the db_film.db
		List<String> context = new LinkedList<String>();
		context.add("Alone");
		context.add("Happy");
		context.add("Happy");
		context.add("Neutral");
		context.add("Healthy");
		context.add("Decision");
		context.add("First");
		context.add("Home");
		context.add("Evening");
		context.add("Weekend");
		context.add("Summer");
		context.add("Sunny");
		// Prefiltering
		PrefilteringBasedRecommendation prefiltering = new PrefilteringBasedRecommendation(dataModel, context, THRESHOLD);
		float estimePreference = prefiltering.estimatePreference(USER_ID, ITEM_ID);

		Assert.assertNotEquals(0, estimePreference);
		log.debug("For the userID: " + USER_ID + " and the itemID: " + ITEM_ID + " the preference estimation: " + estimePreference);
	}
}
