package es.unizar.dbmanagement;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class item_featureTest {
	public static int NUMBER_ITEMS = 240;

	public static File file = new File("");
	public static final String PATH = file.getAbsolutePath() + File.separatorChar + "src" + File.separatorChar + "test"
			+ File.separatorChar + "resources" + File.separatorChar + "DB" + File.separatorChar + "datasetMuseum"
			+ File.separatorChar;
	public static final String CONTEXT_FILE = "item.csv";

	@Test
	public void insertOneTest() throws SQLException, IOException {
		item_feature table = new item_feature(DBInformation.DB_MUSEUM_PATH);
		BufferedReader br = new BufferedReader(new FileReader(new File(PATH + CONTEXT_FILE)));
		String header = br.readLine();
		String line = null;
		while ((line = br.readLine()) != null) {
			String[] array = line.split(";");
			for (int j = 1; j < array.length; j++) {
				int id_item = Integer.valueOf(array[0]).intValue();				
				System.out.println(id_item);
				String name = header.split(";")[j];
				String value = array[j];
				table.insertOne(id_item, name, value);
			}
		}
		br.close();
	}
}
