package es.unizar.recommendation.contextaware.trajectory;

import java.io.File;

/**
 * Access to the values of the properties stored in the graph files.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class DataAccessGraphFile extends DataAccess {

	public DataAccessGraphFile(File file) {
		super(file);
	}

	public int getNumberOfRoom() {
		return Integer.valueOf(getPropertyValue(Literals.NUMBER_ROOM)).intValue();
	}

	public int getRoom(int posRoom) {
		return Integer.valueOf(getPropertyValue(Literals.ROOM + posRoom)).intValue();
	}

	public int getNumberOfItemsByRoom(int posRoom) {
		return Integer.valueOf(getPropertyValue(Literals.NUMBER_ITEMS_BY_ROOM + posRoom)).intValue();
	}

	public long getItemOfRoom(int posItem, int posRoom) {
		return Long.valueOf(getPropertyValue(Literals.ITEM_OF_ROOM + posItem + "_" + posRoom)).longValue();
	}

	public int getNumberOfDoorsByRoom(int posRoom) {
		return Integer.valueOf(getPropertyValue(Literals.NUMBER_DOORS_BY_ROOM + posRoom)).intValue();
	}

	public long getDoorOfRoom(int posDoor, int posRoom) {
		return Long.valueOf(getPropertyValue(Literals.DOOR_OF_ROOM + posDoor + "_" + posRoom)).longValue();
	}

	public long getDoorOfRoom(String door) {
		return Long.valueOf(getPropertyValue(door)).longValue();
	}

	public int getNumberOfConnectedDoor() {
		return Integer.valueOf(getPropertyValue(Literals.NUMBER_CONNECTED_DOOR)).intValue();
	}

	public String getConnectedDoor(int posDoor) {
		return getPropertyValue(Literals.CONNECTED_DOOR + posDoor);
	}

	public int getNumberOfStairsOfRoom() {
		return Integer.valueOf(getPropertyValue(Literals.STAIRS_OF_ROOM)).intValue();
	}

	public long getStairsOfRoom(int posStairs) {
		return Long.valueOf(getPropertyValue(Literals.ROOM_STAIRS + posStairs)).longValue();
	}

	public long getStairsOfRoom(String stairs) {
		return Long.valueOf(getPropertyValue(stairs)).longValue();
	}

	public int getNumberOfConnectedDoorStairs() {
		return Integer.valueOf(getPropertyValue(Literals.NUMBER_CONNECTED_DOOR_STAIRS)).intValue();
	}

	public String getConnectedDoorStairs(int posDoorStairs) {
		return getPropertyValue(Literals.CONNECTED_DOOR_STAIRS + posDoorStairs);
	}
	
	public int getNumberOfConnectedStairs() {
		return Integer.valueOf(getPropertyValue(Literals.NUMBER_CONNECTED_STAIRS)).intValue();
	}
	
	public String getConnectedStairs(int posStairs) {
		return getPropertyValue(Literals.CONNECTED_STAIRS + posStairs);
	}
}
