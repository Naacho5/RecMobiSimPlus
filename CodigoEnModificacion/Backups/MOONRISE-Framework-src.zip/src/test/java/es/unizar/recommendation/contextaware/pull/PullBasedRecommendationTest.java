package es.unizar.recommendation.contextaware.pull;

import java.util.LinkedList;
import java.util.List;

import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.properties.ContextualModelingFileDirectory;
import es.unizar.properties.DBInformation;
import es.unizar.recommendation.contextaware.ContextualModelingBasedRecommendation;
import es.unizar.recommendation.contextaware.PostfilteringBasedRecommendation;
import es.unizar.recommendation.contextaware.PrefilteringBasedRecommendation;
import es.unizar.userprofileandcontextmanager.DBDataModel;
import weka.classifiers.bayes.NaiveBayes;

public class PullBasedRecommendationTest {

	private static final Logger log = LoggerFactory.getLogger(PullBasedRecommendationTest.class);

	public static final String USER_QUERY = "Film";

	public static final int NUM_FEATURES = 10;
	public static final int INITIAL_STEPS = 10;
	private static final long USER_ID = 15;
	private static final int HOW_MANY = 5;
	private static final double THRESHOLD = 0.1;

	public static final String TRANSPORT_WAY_VALUE = "walking";
	public static final double THRESHOLD_RATING = 3;
	public static final long USER_LATITUDE = 1421;
	public static final long USER_LONGITUDE = 2169;

	// Prefiltering
	@Test
	public void prefilteringBasedPullRecommendation() throws Exception {
		// ContextAwareRecommendation: Prefiltering
		// Context of the db_film.db
		DBDataModel dataModel = new DBDataModel(DBInformation.DB_FILM_PATH);
		List<String> context = new LinkedList<String>();
		context.add("Alone");
		context.add("Happy");
		context.add("Happy");
		context.add("Neutral");
		context.add("Healthy");
		context.add("Decision");
		context.add("First");
		context.add("Home");
		context.add("Evening");
		context.add("Weekend");
		context.add("Summer");
		context.add("Sunny");
		PrefilteringBasedRecommendation prefiltering = new PrefilteringBasedRecommendation(dataModel, context,
				THRESHOLD);

		// Pull recommendation:
		List<String> databasePaths = new LinkedList<String>();
		databasePaths.add(DBInformation.DB_APP_PATH);
		databasePaths.add(DBInformation.DB_BOOK_PATH);
		databasePaths.add(DBInformation.DB_CONCERT_PATH);
		databasePaths.add(DBInformation.DB_FILM_PATH);
		databasePaths.add(DBInformation.DB_MUSIC_PATH);
		databasePaths.add(DBInformation.DB_RESTAURANT_PATH);
		databasePaths.add(DBInformation.DB_POI_PATH);
		PullBasedRecommendation pullRecommendation = new PullBasedRecommendation(USER_QUERY, databasePaths,
				prefiltering);
		List<RecommendedItem> recommended = pullRecommendation.recommend(USER_ID, HOW_MANY);

		Assert.assertNotNull(recommended);
		log.debug("UserID: " + USER_ID + " are recommended the itemIDs: ");
		for (int i = 0; i < HOW_MANY; i++) {
			RecommendedItem itemRecommended = recommended.get(i);
			log.debug(itemRecommended.getItemID() + " " + itemRecommended.getValue());
		}
	}

	// Postfiltering
	@Test
	public void postfilteringBasedPullRecommendation() throws Exception {
		// ContextAwareRecommendation: Postfiltering
		DBDataModel dataModel = new DBDataModel(DBInformation.DB_FILM_PATH);
		PostfilteringBasedRecommendation postfiltering = new PostfilteringBasedRecommendation(dataModel, THRESHOLD_RATING, DBInformation.DB_FILM_PATH, TRANSPORT_WAY_VALUE, USER_LATITUDE, USER_LONGITUDE);

		// Pull recommendation:
		List<String> databasePaths = new LinkedList<String>();
		databasePaths.add(DBInformation.DB_APP_PATH);
		databasePaths.add(DBInformation.DB_BOOK_PATH);
		databasePaths.add(DBInformation.DB_CONCERT_PATH);
		databasePaths.add(DBInformation.DB_FILM_PATH);
		databasePaths.add(DBInformation.DB_MUSIC_PATH);
		databasePaths.add(DBInformation.DB_RESTAURANT_PATH);
		databasePaths.add(DBInformation.DB_POI_PATH);
		PullBasedRecommendation pullRecommendation = new PullBasedRecommendation(USER_QUERY, databasePaths, postfiltering);
		List<RecommendedItem> recommendedItems = pullRecommendation.recommend(USER_ID, HOW_MANY);
		
		Assert.assertNotNull(recommendedItems);
		log.debug("UserID: " + USER_ID + " are recommended the itemIDs: ");
		for (int i = 0; i < recommendedItems.size(); i++) {
			RecommendedItem itemRecommended = recommendedItems.get(i);
			log.debug(itemRecommended.getItemID() + " " + itemRecommended.getValue());
		}
	}

	// ContextualModeling
	@Test
	public void CMBasedPullRecommendation() throws Exception {
		// ContextAwareRecommendation: Postfiltering
		DBDataModel dataModel = new DBDataModel(DBInformation.DB_FILM_PATH);
		NaiveBayes classifier = new NaiveBayes();
		ContextualModelingBasedRecommendation cm = new ContextualModelingBasedRecommendation(dataModel, ContextualModelingFileDirectory.KNOWLEDGE_BASES_DIRECTORY_PATH, classifier);
		
		// Pull recommendation:
		List<String> databasePaths = new LinkedList<String>();
		databasePaths.add(DBInformation.DB_APP_PATH);
		databasePaths.add(DBInformation.DB_BOOK_PATH);
		databasePaths.add(DBInformation.DB_CONCERT_PATH);
		databasePaths.add(DBInformation.DB_FILM_PATH);
		databasePaths.add(DBInformation.DB_MUSIC_PATH);
		databasePaths.add(DBInformation.DB_RESTAURANT_PATH);
		databasePaths.add(DBInformation.DB_POI_PATH);
		PullBasedRecommendation pullRecommendation = new PullBasedRecommendation(USER_QUERY, databasePaths, cm);
		List<RecommendedItem> recommendedItems = pullRecommendation.recommend(USER_ID, HOW_MANY);
		
		Assert.assertNotNull(recommendedItems);
		log.debug("UserID: " + USER_ID + " are recommended the itemIDs: ");
		for (int i = 0; i < recommendedItems.size(); i++) {
			RecommendedItem itemRecommended = recommendedItems.get(i);
			log.debug(itemRecommended.getItemID() + " " + itemRecommended.getValue());
		}
	}
}
