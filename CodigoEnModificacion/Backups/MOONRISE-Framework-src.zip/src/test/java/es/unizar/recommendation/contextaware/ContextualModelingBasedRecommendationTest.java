package es.unizar.recommendation.contextaware;

import java.util.List;

import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.properties.ContextualModelingFileDirectory;
import es.unizar.properties.DBInformation;
import es.unizar.userprofileandcontextmanager.DBDataModel;
import weka.classifiers.bayes.NaiveBayes;

/**
 * Tests {@link ContextualModelingBasedRecommendationTest}.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class ContextualModelingBasedRecommendationTest {

	private static final Logger log = LoggerFactory.getLogger(ContextualModelingBasedRecommendationTest.class);

	private static final long USER_ID = 15;
	private static final int HOW_MANY = 5;
	private static final int ITEM_ID = 11;

	@Test
	public void recommendTest() throws Exception {
		DBDataModel dataModel = new DBDataModel(DBInformation.DB_FILM_PATH);
		NaiveBayes classifier = new NaiveBayes();
		ContextualModelingBasedRecommendation cm = new ContextualModelingBasedRecommendation(dataModel, ContextualModelingFileDirectory.KNOWLEDGE_BASES_DIRECTORY_PATH, classifier);
		List<RecommendedItem> recommended = cm.recommend(USER_ID, HOW_MANY);
		
		log.debug("UserID: " + USER_ID + " are recommended the itemIDs: ");
		for (int i = 0; i < HOW_MANY; i++) {
			RecommendedItem itemRecommended = recommended.get(i);
			log.debug(itemRecommended.getItemID() + " " + itemRecommended.getValue());
		}
	}

	@Test
	public void estimatePreferenceTest() throws Exception {
		DBDataModel dataModel = new DBDataModel(DBInformation.DB_FILM_PATH);
		NaiveBayes classifier = new NaiveBayes();
		ContextualModelingBasedRecommendation cm = new ContextualModelingBasedRecommendation(dataModel, ContextualModelingFileDirectory.KNOWLEDGE_BASES_DIRECTORY_PATH, classifier);
		float estimePreference = cm.estimatePreference(USER_ID, ITEM_ID);
		
		log.debug("For the userID: " + USER_ID + " and the itemID: " + ITEM_ID + " the preference estimation: " + estimePreference);
	}
}
