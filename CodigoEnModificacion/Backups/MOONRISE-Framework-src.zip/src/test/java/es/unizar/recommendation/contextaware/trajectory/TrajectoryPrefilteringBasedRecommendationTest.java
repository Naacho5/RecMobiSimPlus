//package es.unizar.recommendation.contextaware.trajectory;
//
//import java.io.File;
//import java.util.LinkedList;
//import java.util.List;
//
//import org.apache.mahout.cf.taste.recommender.RecommendedItem;
//import org.jgrapht.graph.DefaultWeightedEdge;
//import org.jgrapht.graph.SimpleWeightedGraph;
//import org.junit.Test;
//
//import es.unizar.datamodel.DBDataModel;
//import es.unizar.properties.DBInformation;
//import es.unizar.recommendation.contextaware.PrefilteringBasedRecommendation;
//
//public class TrajectoryPrefilteringBasedRecommendationTest {
//
//	private static final double THRESHOLD = 0.1;
//	private static final long USER_ID = 2;
//	private static final int HOW_MANY = 10;
//
//	@Test
//	public void recommendTest() throws Exception {
//		// CARS
//		DBDataModel dataModel = new DBDataModel(DBInformation.DB_MUSEUM_PATH);
//		List<String> context = new LinkedList<String>();
//		context.add("hot");
//		context.add("11");
//		PrefilteringBasedRecommendation prefiltering = new PrefilteringBasedRecommendation(dataModel, context, THRESHOLD);
//		// Graph
//		SimpleWeightedGraph<Long, DefaultWeightedEdge> graph = buildGraph();
//		ShortestTrajectoryStrategy trajectoryStrategy = new ShortestTrajectoryStrategy(graph);
//		TrajectoryPrefilteringBasedRecommendation trajectoryBasedRecommendation = new TrajectoryPrefilteringBasedRecommendation(prefiltering, trajectoryStrategy);
//		List<RecommendedItem> recommendedItems = trajectoryBasedRecommendation.recommend(USER_ID, HOW_MANY);
//		for (int i = 0; i < recommendedItems.size(); i++) {
//			System.out.println(recommendedItems.get(i).getItemID());
//		}
//	}
//
//	private SimpleWeightedGraph<Long, DefaultWeightedEdge> buildGraph() {
//		// Graph
//		SimpleWeightedGraph<Long, DefaultWeightedEdge> graph = new SimpleWeightedGraph<Long, DefaultWeightedEdge>(DefaultWeightedEdge.class);
//
//		DataAccessGraphFile dataAccesGraphFile = new DataAccessGraphFile(new File(Literals.GRAPH_FLOOR_4));
//		int numberOfRooms = dataAccesGraphFile.getNumberOfRoom();
//		for (int posRoom = 1; posRoom <= numberOfRooms; posRoom++) {
//			System.out.println(posRoom);
//			List<Long> verticesRelated = new LinkedList<Long>();
//			// Add vertex: Items
//			int numberOfItemByRoom = dataAccesGraphFile.getNumberOfItemsByRoom(posRoom);
//			for (int posItem = 1; posItem <= numberOfItemByRoom; posItem++) {
//				long itemID = dataAccesGraphFile.getItemOfRoom(posItem, posRoom);
//				graph.addVertex(itemID);
//				verticesRelated.add(itemID);
//			}
//			// Doors
//			int numberOfDoorByRoom = dataAccesGraphFile.getNumberOfDoorsByRoom(posRoom);
//			for (int posDoor = 1; posDoor <= numberOfDoorByRoom; posDoor++) {
//				long doorID = dataAccesGraphFile.getDoorOfRoom(posDoor, posRoom);
//				graph.addVertex(doorID);
//				verticesRelated.add(doorID);
//			}
//			// Add edges: items and doors
//			double weight = 1.0;
//			for (int k = 0; k < verticesRelated.size(); k++) {
//				long v1 = verticesRelated.get(k);
//				for (int j = k + 1; j < verticesRelated.size(); j++) {
//					long v2 = verticesRelated.get(j);
//					graph.setEdgeWeight(graph.addEdge(v1, v2), weight);
//				}
//			}
//
//		}
//		// Stairs
//		int numberOfStairsByRoom = dataAccesGraphFile.getNumberOfStairsOfRoom();
//		for (int posStairs = 1; posStairs <= numberOfStairsByRoom; posStairs++) {
//			long stairsID = dataAccesGraphFile.getStairsOfRoom(posStairs);
//			graph.addVertex(stairsID);
//		}
//
//		double weight = 0;
//		int numberOfConnectedDoor = dataAccesGraphFile.getNumberOfConnectedDoor();
//		for (int posDoor = 1; posDoor <= numberOfConnectedDoor; posDoor++) {
//			String connectedDoor = dataAccesGraphFile.getConnectedDoor(posDoor);
//			String[] array = connectedDoor.split(", ");
//			String door1 = array[0];
//			String door2 = array[1];
//			long d1 = dataAccesGraphFile.getDoorOfRoom(door1);
//			long d2 = dataAccesGraphFile.getDoorOfRoom(door2);
//			graph.setEdgeWeight(graph.addEdge(d1, d2), weight);
//		}
//
//		int numberOfConnectedDoorStairs = dataAccesGraphFile.getNumberOfConnectedDoorStairs();
//		for (int posDoorStairs = 1; posDoorStairs <= numberOfConnectedDoorStairs; posDoorStairs++) {
//			String connectedDoorStairs = dataAccesGraphFile.getConnectedDoorStairs(posDoorStairs);
//			String[] array = connectedDoorStairs.split(", ");
//			String stairs = array[0];
//			String door = array[1];
//			long s = dataAccesGraphFile.getStairsOfRoom(stairs);
//			long d = dataAccesGraphFile.getDoorOfRoom(door);
//			graph.setEdgeWeight(graph.addEdge(s, d), weight);
//		}
//		return graph;
//	}
//
//	// @Test
//	// public void estimatePreferenceTest() throws TasteException {
//	//
//	// }
//}
