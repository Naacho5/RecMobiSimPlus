package es.unizar.recommendation.contextaware.trajectory;

import java.io.File;

/**
 * Access to the values of the properties stored in the floor files.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class DataAccessItemFile extends DataAccess {

    public DataAccessItemFile(File file) {
        super(file);
    }

    public String getName() {
        return getPropertyValue(Literals.NAME);
    }

    public int getNumberOfItems() {
        return Integer.valueOf(getPropertyValue(Literals.NUMBER_ITEMS)).intValue();
    }

    public double getVertexDimensionHeight() {
        return Double.valueOf(getPropertyValue(Literals.VERTEX_DIMENSION_HEIGHT)).doubleValue();
    }

    public double getVertexDimensionWidth() {
        return Double.valueOf(getPropertyValue(Literals.VERTEX_DIMENSION_WIDTH)).doubleValue();
    }

    public int getItemID(int position) {
        return Integer.valueOf(getPropertyValue(Literals.ITEM_ID + position)).intValue();
    }

    public String getItemTitle(int position) {
        return getPropertyValue(Literals.ITEM_TITLE + position);
    }

    public String getItemArtist(int position) {
        return getPropertyValue(Literals.ITEM_ARTIST + position);
    }

    public int getItemConstituentID(int position) {
        return Integer.valueOf(getPropertyValue(Literals.ITEM_CONSTITUENTID + position)).intValue();
    }

    public String getItemArtistBio(int position) {
        return getPropertyValue(Literals.ITEM_ARTISTBIO + position);
    }

    public String getItemNationality(int position) {
        return getPropertyValue(Literals.ITEM_NATIONALITY + position);
    }

    public String getItemBeginDate(int position) {
        return getPropertyValue(Literals.ITEM_BEGINDATE + position);
    }

    public String getItemEndDate(int position) {
        return getPropertyValue(Literals.ITEM_ENDDATE + position);
    }

    public String getItemGender(int position) {
        return getPropertyValue(Literals.ITEM_GENDER + position);
    }

    public String getItemDate(int position) {
        return getPropertyValue(Literals.ITEM_DATE + position);
    }

    public String getItemMedium(int position) {
        return getPropertyValue(Literals.ITEM_MEDIUM + position);
    }

    public String getItemDimensions(int position) {
        return getPropertyValue(Literals.ITEM_DIMENSIONS + position);
    }

    public String getItemCreditLine(int position) {
        return getPropertyValue(Literals.ITEM_CREDITLINE + position);
    }

    public String getItemAccessionNumber(int position) {
        return getPropertyValue(Literals.ITEM_ACCESSIONNUMBER + position);
    }

    public String getItemDepartment(int position) {
        return getPropertyValue(Literals.ITEM_DEPARTMENT + position);
    }

    public String getItemDateAcquired(int position) {
        return getPropertyValue(Literals.ITEM_DATEACQUIRED + position);
    }

    public String getItemCataloged(int position) {
        return getPropertyValue(Literals.ITEM_CATALOGED + position);
    }

    public String getItemDepth(int position) {
        return getPropertyValue(Literals.ITEM_DEPTH + position);
    }

    public String getItemDiameter(int position) {
        return getPropertyValue(Literals.ITEM_DIAMETER + position);
    }

    public String getItemHeight(int position) {
        return getPropertyValue(Literals.ITEM_HEIGHT + position);
    }

    public String getItemWeight(int position) {
        return getPropertyValue(Literals.ITEM_WEIGHT + position);
    }

    public String getItemWidth(int position) {
        return getPropertyValue(Literals.ITEM_WIDTH + position);
    }

    public String getItemRoom(int position) {
        return getPropertyValue(Literals.ITEM_ROOM + position);
    }

    public String getVertexLabel(int position) {
        return getPropertyValue(Literals.VERTEX_LABEL + position);
    }

    public String getVertexXY(int position) {
        return getPropertyValue(Literals.VERTEX_XY + position);
    }
}
