package es.unizar.recommendation.contextaware.trajectory;

import java.io.File;

/**
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class DataAccessRoomFile extends DataAccess {

    public DataAccessRoomFile(File file) {
        super(file);
    }

    public String getName() {
        return getPropertyValue(Literals.NAME);
    }

    public int getNumberOfRoom() {
        return Integer.valueOf(getPropertyValue(Literals.NUMBER_ROOM));
    }

    public String getRoomLabel(int roomPosition) {
        return getPropertyValue(Literals.ROOM_LABEL + roomPosition);
    }

    public String getRoomCorner(int cornerPosition, int roomPosition) {
        return getPropertyValue(Literals.ROOM_CORNER + cornerPosition + "_" + roomPosition);
    }

    public int getRoomNumberDoor(int roomPosition) {
        return Integer.valueOf(getPropertyValue(Literals.ROOM_NUMBER_DOOR + roomPosition));
    }

    public String getRoomDoorXY(int doorPosition, int roomPosition) {
        return getPropertyValue(Literals.ROOM_DOOR_XY + doorPosition + "_" + roomPosition);
    }

    public String getRoomStairs() {
        return getPropertyValue(Literals.ROOM_STAIRS_XY);
    }

    public int getNumberConnectedDoor() {
        return Integer.valueOf(getPropertyValue(Literals.NUMBER_CONNECTED_DOOR));
    }

    public String getConnectedDoor(int position) {
        return getPropertyValue(Literals.CONNECTED_DOOR + position);
    }

    public int getNumberConnectedDoorStairs() {
        return Integer.valueOf(getPropertyValue(Literals.NUMBER_CONNECTED_DOOR_STAIRS));
    }

    public String getConnectedDoorStairs(int position) {
        return getPropertyValue(Literals.CONNECTED_DOOR_STAIRS + position);
    }
}
