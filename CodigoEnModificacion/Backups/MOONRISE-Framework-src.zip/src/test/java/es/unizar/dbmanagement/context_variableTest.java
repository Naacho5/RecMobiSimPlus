package es.unizar.dbmanagement;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class context_variableTest {

	public static File file = new File("");
	public static final String PATH = file.getAbsolutePath() + File.separatorChar + "src" + File.separatorChar + "test" + File.separatorChar + "resources" + File.separatorChar + "DB" + File.separatorChar + "datasetMuseum" + File.separatorChar;
	public static final String CONTEXT_FILE = "context.csv";

	@Test
	public void insertOneTest() throws SQLException, IOException {
		context_variable table = new context_variable(DBInformation.DB_MUSEUM_PATH);
		BufferedReader br = new BufferedReader(new FileReader(new File(PATH + CONTEXT_FILE)));
		String line = br.readLine();
		while ((line = br.readLine()) != null) {
			String[] array = line.split(";");
			int id_context = Integer.valueOf(array[0]).intValue();
			for (int i = 1; i < array.length; i++) {
				int id_variable = Integer.valueOf(table.selectIdVariableFromValue(array[i])).intValue();
				table.insertOne(id_context, id_variable);
			}
		}
		br.close();
	}
}
