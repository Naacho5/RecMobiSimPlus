package es.unizar.dbmanagement;

import java.sql.SQLException;

import org.junit.Test;

import es.unizar.properties.DBInformation;

public class ca_profile_attributeTest {

	@Test
	public void insertOneTest() throws SQLException {
		ca_profile_attribute table = new ca_profile_attribute(DBInformation.DB_MUSEUM_PATH);
		table.insertOne(1, "walking");
		table.insertOne(2, "bicycle");
		table.insertOne(3, "car");
		table.insertOne(4, "public");
	}
}
