package es.unizar.recommendation;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.apache.mahout.cf.taste.common.Refreshable;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.FastIDSet;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.impl.recommender.AbstractRecommender;
import org.apache.mahout.cf.taste.impl.recommender.GenericRecommendedItem;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.model.PreferenceArray;
import org.apache.mahout.cf.taste.recommender.IDRescorer;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.common.RandomUtils;

import com.google.common.collect.Lists;

/**
 * Es la implementacion de Mahout pero mejorado porque daba problemas:repite el mismo items varias veces, y no trata el problema en el que inicialmente no haya items para recomendar.
 * 
 * @author Maria del Carmen Rodriguez Hernandez
 *
 */
public final class RandomBasedRecommendation extends AbstractRecommender {
	private final Random random = RandomUtils.getRandom();
	private final float minPref;
	private final float maxPref;

	public RandomBasedRecommendation(DataModel dataModel) throws TasteException {
		super(dataModel);
		float maxPref = (1.0F / -1.0F);
		float minPref = (1.0F / 1.0F);
		LongPrimitiveIterator userIterator = dataModel.getUserIDs();
		while (userIterator.hasNext()) {
			long userID = ((Long) userIterator.next()).longValue();
			PreferenceArray prefs = dataModel.getPreferencesFromUser(userID);
			for (int i = 0; i < prefs.length(); ++i) {
				float prefValue = prefs.getValue(i);
				if (prefValue < minPref) {
					minPref = prefValue;
				}
				if (prefValue > maxPref) {
					maxPref = prefValue;
				}
			}
		}
		this.minPref = minPref;
		this.maxPref = maxPref;
	}

	public List<RecommendedItem> recommend(long userID, int howMany, IDRescorer rescorer) throws TasteException {
		DataModel dataModel = getDataModel();
		int numItems = dataModel.getNumItems();
		List<RecommendedItem> result = Lists.newArrayListWithCapacity(howMany);

		// Items seen by the current user
		FastIDSet items = dataModel.getItemIDsFromUser(userID);
		int count = 0;
		if (items.size() == 1) {
			long item = items.iterator().nextLong();
			LongPrimitiveIterator userIDs = dataModel.getUserIDs();
			while (userIDs.hasNext()) {
				long user = userIDs.nextLong();
				if (dataModel.getItemIDsFromUser(user).contains(item)) {
					count++;
				}
			}
			if (count == dataModel.getNumUsers()) {
				howMany = 0;
			}
		}

		while (result.size() < howMany) {
			LongPrimitiveIterator it = dataModel.getItemIDs();
			it.skip(this.random.nextInt(numItems));
			long itemID = ((Long) it.next()).longValue();
			if ((dataModel.getPreferenceValue(userID, itemID) == null)) {
				result.add(new GenericRecommendedItem(itemID, randomPref()));
			}
		}

		List<RecommendedItem> resultFiltered = new LinkedList<>();
		for (int i = 0; i < result.size(); i++) {
			RecommendedItem recommendedItem = result.get(i);
			long item = recommendedItem.getItemID();
			if (resultFiltered.isEmpty() || !ifContains(resultFiltered, item)) {
				resultFiltered.add(recommendedItem);
			}
		}
		return resultFiltered;
	}

	private boolean ifContains(List<RecommendedItem> result, long itemID) {
		boolean contains = false;
		for (int i = 0; i < result.size(); i++) {
			if (result.get(i).getItemID() == itemID) {
				contains = true;
				break;
			}
		}
		return contains;
	}

	public float estimatePreference(long userID, long itemID) {
		return randomPref();
	}

	private float randomPref() {
		return (this.minPref + this.random.nextFloat() * (this.maxPref - this.minPref));
	}

	public void refresh(Collection<Refreshable> alreadyRefreshed) {
		getDataModel().refresh(alreadyRefreshed);
	}
}
