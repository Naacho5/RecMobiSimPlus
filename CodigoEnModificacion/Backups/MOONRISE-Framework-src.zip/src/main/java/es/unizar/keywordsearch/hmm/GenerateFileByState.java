/*
 * @(#)Context.java  1.0.0  12/11/15
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI-ARTIGAS, SERGIO <silarri[3]unizar.es>
 *  TRILLO LADO, RAQUEL <raqueltl[3]unizar.es>
 *  GUERRA, FRANCESCO <francesco.guerra[3]unimore.it>
 */
package es.unizar.keywordsearch.hmm;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import es.unizar.keywordsearch.preprocessing.PreprocessingText;
import es.unizar.properties.HMMFileInformation;

/**
 * Generates a file by state.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class GenerateFileByState {

    private Map<String, Map<String, List<String>>> observationMap;
    private PreprocessingText preprocessing;

    public GenerateFileByState(List<String> dbURLlist) throws SQLException {
        this.preprocessing = new PreprocessingText();
        ItemFeaturesFromSeveralDatabase fromSeveralDB = new ItemFeaturesFromSeveralDatabase();
        fromSeveralDB.getItemFeatureValuesMapFromSeveralDB(dbURLlist);
        this.observationMap = fromSeveralDB.itemFeaturesMap;
    }

    /**
     * Gets the observation map.
     *
     * @return The observation map.
     */
    public Map<String, Map<String, List<String>>> getObservationMap() {
        return observationMap;
    }

    /**
     * Sets the observation map.
     *
     * @param observationMap The new observation map.
     */
    public void setObservationMap(Map<String, Map<String, List<String>>> observationMap) {
        this.observationMap = observationMap;
    }

    /**
     * Preprocessing the observation map. Removing the stopwords and unknown
     * values.
     *
     * @param stopWordsPath
     * @throws FileNotFoundException
     * @throws IOException
     */
    public void preprocessingObservationMap(String stopWordsPath) throws FileNotFoundException, IOException {
        TreeMap<String, Map<String, List<String>>> newObservationMap = new TreeMap<String, Map<String, List<String>>>();
        for (Map.Entry<String, Map<String, List<String>>> entry : observationMap.entrySet()) {
            String itemType = entry.getKey();
            Map<String, List<String>> featureNamesValuesMap = observationMap.get(itemType);
            //Write in file the item type preprocessing.
            String itemTypeFinal = preprocessing.preprocessingText(itemType, stopWordsPath);

            Map<String, List<String>> featureNamesValuesMapFinal = new TreeMap<String, List<String>>();
            for (Map.Entry<String, List<String>> entry1 : featureNamesValuesMap.entrySet()) {
                String name = entry1.getKey();
                //Write in file the feature name preprocessing.
                String nameFinal = preprocessing.preprocessingText(name, stopWordsPath);

                List<String> valuesList = featureNamesValuesMap.get(name);
                List<String> valuesListFinal = new LinkedList<String>();
                for (int i = 0; i < valuesList.size(); i++) {
                    String value = valuesList.get(i);
                    //To avoid the null or -1 values.
                    if (!value.equalsIgnoreCase("-1") && !value.equalsIgnoreCase("null")) {
                        //Write in file the feature name preprocessing.
                        String valueFinal = preprocessing.preprocessingText(value, stopWordsPath);
                        valuesListFinal.add(valueFinal);
                    }
                }
                featureNamesValuesMapFinal.put(nameFinal, valuesListFinal);
            }
            newObservationMap.put(itemTypeFinal, featureNamesValuesMapFinal);
        }
        setObservationMap(newObservationMap);
    }

    /**
     * Generates the files with values by feature.
     *
     * @param stopWordsPath The stopwords file path.
     * @param outputFilesPath The output file path.
     * @throws FileNotFoundException
     * @throws IOException
     */
    public void generateFileByFeature() throws FileNotFoundException, IOException {
        preprocessingObservationMap(HMMFileInformation.STOPWORDS_PATH);
        RandomAccessFile pw = null;

        for (Map.Entry<String, Map<String, List<String>>> entry : observationMap.entrySet()) {
            String itemType = entry.getKey();
            Map<String, List<String>> featureNamesValuesMap = observationMap.get(itemType);

            for (Map.Entry<String, List<String>> entry1 : featureNamesValuesMap.entrySet()) {
                String name = entry1.getKey();
                pw = new RandomAccessFile(new File(HMMFileInformation.PATH + itemType + "_" + name + ".txt"), "rw");
                if (name.equalsIgnoreCase("title") || name.equalsIgnoreCase("band")) {
                    if (itemType.contains(" ")) {
                        itemType = itemType.replaceAll(" ", "-");
                    }
                    pw.writeBytes(itemType + "\n");
                } else {
                    if (name.contains(" ")) {
                        name = name.replaceAll(" ", "-");
                    }
                    pw.writeBytes(name + "\n");
                }
                List<String> valuesList = featureNamesValuesMap.get(name);

                for (int i = 0; i < valuesList.size(); i++) {
                    String value = valuesList.get(i);
                    if (value.contains(" ")) {
                        value = value.replaceAll(" ", "-");
                    }
                    pw.writeBytes(value + "\n");
                }
            }
        }
    }
}
