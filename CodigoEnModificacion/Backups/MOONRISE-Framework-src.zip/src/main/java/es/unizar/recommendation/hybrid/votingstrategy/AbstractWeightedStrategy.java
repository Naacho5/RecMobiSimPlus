/*
 * @(#)Context.java  1.0.0  3/08/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation.hybrid.votingstrategy;

import java.util.List;

/**
 *
 * Are useful for certain hybridization strategies such as “merging�?.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public abstract class AbstractWeightedStrategy {

    public List<DataStrategy> dataVotingStrategieList;

    public AbstractWeightedStrategy(List<DataStrategy> dataVotingStrategieList) {
        this.dataVotingStrategieList = dataVotingStrategieList;
    }

    /**
     *
     */
    public void verifyCoefficient() {
        float sum = 0;
        for (int i = 0; i < dataVotingStrategieList.size(); i++) {
            DataStrategy hybridData = dataVotingStrategieList.get(i);
            sum += hybridData.getCoefficient();
        }
        if (sum != 1) {
            System.out.println("Debe lanzar una excepción pues la suma de los coeficientes debe ser 1");
            //throw NullPointerException; //Crear yo una exception
        }
    }

    public abstract float executeStrategie(long userId, long itemId);
}
