/*
 * @(#)Context.java  1.0.0  2/06/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation.hybrid;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.apache.mahout.cf.taste.common.Refreshable;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.FastIDSet;
import org.apache.mahout.cf.taste.impl.recommender.AbstractRecommender;
import org.apache.mahout.cf.taste.impl.recommender.TopItems;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.model.PreferenceArray;
import org.apache.mahout.cf.taste.recommender.IDRescorer;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;

import es.unizar.recommendation.hybrid.votingstrategy.AbstractWeightedStrategy;

/**
 * Produces popularity-based recommendations and preference estimates.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class WeightedHybridRecommendation extends AbstractRecommender {

    private AbstractWeightedStrategy votingStrategie;

    public WeightedHybridRecommendation(AbstractWeightedStrategy votingStrategie, DataModel dataModel) {
        super(dataModel);
        this.votingStrategie = votingStrategie;
    }

    @Override
    public List<RecommendedItem> recommend(long userId, int howMany, IDRescorer rescorer) throws TasteException {
        PreferenceArray preferencesFromUser = getDataModel().getPreferencesFromUser(userId);
        if (preferencesFromUser.length() == 0) {
            return Collections.emptyList();
        }
        FastIDSet possibleItemIDs = getAllOtherItems(userId, preferencesFromUser);
        TopItems.Estimator<Long> estimator = new Estimator(userId, preferencesFromUser);
        List<RecommendedItem> topItems = TopItems.getTopItems(howMany, possibleItemIDs.iterator(), rescorer, estimator);
        return topItems;
    }

    @Override
    public float estimatePreference(long userId, long itemId) throws TasteException {
        PreferenceArray preferencesFromUser = getDataModel().getPreferencesFromUser(userId);
        Float actualPref = getPreferenceForItem(preferencesFromUser, itemId);
        if (actualPref != null) {
            return actualPref;
        }
        return doEstimatePreference(userId, preferencesFromUser, itemId);
    }

    @Override
    public void refresh(Collection<Refreshable> alreadyRefreshed) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private static Float getPreferenceForItem(PreferenceArray preferencesFromUser, long itemId) {
        int size = preferencesFromUser.length();
        for (int i = 0; i < size; i++) {
            if (preferencesFromUser.getItemID(i) == itemId) {
                return preferencesFromUser.getValue(i);
            }
        }
        return null;
    }

    /**
     *
     * @param userId
     * @param preferencesFromUser
     * @param itemId
     * @return
     * @throws TasteException
     */
    protected float doEstimatePreference(long userId, PreferenceArray preferencesFromUser, long itemId) throws TasteException {
        return votingStrategie.executeStrategie(userId, itemId);
    }

    private final class Estimator implements TopItems.Estimator<Long> {

        private final long userId;
        private final PreferenceArray preferencesFromUser;

        private Estimator(long userId, PreferenceArray preferencesFromUser) {
            this.userId = userId;
            this.preferencesFromUser = preferencesFromUser;
        }

        @Override
        public double estimate(Long itemId) throws TasteException {
            return doEstimatePreference(userId, preferencesFromUser, itemId);
        }
    }
}
