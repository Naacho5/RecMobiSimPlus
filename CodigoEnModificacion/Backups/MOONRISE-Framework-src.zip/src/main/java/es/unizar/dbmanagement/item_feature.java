package es.unizar.dbmanagement;

import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.repositorymanager.DBConnection;

/**
 * tb: item_feature, att: id_item, name, value
 * 
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class item_feature extends DBConnection {

	private static final Logger log = LoggerFactory.getLogger(item_feature.class);

	public item_feature(String dbURL) {
		super(dbURL);
	}

	public void insertOne(int id_item, String name, String value) {
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			statement.executeUpdate("INSERT INTO item_feature VALUES('" + id_item + "','" + name + "','" + value + "')");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
