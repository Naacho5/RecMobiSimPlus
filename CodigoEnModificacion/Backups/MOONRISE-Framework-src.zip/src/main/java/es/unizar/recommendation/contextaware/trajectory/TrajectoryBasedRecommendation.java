package es.unizar.recommendation.contextaware.trajectory;

public class TrajectoryBasedRecommendation {

}
