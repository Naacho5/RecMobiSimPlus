/*
 * @(#)Context.java  1.0.0  27/09/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation;

import com.google.common.base.Preconditions;

import es.unizar.userprofileandcontextmanager.DBDataModel;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.common.Weighting;

/**
 * The cosine similarity for the content-based recommendation.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public final class CosineSimilarity extends AbstractCosineSimilarity {

    public CosineSimilarity(DBDataModel dataModel, Weighting weighting, boolean centerData) throws TasteException {
        super(dataModel, weighting, centerData);
        Preconditions.checkArgument(dataModel.hasPreferenceValues(), "DataModel doesn't have preference values");
    }

    @Override
    double computeResult(int n, double sumXY, double sumX2, double sumY2, double sumXYdiff2) {
        if (n == 0) {
            return Double.NaN;
        }
        double denominator = Math.sqrt(sumX2) * Math.sqrt(sumY2);
        if (denominator == 0.0) {
            // One or both parties has -all- the same ratings;
            // can't really say much similarity under this measure
            return Double.NaN;
        }
        return sumXY / denominator;
    }
}
