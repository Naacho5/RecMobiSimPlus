package es.unizar.dbmanagement;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.repositorymanager.DBConnection;

/**
 * tb: , att:
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class user_item_context extends DBConnection {

	private static final Logger log = LoggerFactory.getLogger(user_item_context.class);

	public user_item_context(String dbURL) {
		super(dbURL);
	}

	public boolean insertOne(long id_user, long id_item, long id_context, double rating, String opinion,
			int user_provided) {
		boolean ifInsertOK = true;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			statement.executeUpdate("INSERT INTO user_item_context VALUES('" + id_user + "','" + id_item + "','"
					+ id_context + "','" + rating + "','" + opinion + "','" + user_provided + "')");
		} catch (ClassNotFoundException | SQLException e) {
			ifInsertOK = false;
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ifInsertOK;
	}

	public boolean verifyIfExist(long id_user, long id_item, long id_context, double rating) {
		ResultSet result = null;
		boolean exist = false;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			result = statement
					.executeQuery("SELECT * FROM user_item_context WHERE id_user = '" + id_user + "' and id_item='"
							+ id_item + "' and id_context='" + id_context + "' and rating='" + rating + "'");
			if (result.next()) {
				exist = true;
			} else {
				exist = false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return exist;
	}

}
