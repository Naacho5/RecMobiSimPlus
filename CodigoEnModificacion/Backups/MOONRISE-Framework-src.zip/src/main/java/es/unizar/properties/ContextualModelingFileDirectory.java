package es.unizar.properties;

import java.io.File;

/**
 * The path of the directory of files (one file is a knowledge base by user) for
 * the Contextual Modeling Based-Pull Recommendation.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class ContextualModelingFileDirectory {

	public static final File file = new File("");
	public static final String KNOWLEDGE_BASES_DIRECTORY_PATH = file.getAbsolutePath() + File.separatorChar + "src"
			+ File.separatorChar + "test" + File.separatorChar + "resources" + File.separatorChar + "CMfiles"
			+ File.separatorChar;
}
