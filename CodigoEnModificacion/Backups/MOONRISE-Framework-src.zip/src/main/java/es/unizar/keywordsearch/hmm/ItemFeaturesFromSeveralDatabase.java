/*
 * @(#)Context.java  1.0.0  28/09/15
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI-ARTIGAS, SERGIO <silarri[3]unizar.es>
 *  TRILLO LADO, RAQUEL <raqueltl[3]unizar.es>
 *  GUERRA, FRANCESCO <francesco.guerra[3]unimore.it>
 */
package es.unizar.keywordsearch.hmm;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class ItemFeaturesFromSeveralDatabase {

	public Map<String, Map<String, List<String>>> itemFeaturesMap;

	public ItemFeaturesFromSeveralDatabase() {
		this.itemFeaturesMap = new TreeMap<String, Map<String, List<String>>>();
	}

	/**
	 * Includes the item type and the map by database (with the names and values
	 * of the features) in the map.
	 *
	 * @param dbURLlist
	 *            The list of database paths.
	 * @throws SQLException
	 */
	public void getItemFeatureValuesMapFromSeveralDB(List<String> dbURLlist) throws SQLException {
		for (int i = 0; i < dbURLlist.size(); i++) {
			// Gets the item type.
			String dbURL = dbURLlist.get(i);
			String array[] = dbURL.split("_");
			String nameItemType = array[1].substring(0, array[1].length() - 3);

			// Includes the item type and the map by database (with the names
			// and values of the features) in the map.
			ItemFeaturesFromOneDatabase oneDB = new ItemFeaturesFromOneDatabase(dbURL);
			oneDB.getItemFeatureValuesMapFromOneDB();
			itemFeaturesMap.put(nameItemType, oneDB.itemFeaturesMap);
		}
		// printTreeMap();
	}

	public void printTreeMap() {
		for (Map.Entry<String, Map<String, List<String>>> entry : itemFeaturesMap.entrySet()) {
			String itemType = entry.getKey();
			System.out.println(itemType);
			Map<String, List<String>> featureNamesValuesMap = itemFeaturesMap.get(itemType);

			for (Map.Entry<String, List<String>> entry1 : featureNamesValuesMap.entrySet()) {
				String name = entry1.getKey();
				System.out.println(name);
				List<String> valuesList = featureNamesValuesMap.get(name);

				for (int i = 0; i < valuesList.size(); i++) {
					String value = valuesList.get(i);
					System.out.println(value);
				}
			}
		}
	}
	// public static void main(String[] args) throws SQLException {
	// ItemFeaturesFromSeveralDatabase ii = new
	// ItemFeaturesFromSeveralDatabase();
	// String dbURL_music =
	// "jdbc:sqlite:/USERS/Maria/10-HMM/framework/DB/db_music.db";
	// String dbURL_film =
	// "jdbc:sqlite:/USERS/Maria/10-HMM/framework/DB/db_film.db";
	// LinkedList<String> dbURLlist = new LinkedList<String>();
	// dbURLlist.add(dbURL_music);
	// dbURLlist.add(dbURL_film);
	// ii.getItemFeatureValuesMapFromSeveralDB(dbURLlist);
	// }
}
