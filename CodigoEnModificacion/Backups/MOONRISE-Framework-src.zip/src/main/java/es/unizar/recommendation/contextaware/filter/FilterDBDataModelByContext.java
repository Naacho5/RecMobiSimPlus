/*
 * @(#)Context.java  1.0.0  13/10/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation.contextaware.filter;

import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.FastByIDMap;
import org.apache.mahout.cf.taste.impl.common.FastIDSet;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.impl.model.GenericItemPreferenceArray;
import org.apache.mahout.cf.taste.impl.model.GenericUserPreferenceArray;
import org.apache.mahout.cf.taste.model.Preference;
import org.apache.mahout.cf.taste.model.PreferenceArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

import es.unizar.userprofileandcontextmanager.DBDataModel;
import es.unizar.userprofileandcontextmanager.DBDataModelFilteredByContext;

/**
 * Filters a data model, by using the contextual information introduced for the
 * user.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class FilterDBDataModelByContext {

	private static final Logger log = LoggerFactory.getLogger(FilterDBDataModelByContext.class);

	private DBDataModel dataModel;
	private DBDataModelFilteredByContext dataModelFilteredByContext;

	public FilterDBDataModelByContext(DBDataModel dataModel, List<String> context, double similarityThreshold)
			throws TasteException, SQLException {
		this.dataModel = dataModel;
		this.setDataModelFilteredByContext(getDBDataModelFilteredByContext(context, similarityThreshold));
	}

	private DBDataModelFilteredByContext getDBDataModelFilteredByContext(List<String> contextVariableValues,
			double similarityThreshold) throws TasteException, SQLException {
		// Obtain all variable names
		List<String> variableNames = dataModel.getVariableNames();

		// Current user:
		List<String> currentUserVariables = new LinkedList<String>();
		for (int i = 0; i < variableNames.size(); i++) {
			currentUserVariables.add("unknown");
		}
		String currentUserVariableName = null;
		for (int i = 0; i < contextVariableValues.size(); i++) {
			String currentUserVariableValue = contextVariableValues.get(i);
			List<String> variableNamesByValue = dataModel.getVariableNames(currentUserVariableValue);
			if (variableNamesByValue.size() == 1) {
				currentUserVariableName = ((LinkedList<String>) variableNamesByValue).getFirst();
			} else {
				// See what to choose. Can to exist several variable names with
				// the same value.
			}
			int pos = variableNames.indexOf(currentUserVariableName);
			currentUserVariables.set(pos, currentUserVariableValue);
		}

		// Puts in the DBDataModelFilteredByContext
		List<Long> userIDList = new LinkedList<Long>();
		List<Long> itemIDList = new LinkedList<Long>();
		FastByIDMap<PreferenceArray> preferenceFromUsers = new FastByIDMap<PreferenceArray>();
		PreferenceArray preferenceArray = null;

		// Another users:
		List<String> anotherUserVariables = new LinkedList<String>();
		for (int i = 0; i < variableNames.size(); i++) {
			anotherUserVariables.add("unknown");
		}
		LongPrimitiveIterator userIDs = dataModel.getUserIDs();
		double similarity = 0;
		double distanceTotal = 0;
		String valueX = null;
		String valueY = null;
		double distanceVariables = 0;
		double weight = 0;
		int k = 0;
		long userID = 0;
		while (userIDs.hasNext()) {
			userID = userIDs.nextLong();
			FastIDSet itemIDs = dataModel.getItemIDsFromUser(userID);
			preferenceArray = new GenericUserPreferenceArray(itemIDs.size());
			for (int i = 0; i < itemIDs.toArray().length; i++) {
				long itemID = itemIDs.toArray()[i];
				log.debug("user-item: " + userID + "-" + itemID);
				List<String> variableNameAndValueList = dataModel.getVariableNameAndValue(userID, itemID);
				for (int j = 0; j < variableNameAndValueList.size(); j++) {
					String variableName = variableNameAndValueList.get(j).split("__")[0];
					String variableValue = variableNameAndValueList.get(j).split("__")[1];
					int pos = variableNames.indexOf(variableName);
					anotherUserVariables.set(pos, variableValue);
				}

				// similarity
				for (int j = 0; j < anotherUserVariables.size(); j++) {
					valueX = anotherUserVariables.get(j);
					valueY = currentUserVariables.get(j);
					distanceVariables = distanceVariableValues(valueX, valueY);
					weight = Double.valueOf(dataModel.getVariableNameAndWeight(userID).get(j).split("__")[1]);
					distanceTotal += distanceVariables * weight;
				}
				similarity = 1 - distanceTotal;
				distanceTotal = 0;

				if (similarity >= similarityThreshold) {
					// DBdataModel filtered
					float rating = dataModel.getPreferenceValue(userID, itemID);
					// Avoid users repeated
					if (userIDList.isEmpty()) {
						userIDList.add(userID);
					} else {
						if (!userIDList.contains(userID)) {
							userIDList.add(userID);
						}
					}

					// Avoid users repeated
					if (itemIDList.isEmpty()) {
						itemIDList.add(itemID);
					} else {
						if (!itemIDList.contains(itemID)) {
							itemIDList.add(itemID);
						}
					}

					preferenceArray.setUserID(k, userID);
					preferenceArray.setItemID(k, itemID);
					preferenceArray.setValue(k, rating);
					k++;

					anotherUserVariables = new LinkedList<String>();
					for (int j = 0; j < variableNames.size(); j++) {
						anotherUserVariables.add("unknown");
					}
				}
			}
			preferenceFromUsers.put(userID, preferenceArray);
			k = 0;
		}

		FastByIDMap<Collection<Preference>> prefsForItems = new FastByIDMap<Collection<Preference>>();
		FastIDSet itemIDSet = new FastIDSet();
		float maxPrefValue = Float.NEGATIVE_INFINITY;
		float minPrefValue = Float.POSITIVE_INFINITY;
		for (Map.Entry<Long, PreferenceArray> entry : preferenceFromUsers.entrySet()) {
			PreferenceArray prefs = entry.getValue();
			prefs.sortByItem();
			for (Preference preference : prefs) {
				long itemID = preference.getItemID();
				itemIDSet.add(itemID);
				Collection<Preference> prefsForItem = prefsForItems.get(itemID);
				if (prefsForItem == null) {
					prefsForItem = Lists.newArrayListWithCapacity(2);
					prefsForItems.put(itemID, prefsForItem);
				}
				prefsForItem.add(preference);
				float value = preference.getValue();
				if (value > maxPrefValue) {
					maxPrefValue = value;
				}
				if (value < minPrefValue) {
					minPrefValue = value;
				}
			}
		}
		FastByIDMap<PreferenceArray> preferenceForItems = toDataMap(prefsForItems, false);
		long[] userIDArray = listToArray(userIDList);
		long[] itemIDArray = listToArray(itemIDList);
		return new DBDataModelFilteredByContext(userIDArray, itemIDArray, preferenceFromUsers, preferenceForItems);
	}

	public long[] listToArray(List<Long> list) {
		long[] array = new long[list.size()];
		for (int i = 0; i < list.size(); i++) {
			array[i] = list.get(i).longValue();
		}
		return array;
	}

	/**
	 * Determine the distance between the variable value and the current
	 * variable value.
	 *
	 * @param variableValue
	 * @param variableValueCurrent
	 * @return the distance between the variable value and the current variable
	 *         value.
	 */
	public double distanceVariableValues(String variableValue, String variableValueCurrent) {
		double distance = -1;
		// If "a" similar "b"
		if (dataModel.distanceSoftVariableValues(variableValue, variableValueCurrent) != -1) {
			distance = dataModel.distanceSoftVariableValues(variableValue, variableValueCurrent);
		} else {
			// If "a" == "b" or "unknown" == "unknown"
			if (variableValue.equalsIgnoreCase(variableValueCurrent)) {
				distance = 0;
			} else {
				// If "a" != "b" or "a" != "unknown"
				distance = 1;
			}
		}
		return distance;
	}

	/**
	 * Swaps, in-place, {@link List}s for arrays in {@link Map} values .
	 *
	 * @param data
	 * @param byUser
	 * @return input value
	 */
	@SuppressWarnings("unchecked")
	public static FastByIDMap<PreferenceArray> toDataMap(FastByIDMap<Collection<Preference>> data, boolean byUser) {
		for (Map.Entry<Long, Object> entry : ((FastByIDMap<Object>) (FastByIDMap<?>) data).entrySet()) {
			List<Preference> prefList = (List<Preference>) entry.getValue();
			entry.setValue(
					byUser ? new GenericUserPreferenceArray(prefList) : new GenericItemPreferenceArray(prefList));
		}
		return (FastByIDMap<PreferenceArray>) (FastByIDMap<?>) data;
	}

	public DBDataModelFilteredByContext getDataModelFilteredByContext() {
		return dataModelFilteredByContext;
	}

	public void setDataModelFilteredByContext(DBDataModelFilteredByContext dataModelFilteredByContext) {
		this.dataModelFilteredByContext = dataModelFilteredByContext;
	}
}
