/*
 * @(#)Context.java  1.0.0  14/10/15
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI-ARTIGAS, SERGIO <silarri[3]unizar.es>
 *  TRILLO LADO, RAQUEL <raqueltl[3]unizar.es>
 *  GUERRA, FRANCESCO <francesco.guerra[3]unimore.it>
 */
package es.unizar.keywordsearch.preprocessing;

import java.io.IOException;

/**
 * Text preprocessing.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class PreprocessingText {

    /**
     * Preprocesing of the input text.
     *
     * @param textToPreprocess The input text.
     * @param stopWordsPath
     * @return The new text preprocessing.
     * @throws IOException
     */
    public String preprocessingText(String textToPreprocess, String stopWordsPath) throws IOException {
        QueryPreprocesing query = new QueryPreprocesing();
        String outputText = query.standardFilter(textToPreprocess, stopWordsPath);
        return outputText;
    }
}
