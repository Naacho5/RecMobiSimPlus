/*
 * @(#)Context.java  1.0.0 8/04/15
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI-ARTIGAS, SERGIO <silarri[3]unizar.es>
 *  TRILLO LADO, RAQUEL <raqueltl[3]unizar.es>
 *  GUERRA, FRANCESCO <francesco.guerra[3]unimore.it>
 */
package es.unizar.keywordsearch.hmm;

/**
 * Enumeration of type of items being considered.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public enum States {

    film_director,
    film_country,
    film_language,
    film_year,
    film_genre1,
    film_genre2,
    film_genre3,
    film_actor1,
    film_actor2,
    film_actor3,
    film_budget,
    film_title,
    music_artist,
    music_category,
    music_title,
    book_isbn,
    book_title,
    book_author,
    book_year,
    book_publisher,
    concert_date,
    concert_city,
    concert_state,
    concert_latitude,
    concert_longitude,
    concert_venue,
    concert_band,
    restaurant_accessibility,
    restaurant_address,
    restaurant_alcohol,
    restaurant_ambience,
    restaurant_area,
    restaurant_city,
    restaurant_country,
    restaurant_cuisine,
    restaurant_days,
    restaurant_dress,
    restaurant_franchise,
    restaurant_hours,
    restaurant_latitude,
    restaurant_longitude,
    restaurant_name,
    restaurant_services,
    restaurant_parking,
    restaurant_payment,
    restaurant_price,
    restaurant_smoking,
    restaurant_state,
    restaurant_zip,
    app_category,
    app_developer,
    app_downloads,
    app_language,
    app_name,
    app_package,
    app_rating,
}
