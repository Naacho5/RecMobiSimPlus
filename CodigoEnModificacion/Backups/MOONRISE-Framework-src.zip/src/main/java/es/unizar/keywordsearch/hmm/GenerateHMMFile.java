/*
 * @(#)Context.java  1.0.0  28/09/15
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI-ARTIGAS, SERGIO <silarri[3]unizar.es>
 *  TRILLO LADO, RAQUEL <raqueltl[3]unizar.es>
 *  GUERRA, FRANCESCO <francesco.guerra[3]unimore.it>
 */
package es.unizar.keywordsearch.hmm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.TreeMap;

import es.unizar.keywordsearch.preprocessing.PreprocessingText;
import es.unizar.properties.HMMFileInformation;

/**
 *
 * @author María del Carmen Rodríguez-Hernández
 */
public class GenerateHMMFile {

    private PreprocessingText preprocessing;

    public GenerateHMMFile() {
        this.preprocessing = new PreprocessingText();
    }

    /**
     * Concatenates the values of the vector A (the state transition
     * probabilities).
     *
     * @param vector The vector A with values to concatenate.
     * @return The string concetenated.
     */
    public String concatenateVectorA(LinkedList<Double> vector) {
        DecimalFormat df = new DecimalFormat("#.######");
        String textConcatenated = String.valueOf(df.format(Double.valueOf(vector.getFirst())).replace(",", "."));
        for (int i = 1; i < vector.size(); i++) {
            textConcatenated += " " + df.format(Double.valueOf(vector.getFirst())).replace(",", ".");
        }
        return textConcatenated;
    }

    /**
     * Concatenates the values of the vector B (the observation probabilities).
     *
     * @param vector The vector B with values to concatenate.
     * @return The string concetenated.
     */
    public String concatenateVectorB(LinkedList<Double> vector) {
        DecimalFormat df = new DecimalFormat("#.######");
        String textConcatenated = "[" + String.valueOf(df.format(Double.valueOf(vector.getFirst())).replace(",", "."));
//        String textConcatenated = "[" + vector.getFirst();
        for (int i = 1; i < vector.size(); i++) {
            textConcatenated += " " + df.format(Double.valueOf(vector.get(i))).replace(",", ".");
//            textConcatenated += " " + vector.get(i);
        }
        textConcatenated += " ]";
        return textConcatenated;
    }

    /**
     * Gets the vector Pi (the initial state probabilities).
     *
     * @param numberStates The number of states.
     * @return The vector Pi.
     */
    public LinkedList<Double> getVectorPi(int numberStates) {
        LinkedList<Double> vectorPi = new LinkedList<Double>();
        double value = 0;
        for (int i = 0; i < numberStates; i++) {
            value = (double) 1 / (double) numberStates;
            vectorPi.add(value);
        }
        return vectorPi;
    }

    /**
     * Gets the vector A (the state transition probabilities).
     *
     * @param numberStates The number of states.
     * @return The vector A.
     */
    public LinkedList<Double> getVectorA(int numberStates) {
        LinkedList<Double> vectorA = getVectorPi(numberStates);
        return vectorA;
    }

    /**
     * Gets the vector B (the observation probabilities) with equiprobable
     * values.
     *
     * @param numberObservations The number of observations.
     * @return The vector B.
     */
    public LinkedList<Double> getVectorB(int numberObservations) {
        LinkedList<Double> vectorB = new LinkedList<Double>();
        double value = 0;
        for (int i = 0; i < numberObservations; i++) {
            value = (double) 1 / (double) numberObservations;
            vectorB.add(value);
        }
        return vectorB;
    }

    /**
     *
     * @param vectorBmap
     * @param state
     * @return
     * @throws SQLException
     * @throws FileNotFoundException
     * @throws IOException
     */
    public LinkedList<Double> getVectorB(TreeMap<Integer, LinkedList<Double>> vectorBmap, int state) throws SQLException, FileNotFoundException, IOException {
        return vectorBmap.get(state);
    }

    /**
     * Gets the vector B (the observation probabilities).
     *
     * @param observationFilePath
     * @param filePath
     * @return The vector B.
     * @throws SQLException
     * @throws FileNotFoundException
     * @throws IOException
     */
    public TreeMap<Integer, LinkedList<Double>> getVectorBmap(String observationFilePath, String filePath) throws SQLException, FileNotFoundException, IOException {
        TreeMap<Integer, LinkedList<Double>> vectorBMap = new TreeMap<Integer, LinkedList<Double>>();
        int numberObservations = getNumberObservations(observationFilePath);
        LinkedList<Double> vectorB = new LinkedList<Double>();

        //Modifies the values of the vector.
        TreeMap<Integer, Integer> numberObservatioByStateMap = getNumberObservationByState(filePath);
        ManageStates mStates = new ManageStates();
        int numberStates = mStates.numberStates;
        LinkedList<String> statesList = mStates.statesList;

        //First iteration:
        int posInitial = 0;
        int numberIemType = mStates.stateItemTypeMap.get(statesList.get(posInitial));
        int count = numberObservatioByStateMap.get(0);
        int posFinal = count;
        int sum = count;
        //Initially the vector contain 0.
        for (int k = 0; k < numberObservations; k++) {
            vectorB.add(0.0);
        }
        double value = (double) 1 / (double) (count + 1);
        for (int j = posInitial; j < posFinal; j++) {
            vectorB.set(j, value);
        }
        vectorB.set(numberObservations - numberIemType, value);
        vectorBMap.put(0, vectorB);

        //Remaining iterations:
        for (int i = 1; i < numberStates; i++) {
            vectorB = new LinkedList<Double>();
            //Initially the vector contain 0.
            for (int k = 0; k < numberObservations; k++) {
                vectorB.add(0.0);
            }
            count = numberObservatioByStateMap.get(i);
            posInitial = posFinal;
            sum += count;
            posFinal = sum;
            value = (double) 1 / (double) (count + 1);
            for (int j = posInitial; j < posFinal; j++) {
                vectorB.set(j, value);
            }
            numberIemType = mStates.stateItemTypeMap.get(statesList.get(i));
            vectorB.set(numberObservations - numberIemType, value);
            vectorBMap.put(i, vectorB);
        }
        return vectorBMap;
    }

    /**
     * Gets a map with the number of observations by state.
     *
     * @param filePath The path where are the files related with the states.
     * @return A map with the number of observations by state.
     * @throws FileNotFoundException
     * @throws IOException
     */
    public TreeMap<Integer, Integer> getNumberObservationByState(String filePath) throws FileNotFoundException, IOException {
        TreeMap<Integer, Integer> numberObservatioByStateMap = new TreeMap<Integer, Integer>();
        States array[] = States.values();
        for (int i = 0; i < array.length; i++) {
            String state = array[i].name();
            String itemType = state.split("_")[0];
            String feature = state.split("_")[1];
            String itemTypePreprocessed = preprocessing.preprocessingText(itemType, HMMFileInformation.STOPWORDS_PATH);
            String featurePreprocessed = preprocessing.preprocessingText(feature, HMMFileInformation.STOPWORDS_PATH);
            File file = new File(filePath + itemTypePreprocessed + "_" + featurePreprocessed + ".txt");
            int count = getCountValuesByState(file);
            numberObservatioByStateMap.put(i, count);
        }
        return numberObservatioByStateMap;
    }

    /**
     * Gets the number of observation into observation file.
     *
     * @param observationFilePath The observation file path.
     * @return The number of observation into observation file.
     * @throws FileNotFoundException
     * @throws IOException
     */
    public int getNumberObservations(String observationFilePath) throws FileNotFoundException, IOException, FileNotFoundException, FileNotFoundException, FileNotFoundException, FileNotFoundException {
        BufferedReader br = new BufferedReader(new FileReader(new File(observationFilePath)));
        int numberOfObservation = 0;
        while ((br.readLine()) != null) {
            numberOfObservation++;
        }
        br.close();
        return numberOfObservation;
    }

    /**
     *
     * @param filePath
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public Hashtable<String, LinkedList<String>> getObservationsHash(String filePath) throws FileNotFoundException, IOException {
        Hashtable<String, LinkedList<String>> hash = new Hashtable<String, LinkedList<String>>();
        States array[] = States.values();
        String line;
        for (int i = 0; i < array.length; i++) {
            String state = array[i].name();

            LinkedList<String> values = new LinkedList<String>();
            BufferedReader br = new BufferedReader(new FileReader(new File(filePath + state + ".txt")));
            while ((line = br.readLine()) != null) {
                values.add(line);
            }
            hash.put(state, values);
            br.close();
        }
        return hash;
    }

    /**
     *
     * @param file
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public int getCountValuesByState(File file) throws FileNotFoundException, IOException {
        int pos = 0;
        BufferedReader br = new BufferedReader(new FileReader(file));
        while ((br.readLine()) != null) {
            pos++;
        }
        br.close();
        return pos;
    }

    /**
     * Generates the HMM model file.
     *
     * @param hmmFilePath
     * @param observationFilePath
     * @throws FileNotFoundException
     * @throws IOException
     * @throws SQLException
     */
    public void generateHMMModelFile(String hmmFilePath, String observationFilePath) throws FileNotFoundException, IOException, SQLException {
        File HMMmodelFile = new File(hmmFilePath);
        if (HMMmodelFile.exists()) {
            HMMmodelFile.delete();
        }
        RandomAccessFile pw = new RandomAccessFile(HMMmodelFile, "rw");
        //Header
        pw.writeBytes("Hmm v1.0" + "\n");
        pw.writeBytes("\n");
        //Number of satates
        int numberStates = States.values().length;
        pw.writeBytes("NbStates " + numberStates + "\n");
        pw.writeBytes("\n");
        LinkedList<Double> vectorPi = getVectorPi(numberStates);
        DecimalFormat df = new DecimalFormat("#.######");
        for (int s = 0; s < numberStates; s++) {
            //Pi: the initial state probability.
            double Pi = vectorPi.get(s);
            //A: the state transition probabilities.
            LinkedList<Double> vectorA = getVectorA(numberStates);
            String A = concatenateVectorA(vectorA);
            //B: the observation probabilities.
            int numberObservations = getNumberObservations(observationFilePath);
            LinkedList<Double> vectorB = getVectorB(numberObservations);
            String B = concatenateVectorB(vectorB);
            //Write in file.
            pw.writeBytes("State" + "\n");
            pw.writeBytes("Pi " + df.format(Pi).replace(",", ".") + "\n");
            pw.writeBytes("A " + A + "\n");
            pw.writeBytes("IntegerOPDF " + B + "\n");
            pw.writeBytes("\n");
            pw.writeBytes("\n");
        }
        pw.close();
    }

    /**
     * Generates the HMM model file.
     *
     * @param hmmFilePath
     * @param observationFilePath
     * @param filePath
     * @throws FileNotFoundException
     * @throws IOException
     * @throws SQLException
     */
    public void generateHMMModelFile(String hmmFilePath, String observationFilePath, String filePath) throws FileNotFoundException, IOException, SQLException {
        File HMMmodelFile = new File(hmmFilePath);
        if (HMMmodelFile.exists()) {
            HMMmodelFile.delete();
        }
        RandomAccessFile pw = new RandomAccessFile(HMMmodelFile, "rw");
        //Header
        pw.writeBytes("Hmm v1.0" + "\n");
        pw.writeBytes("\n");
        //Number of satates
        int numberStates = States.values().length;
        pw.writeBytes("NbStates " + numberStates + "\n");
        pw.writeBytes("\n");

        TreeMap<Integer, LinkedList<Double>> vectorBmap = getVectorBmap(observationFilePath, filePath);
        LinkedList<Double> vectorPi = getVectorPi(numberStates);
        DecimalFormat df = new DecimalFormat("#.######");
        for (int s = 0; s < numberStates; s++) {
            //Pi: the initial state probability.
            double Pi = vectorPi.get(s);
            //A: the state transition probabilities.
            LinkedList<Double> vectorA = getVectorA(numberStates);
            String A = concatenateVectorA(vectorA);
            //B: the observation probabilities.
            LinkedList<Double> vectorB = getVectorB(vectorBmap, s);
            String B = concatenateVectorB(vectorB);
            //Write in file.
            pw.writeBytes("State" + "\n");
            pw.writeBytes("Pi " + df.format(Pi).replace(",", ".") + "\n");
            pw.writeBytes("A " + A + "\n");
            pw.writeBytes("IntegerOPDF " + B + "\n");
            pw.writeBytes("\n");
            pw.writeBytes("\n");
        }
        pw.close();
    }

    /**
     * Updates in the HMM the weights (not modified) automatically.
     *
     * @param hmmFilePath The old HMM file path.
     * @param newHmmFilePath The current HMM file path;
     * @throws FileNotFoundException
     * @throws IOException
     */
    public void adjustWeights(String hmmFilePath, String newHmmFilePath) throws FileNotFoundException, IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File(hmmFilePath)));
        RandomAccessFile pw = new RandomAccessFile(newHmmFilePath, "rw");
        DecimalFormat df = new DecimalFormat("#.######");
        String line = null;
        while ((line = br.readLine()) != null) {
            if (line.contains("IntegerOPDF")) {
                line = line.replace("IntegerOPDF [", "");
                line = line.replace(" ]", "");
                String[] arrayWithAll = line.split(" ");
                LinkedList<Double> listWithRelevantData = new LinkedList<Double>();

                for (int i = 0; i < arrayWithAll.length; i++) {
                    String value = arrayWithAll[i];
                    if (!value.equalsIgnoreCase("0")) {
                        listWithRelevantData.add(Double.valueOf(value));
                    }
                }

                double valueModified = getHighestWeight(listWithRelevantData);
                int numberValueModified = getNumberValueModified(listWithRelevantData, valueModified);

                double currentWeight = valueModified * numberValueModified;
                double oldWeight = getLowestWeight(listWithRelevantData);
                double rest = 0;
                double restTemp = 0;
                double sumWeightsNoModified = getSumOldWeights(listWithRelevantData, oldWeight);

                if (currentWeight > oldWeight) {
                    rest = currentWeight - (oldWeight * numberValueModified);
                    restTemp = sumWeightsNoModified - rest;
                } else {
                    rest = (oldWeight * numberValueModified) - currentWeight;
                    restTemp = sumWeightsNoModified + rest;
                }

                for (int i = 0; i < arrayWithAll.length; i++) {
                    double value = Double.valueOf(arrayWithAll[i]);
                    if (value == oldWeight) {
                        arrayWithAll[i] = String.valueOf((oldWeight * restTemp) / sumWeightsNoModified);
                    }
                }


                String lineUpdated = "IntegerOPDF [";
                for (int i = 0; i < arrayWithAll.length; i++) {
                    String valueUpdated = String.valueOf(df.format(Double.valueOf(arrayWithAll[i]))).replace(",", ".");
                    lineUpdated += valueUpdated + " ";
                }
                lineUpdated += "]";
                pw.writeBytes(lineUpdated + "\n");
                System.out.println(lineUpdated);
            } else {
                pw.writeBytes(line + "\n");
                System.out.println(line);
            }
        }
        br.close();
        pw.close();
    }

    /**
     * Gets the highest value.
     *
     * @param listWithRelevantData The list with the relevant values (or
     * nonzero).
     * @return The highest value.
     */
    public double getHighestWeight(LinkedList<Double> listWithRelevantData) {
        double highestWeight = 0;
        for (int i = 0; i < listWithRelevantData.size(); i++) {
            double value = listWithRelevantData.get(i);
            if (value > highestWeight) {
                highestWeight = value;
            }
        }
        return highestWeight;
    }

    /**
     * Gets the highest value.
     *
     * @param listWithRelevantData The list with the relevant values (or
     * nonzero).
     * @return The highest value.
     */
    public double getLowestWeight(LinkedList<Double> listWithRelevantData) {
        double lowestWeight = 2;
        for (int i = 0; i < listWithRelevantData.size(); i++) {
            double value = listWithRelevantData.get(i);
            if (value < lowestWeight) {
                lowestWeight = value;
            }
        }
        return lowestWeight;
    }

    /**
     * Gets the number of values modified.
     *
     * @param listWithRelevantData The list with the relevant values (or
     * nonzero).
     * @param valueModified The value modified.
     * @return The number of values modified.
     */
    public int getNumberValueModified(LinkedList<Double> listWithRelevantData, double valueModified) {
        int numberValueModified = 0;
        for (int i = 0; i < listWithRelevantData.size(); i++) {
            double value = listWithRelevantData.get(i);
            if (value == valueModified) {
                numberValueModified++;
            }
        }
        return numberValueModified;
    }

    /**
     * Gets the sum of the old weights.
     *
     * @param listWithRelevantData The list with the relevant values (or
     * nonzero).
     * @param oldWeight The old weight.
     * @return The sum of the old weights.
     */
    public double getSumOldWeights(LinkedList<Double> listWithRelevantData, double oldWeight) {
        double sumOldWeights = 0;
        for (int i = 0; i < listWithRelevantData.size(); i++) {
            double value = listWithRelevantData.get(i);
            if (value == oldWeight) {
                sumOldWeights += value;
            }
        }
        return sumOldWeights;
    }
}
