/*
 * @(#)Context.java  1.0.0  28/09/15
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI-ARTIGAS, SERGIO <silarri[3]unizar.es>
 *  TRILLO LADO, RAQUEL <raqueltl[3]unizar.es>
 *  GUERRA, FRANCESCO <francesco.guerra[3]unimore.it>
 */
package es.unizar.keywordsearch.hmm;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import es.unizar.repositorymanager.DataAccessLayer;

/**
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class ItemFeaturesFromOneDatabase {

    public Map<String, List<String>> itemFeaturesMap;
    public DataAccessLayer dataAccessLayer;
    public String dbURL;

    public ItemFeaturesFromOneDatabase(String dbURL) {
        this.dbURL = dbURL;
        this.dataAccessLayer = new DataAccessLayer(dbURL);
        this.itemFeaturesMap = new TreeMap<String, List<String>>();
    }

    /**
     * Gets a TreeMap with the item feature names (like the key) and the item
     * features values.
     *
     * @param dbURL The path of the current database.
     * @return A TreeMap with the item feature names (like the key) and the item
     * features values.
     * @throws SQLException
     */
    public void getItemFeatureValuesMapFromOneDB() throws SQLException {
        //Includes the names and values of the features in the map.
        List<String> nameFeatureList = dataAccessLayer.getFeatureNames();
        for (int i = 0; i < nameFeatureList.size(); i++) {
            String nameFeature = nameFeatureList.get(i);
            List<String> itemValuesFromFeaturesList = dataAccessLayer.getFeatureValueFromFeatureName(nameFeature);
            itemFeaturesMap.put(nameFeature, itemValuesFromFeaturesList);
        }
    }
}
