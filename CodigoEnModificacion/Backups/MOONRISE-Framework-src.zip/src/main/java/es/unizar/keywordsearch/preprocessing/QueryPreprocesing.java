/*
 * @(#)Context.java  1.0.0  8/04/15
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI-ARTIGAS, SERGIO <silarri[3]unizar.es>
 *  TRILLO LADO, RAQUEL <raqueltl[3]unizar.es>
 *  GUERRA, FRANCESCO <francesco.guerra[3]unimore.it>
 */
package es.unizar.keywordsearch.preprocessing;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.analysis.StopAnalyzer;
import org.apache.lucene.analysis.Token;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.snowball.SnowballFilter;
import org.apache.lucene.analysis.standard.StandardAnalyzer;

/**
 *
 * @author María del Carmen Rodríguez-Hernández
 */
public class QueryPreprocesing {

    /**
     * Is a standard filter but also includes the number and double quotation.
     *
     * @param keywords The keywords.
     * @param stopwordsNameFile The file name that contain the list of
     * stopwords.
     * @return The keywords filtered.
     * @throws IOException
     */
    @SuppressWarnings("deprecation")
	public String quotationFilter(String keywords, String stopwordsNameFile) throws IOException {
        String keywordFiltered = "";
        //Input of the keywords
        StringReader reader = new StringReader(keywords);
        //File with the stopwords
        File stopwordsFile = new File(stopwordsNameFile);
        //Apply the analyzer: LowerCaseFilter and StopFilter
        Analyzer analizador = new KeywordsearchAnalyzer(stopwordsFile);
        TokenStream stream = analizador.tokenStream("", reader);
        Token token = stream.next();
        while (token != null) {
            keywordFiltered = keywordFiltered + " " + token.termText() + " ";
            keywordFiltered = keywordFiltered.trim();
            token = stream.next();
        }
        return keywordFiltered;
    }

    /**
     * An Analyzer that filters LetterTokenizer with LowerCaseFilter and
     * StopFilter from the given reader. It is Lucene’s most sophisticated core
     * analyzer. It has quite a bit of logic to identify certain kinds of
     * tokens, such as company names, email addresses, and host names. It also
     * lowercases each token and removes stop words.
     *
     * @param keywords The keywords.
     * @param stopwordsNameFile The file name that contain the list of
     * stopwords.
     * @return The keywords filtered.
     * @throws IOException
     */
    @SuppressWarnings("deprecation")
	public String standardFilter(String keywords, String stopwordsNameFile) throws IOException {
        String keywordFiltered = "";
        //Input of the keywords
        StringReader reader = new StringReader(keywords);
        //File with the stopwords
        File stopwordsFile = new File(stopwordsNameFile);
        //Apply the analyzer: LowerCaseFilter and StopFilter
        Analyzer analizador = new StandardAnalyzer(stopwordsFile);
        TokenStream stream = analizador.tokenStream("", reader);
        stream = new SnowballFilter(stream, "English");
        Token token = stream.next();
        while (token != null) {
            keywordFiltered = keywordFiltered + " " + token.termText() + " ";
            keywordFiltered = keywordFiltered.trim();
            token = stream.next();
        }
        return keywordFiltered;
    }

    /**
     * Filters LetterTokenizer with LowerCaseFilter and StopFilter. It is the
     * same as SimpleAnalyzer, except it removes common words (called stop
     * words, described more in section XXX). By default it removes common words
     * in the English language (the, a, etc.), though you can pass in your own
     * set.
     *
     * @param keywords The keywords.
     * @param stopwordsNameFile The file name that contain the list of
     * stopwords.
     * @return The keywords filtered.
     * @throws IOException
     */
    @SuppressWarnings("deprecation")
	public String stopwordsFilter(String keywords, String stopwordsNameFile) throws IOException {
        String keywordFiltered = "";

        //Input of the keywords
        StringReader reader = new StringReader(keywords);

        //File with the stopwords
        File stopwordsFile = new File(stopwordsNameFile);

        //Apply the analyzer: LowerCaseFilter and StopFilter
        Analyzer analizador = new StopAnalyzer(stopwordsFile);
        TokenStream stream = analizador.tokenStream("", reader);
        Token token = stream.next();
        while (token != null) {
            keywordFiltered = keywordFiltered + " " + token.termText() + " ";
            keywordFiltered = keywordFiltered.trim();
            token = stream.next();
        }
        return keywordFiltered;
    }

    /**
     * An Analyzer that filters LetterTokenizer with LowerCaseFilter. First
     * splits tokens at non-letter characters, then lowercases each token. Be
     * careful! This analyzer quietly discards numeric characters.
     *
     * @param keywords The keywords.
     * @param stopwordsNameFile The file name that contain the list of
     * stopwords.
     * @return The keywords filtered.
     * @throws IOException
     */
    @SuppressWarnings("deprecation")
	public String simpleFilter(String keywords, String stopwordsNameFile) throws IOException {
        String keywordFiltered = "";
        //Input of the keywords
        StringReader reader = new StringReader(keywords);
        //Apply the analyzer: LowerCaseFilter and StopFilter
        Analyzer analizador = new SimpleAnalyzer();
        TokenStream stream = analizador.tokenStream("", reader);
        Token token = stream.next();
        while (token != null) {
            keywordFiltered = keywordFiltered + " " + token.termText() + " ";
            keywordFiltered = keywordFiltered.trim();
            token = stream.next();
        }
        return keywordFiltered;
    }

    /**
     * Extract a substring between double quotes.
     *
     * @param keywords The keywords.
     * @return A substring between double quotes.
     */
    public String extractSubstringWithQuotation(String keywords) {
        Pattern p = Pattern.compile(".*\\\"(.*)\\\".*");
        Matcher matcher = p.matcher(keywords);
        String quotation = null;
        if (matcher.find()) {
            quotation = matcher.group(1);
        }
        return quotation;
    }

    /**
     * Extract a list with several substring between double quotes.
     *
     * @param keywords The keywords.
     * @return A list with several substring between double quotes.
     */
    public ArrayList<String> extractSeveralSubstringWithQuotation(String keywords, String stopWordsPath) throws IOException {
        Pattern regex = Pattern.compile("\"([^\"]*)\"");
        ArrayList<String> allMatchesTemp = new ArrayList<String>();
        ArrayList<String> allMatches = new ArrayList<String>();
        Matcher matcher = regex.matcher(keywords);
        while (matcher.find()) {
            allMatchesTemp.add(matcher.group(1));
        }
        for (int i = 0; i < allMatchesTemp.size(); i++) {
            String value = allMatchesTemp.get(i);
            value = preprocessingText(value, stopWordsPath);
            allMatches.add(value);
        }
        return allMatches;
    }

    /**
     * Replaces a substring with double quotation by dashes in the whitespaces.
     *
     * @param keywords The keywords.
     * @return The keywords with dashes.
     */
    public String replaceOneQuotationByDashes(String keywords) {
        String wordsWithQuotation = extractSubstringWithQuotation(keywords);
        if (wordsWithQuotation != null) {
            wordsWithQuotation = wordsWithQuotation.replaceAll(" ", "-");
        } else {
            wordsWithQuotation = "";
        }

        String array[] = keywords.split(" ");
        String tokenStream = array[0];
        int cont = 0;
        if (tokenStream.contains("\"")) {
            tokenStream = wordsWithQuotation;
            cont = wordsWithQuotation.split("-").length;
        } else {
            cont = 1;
        }

        int contFinal = array.length;
        while (cont != contFinal) {
            String token = array[cont];
            if (token.contains("\"")) {
                tokenStream += " " + wordsWithQuotation;
                cont += wordsWithQuotation.split("-").length;
            } else {
                tokenStream += " " + token;
                cont++;
            }
        }
        return tokenStream;
    }

    /**
     * Replace several substring with double quotation by dashes in the
     * whitespaces.
     *
     * @param keywords The keywords.
     * @return The keywords with dashes.
     */
    public String replaceSeveralQuotationByDashes(String keywords, String stopWordsPath) throws IOException {
        ArrayList<String> wordsWithQuotationTemp = extractSeveralSubstringWithQuotation(keywords, stopWordsPath);
        ArrayList<String> wordsWithQuotation = new ArrayList<String>();

        if (!wordsWithQuotationTemp.isEmpty()) {
            for (int i = 0; i < wordsWithQuotationTemp.size(); i++) {
                String word = wordsWithQuotationTemp.get(i).replaceAll(" ", "-");
                wordsWithQuotation.add(word);
            }
        }

        String array[] = keywords.split(" ");
        String tokenStream = array[0];
        int cont = 0;
        int i = 0;
        if (tokenStream.contains("\"")) {
            tokenStream = wordsWithQuotation.get(0);
            cont = wordsWithQuotation.get(0).split("-").length;
            i++;
        } else {
            cont = 1;
        }

        int contFinal = array.length;
        while (cont != contFinal) {
            String token = array[cont];
            if (token.contains("\"")) {
                tokenStream += " " + wordsWithQuotation.get(i);
                cont += wordsWithQuotation.get(i).split("-").length;
                i++;
            } else {
                tokenStream += " " + token;
                cont++;
            }
        }
        return tokenStream;
    }

    /**
     * Preprocesing of the input text.
     *
     * @param textToPreprocess The input text.
     * @param stopWordsPath
     * @return The new text preprocessing.
     * @throws IOException
     */
    public String preprocessingText(String textToPreprocess, String stopWordsPath) throws IOException {
        QueryPreprocesing query = new QueryPreprocesing();
        String outputText = query.standardFilter(textToPreprocess, stopWordsPath);
        return outputText;
    }
}
