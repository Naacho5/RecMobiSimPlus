package es.unizar.properties;

import java.io.File;

/**
 * URL of the database.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class DBInformation {

	public static final File file = new File("");
	public static final String DB_PATH = "jdbc:sqlite:" + File.separatorChar + file.getAbsolutePath() + File.separatorChar + "src" + File.separatorChar + "test" + File.separatorChar + "resources"	+ File.separatorChar + "DB" + File.separatorChar;
	public static final String DB_FILM_PATH = DB_PATH + "db_film.db";
	public static final String DB_MUSIC_PATH = DB_PATH + "db_music.db";
	public static final String DB_RESTAURANT_PATH = DB_PATH + "db_restaurant.db";
	public static final String DB_CONCERT_PATH = DB_PATH + "db_concert.db";
	public static final String DB_BOOK_PATH = DB_PATH + "db_book.db";
	public static final String DB_APP_PATH = DB_PATH + "db_app.db";
	public static final String DB_POI_PATH = DB_PATH + "database_Dataset_POI.db";
	
	
	public static final String DB_MUSEUM_PATH = DB_PATH + "db_museum.db";
	public static final String DB_USER_PATH = DB_PATH + "db_user.db";
}
