/*
 * @(#)Context.java  1.0.0  13/10/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation.contextaware.filter;

import java.sql.SQLException;
import java.util.List;

import be.ac.ulg.montefiore.run.jahmm.Hmm;
import be.ac.ulg.montefiore.run.jahmm.ObservationInteger;
import es.unizar.keywordsearch.hmm.KeywordSearchHMM;
import es.unizar.keywordsearch.preprocessing.QueryPreprocesing;
import es.unizar.properties.HMMFileInformation;
import es.unizar.userprofileandcontextmanager.DBDataModel;

/**
 * Filters the data models, by using the item type obtained from the user query.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class FilterDBDataModelsByItemType {

	public String itemType;
	private DBDataModel dataModelFilteredByItemType;
	private List<String> databasePaths;

	public FilterDBDataModelsByItemType(String userQuery, List<String> databasePaths) throws Exception {
		this.databasePaths = databasePaths;
		this.itemType = getItemType(userQuery);
		this.setDataModelFilteredByItemType(getDBDataModelFilteredByItemType());
	}

	private String getItemType(String userQuery) throws Exception {
		KeywordSearchHMM keywordSearch = new KeywordSearchHMM(HMMFileInformation.OBSERVATIONS_PATH, HMMFileInformation.HMM_PATH);
		// HMM model
		Hmm<ObservationInteger> hmm = keywordSearch.buildFromHmmFile();
		// Preprocesing of the keywords query
		QueryPreprocesing query = new QueryPreprocesing();
		String stopwordsFile = HMMFileInformation.STOPWORDS_PATH;
		// Algorithm Viterbi
		String keywordFiltered = query.quotationFilter(userQuery, stopwordsFile);
		String keywordFilteredFinal = query.replaceSeveralQuotationByDashes(keywordFiltered, stopwordsFile);
		String sequenceStates = keywordSearch.tagSentence(keywordFilteredFinal, hmm);

		String sequenceSatesWithoutDuplicates = keywordSearch.deleteDuplicates(sequenceStates);
		return keywordSearch.itemTypeMoreRelevant(sequenceSatesWithoutDuplicates);
	}

	private DBDataModel getDBDataModelFilteredByItemType() throws SQLException {
		DBDataModel newDataModel = null;
		for (int i = 0; i < databasePaths.size(); i++) {
			String database = databasePaths.get(i);
			String fileName = database.substring(database.lastIndexOf('/') + 1, database.lastIndexOf('.'));
			if (fileName.contains(itemType.split("_")[0])) {
				newDataModel = new DBDataModel(database);
				break;
			}
		}
		return newDataModel;
	}

	public DBDataModel getDataModelFilteredByItemType() {
		return dataModelFilteredByItemType;
	}

	public void setDataModelFilteredByItemType(DBDataModel dataModelFilteredByItemType) {
		this.dataModelFilteredByItemType = dataModelFilteredByItemType;
	}
}
