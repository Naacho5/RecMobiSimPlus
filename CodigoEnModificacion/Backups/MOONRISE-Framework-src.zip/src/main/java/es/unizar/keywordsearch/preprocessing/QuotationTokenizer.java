/*
 * @(#)Context.java  1.0.0  14/10/15
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI-ARTIGAS, SERGIO <silarri[3]unizar.es>
 *  TRILLO LADO, RAQUEL <raqueltl[3]unizar.es>
 *  GUERRA, FRANCESCO <francesco.guerra[3]unimore.it>
 */
package es.unizar.keywordsearch.preprocessing;

import java.io.Reader;
import org.apache.lucene.analysis.CharTokenizer;

/**
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class QuotationTokenizer extends CharTokenizer {

    /**
     * Construct a new QuotationTokenizer.
     *
     * @param input The reader.
     */
    public QuotationTokenizer(Reader input) {
        super(input);
    }

    /**
     * Collects only characters which satisfy the conditions specified.
     *
     * @param c The char specified.
     * @return Characters which satisfy the conditions specified.
     */
    @Override
    protected boolean isTokenChar(char c) {
        return Character.isLetter(c) || c == '"' || Character.isDigit(c);
    }
}
