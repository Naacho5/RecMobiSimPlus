package es.unizar.dbmanagement;

import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.repositorymanager.DBConnection;

/**
 * tb: feature, att: name
 * 
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class feature extends DBConnection {

	private static final Logger log = LoggerFactory.getLogger(feature.class);

	public feature(String dbURL) {
		super(dbURL);
	}

	public void insertOne(String name) {
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			statement.executeUpdate("INSERT INTO feature VALUES('" + name + "')");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
