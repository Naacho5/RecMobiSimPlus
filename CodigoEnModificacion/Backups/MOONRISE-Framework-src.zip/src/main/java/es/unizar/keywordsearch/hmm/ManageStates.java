/*
 * @(#)Context.java  1.0.0 8/04/15
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI-ARTIGAS, SERGIO <silarri[3]unizar.es>
 *  TRILLO LADO, RAQUEL <raqueltl[3]unizar.es>
 *  GUERRA, FRANCESCO <francesco.guerra[3]unimore.it>
 */
package es.unizar.keywordsearch.hmm;

import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

/**
 * Gets information about states.
 *
 * @author María del Carmen Rodríguez-Hernández
 */
public final class ManageStates {

    public LinkedList<String> statesList;
    public LinkedList<String> itemTypeList;
    public int numberStates;
    public TreeMap<String, Integer> stateItemTypeMap;

    public ManageStates() {
        this.statesList = new LinkedList<String>();
        this.getStateList();
        itemTypeList = new LinkedList<String>();
        this.getItemTypeList();
        this.numberStates = getNumberOfStates();
        this.stateItemTypeMap = new TreeMap<String, Integer>();
        getStateItemTypeMap();
    }

    /**
     * Gets a list with the states.
     */
    private void getStateList() {
        States[] arraySates = States.values();
        for (int i = 0; i < arraySates.length; i++) {
            String state = arraySates[i].name();
            if (statesList.isEmpty()) {
                statesList.add(state);
            } else {
                if (!statesList.contains(state)) {
                    statesList.add(state);
                }
            }
        }
    }

    /**
     * Gets a list with item types.
     */
    private void getItemTypeList() {
        for (int i = 0; i < statesList.size(); i++) {
            String itemType = statesList.get(i).split("_")[0];
            if (itemTypeList.isEmpty()) {
                itemTypeList.add(itemType);
            } else {
                if (!itemTypeList.contains(itemType)) {
                    itemTypeList.add(itemType);
                }
            }
        }
    }

    /**
     * Gets the number of states.
     *
     * @return The number of states.
     */
    private int getNumberOfStates() {
        int numberOfSates = 0;
        numberOfSates = statesList.size();
        return numberOfSates;
    }

    /**
     * Gets a map with the states and the identifier of the item type.
     */
    public void getStateItemTypeMap() {
        for (int i = 0; i < statesList.size(); i++) {
            stateItemTypeMap.put(statesList.get(i), 0);
        }

        for (int j = 0; j < itemTypeList.size(); j++) {
            String itemType = itemTypeList.get(j);

            for (Map.Entry<String, Integer> entry : stateItemTypeMap.entrySet()) {
                String state = entry.getKey();

                if (state.contains(itemType)) {
                    stateItemTypeMap.put(state, itemTypeList.size() - j);
                }
            }
        }
    }
}
