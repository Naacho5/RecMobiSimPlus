package es.unizar.dbmanagement;

import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.repositorymanager.DBConnection;

/**
 * tb: , att:
 * 
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class user_variable_name extends DBConnection {

	private static final Logger log = LoggerFactory.getLogger(user_variable_name.class);

	public user_variable_name(String dbURL) {
		super(dbURL);
	}

	public void insertOne(int id_user, String name, double weight) {
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			statement.executeUpdate(
					"INSERT INTO user_variable_name VALUES('" + id_user + "','" + name + "','" + weight + "')");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
