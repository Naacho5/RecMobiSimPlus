/*
 * @(#)Context.java  1.0.0  27/09/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation;

import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.mahout.cf.taste.common.Refreshable;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.common.Weighting;
import org.apache.mahout.cf.taste.impl.common.RefreshHelper;
import org.apache.mahout.cf.taste.impl.similarity.AbstractItemSimilarity;
import org.apache.mahout.cf.taste.similarity.ItemSimilarity;
import org.apache.mahout.cf.taste.similarity.PreferenceInferrer;

import es.unizar.userprofileandcontextmanager.DBDataModel;

/**
 * The cosine similarity for the content-based recommendation.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public abstract class AbstractCosineSimilarity extends AbstractItemSimilarity implements ItemSimilarity {

    public DBDataModel dataModel;
    private boolean centerData;
    @SuppressWarnings("unused")
	private int cachedNumItems;
    private int cachedNumUsers;
    private final boolean weighted;
    private PreferenceInferrer inferrer;
    private final RefreshHelper refreshHelper;

    public AbstractCosineSimilarity(final DBDataModel dataModel, Weighting weighting, boolean centerData) throws TasteException {
        super(dataModel);
        this.dataModel = dataModel;
        this.centerData = centerData;
        this.cachedNumItems = dataModel.getNumItems();
        this.weighted = weighting == Weighting.WEIGHTED;
        this.cachedNumItems = dataModel.getNumItems();
        this.cachedNumUsers = dataModel.getNumUsers();
        this.refreshHelper = new RefreshHelper(new Callable<Object>() {
            @Override
            public Object call() throws TasteException {
                cachedNumItems = dataModel.getNumItems();
                cachedNumUsers = dataModel.getNumUsers();
                return null;
            }
        });
    }

    /**
     * Returns the degree of similarity, of two items, based on the preferences
     * that users have expressed for the items.
     *
     * @param itemId1 first item Id
     * @param itemId2 second item Id
     * @return similarity between the items, in [-1,1] or {@link Double#NaN}
     * similarity is unknown
     * @throws TasteException if an error occurs while accessing the data
     */
    @Override
    public double itemSimilarity(long itemId1, long itemId2) throws TasteException {
        double result = 0;
        try {
            //total number of items
            int n = 0;
            //sum of product of item values, over all items by both items
            double sumXY = 0;
            //sum of the square of item values, over the first item
            double sumX2 = 0;
            //sum of the square of the item values, over the second item
            double sumY2 = 0;
            //sum of squares of differences in X and Y values
            double sumXYdiff2 = 0;

            double sumX = 0;
            double sumY = 0;

            LinkedList<Double> vectorFeaturesItemId1 = (LinkedList<Double>) getFeatureVectorFromItem(itemId1);
            LinkedList<Double> vectorFeaturesItemId2 = (LinkedList<Double>) getFeatureVectorFromItem(itemId2);

            n = vectorFeaturesItemId1.size();

            for (int i = 0; i < n; i++) {
                double x = vectorFeaturesItemId1.get(i);
                double y = vectorFeaturesItemId2.get(i);
                sumXY += x * y;
                sumX += x;
                sumX2 += x * x;
                sumY += y;
                sumY2 += y * y;

                double diff = x - y;
                sumXYdiff2 += diff * diff;
            }

            if (centerData) {
                double meanX = sumX / n;
                double meanY = sumY / n;

                double centeredSumXY = sumXY - meanY * sumX;
                double centeredSumX2 = sumX2 - meanX * sumX;
                double centeredSumY2 = sumY2 - meanY * sumY;
                result = computeResult(n, centeredSumXY, centeredSumX2, centeredSumY2, sumXYdiff2);
            } else {
                result = computeResult(n, sumXY, sumX2, sumY2, sumXYdiff2);
            }
            if (!Double.isNaN(result)) {
                result = normalizeWeightResult(result, n, cachedNumUsers);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AbstractCosineSimilarity.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    final double normalizeWeightResult(double result, int count, int num) {
        double normalizedResult = result;
        if (weighted) {
            double scaleFactor = 1.0 - (double) count / (double) (num + 1);
            if (normalizedResult < 0.0) {
                normalizedResult = -1.0 + scaleFactor * (1.0 + normalizedResult);
            } else {
                normalizedResult = 1.0 - scaleFactor * (1.0 - normalizedResult);
            }
        }
        // Make sure the result is not accidentally a little outside [-1.0, 1.0] due to rounding:
        if (normalizedResult < -1.0) {
            normalizedResult = -1.0;
        } else if (normalizedResult > 1.0) {
            normalizedResult = 1.0;
        }
        return normalizedResult;
    }

    @Override
    public double[] itemSimilarities(long itemId1, long[] itemId2s) throws TasteException {
        int length = itemId2s.length;
        double[] result = new double[length];
        for (int i = 0; i < length; i++) {
            result[i] = itemSimilarity(itemId1, itemId2s[i]);
        }
        return result;
    }

    @Override
    public final void refresh(Collection<Refreshable> alreadyRefreshed) {
        super.refresh(alreadyRefreshed);
        refreshHelper.refresh(alreadyRefreshed);
    }

    @Override
    public final String toString() {
        return this.getClass().getSimpleName() + "[dataModel:" + getDataModel() + ",inferrer:" + inferrer + ']';
    }

    /**
     * Gets the feature vector of an item.
     *
     * @param itemID The item identifier.
     * @return The feature vector of an item.
     * @throws TasteException
     * @throws SQLException
     */
    public List<Double> getFeatureVectorFromItem(long itemID) throws TasteException, SQLException {
        LinkedList<Double> vectorFeatures = new LinkedList<Double>();
        LinkedList<String> itemFeatures = (LinkedList<String>) dataModel.getNamesAndValuesOfFeaturesFromItem(itemID);
        LinkedList<String> vocabularyFeatures = (LinkedList<String>) dataModel.getItemFeatureNames();
        int numFeatures = dataModel.getNumberItemFeatures();
        double weightTF;
        for (int i = 0; i < numFeatures; i++) {
            vectorFeatures.add((double) 0);
        }
        for (int i = 0; i < itemFeatures.size(); i++) {
            weightTF = 0;
            String featureName = itemFeatures.get(i).split("__")[0];
            String termToCheck = itemFeatures.get(i).split("__")[1];
            weightTF = (double) termFrequency(vocabularyFeatures, termToCheck);
            int position = positionFromTerm(itemFeatures, featureName);
            vectorFeatures.set(position, weightTF);
        }
        return vectorFeatures;
    }

    /**
     * Gets the term frequency.
     *
     * @param itemFeatures The item features.
     * @param termToCheck The term to check.
     * @return The term frequency.
     */
    public double termFrequency(List<String> itemFeatures, String termToCheck) {
        double count = 0;
        for (String term : itemFeatures) {
            if (term.equalsIgnoreCase(termToCheck)) {
                count++;
            }
        }
        return count / itemFeatures.size();
    }

    /**
     * Position from the term.
     *
     * @param featureVocabulary The feature vocabulary.
     * @param termToCheck
     * @return The position of the term.
     */
    public int positionFromTerm(LinkedList<String> itemFeatures, String featureName) {
        int i;
        for (i = 0; i < itemFeatures.size(); i++) {
            String feature = itemFeatures.get(i);
            if (feature.split("__")[0].equalsIgnoreCase(featureName)) {
                break;
            }
        }
        return i;
    }

    /**
     * <p> Several subclasses in this package implement this method to actually
     * compute the similarity from figures computed over users or items. Note
     * that the computations in this class "center" the data, such that X and
     * Y's mean are 0. </p>
     *
     * <p> Note that the sum of all X and Y values must then be 0. This value
     * isn't passed down into the standard similarity computations as a result.
     * </p>
     *
     * @param n total number of users or items
     * @param sumXY sum of product of user/item preference values, over all
     * items/users preferred by both users/items
     * @param sumX2 sum of the square of user/item preference values, over the
     * first item/user
     * @param sumY2 sum of the square of the user/item preference values, over
     * the second item/user
     * @param sumXYdiff2 sum of squares of differences in X and Y values
     * @return similarity value between -1.0 and 1.0, inclusive, or
     * {@link Double#NaN} if no similarity can be computed (e.g. when no items
     * have been rated by both users
     */
    abstract double computeResult(int n, double sumXY, double sumX2, double sumY2, double sumXYdiff2);
}
