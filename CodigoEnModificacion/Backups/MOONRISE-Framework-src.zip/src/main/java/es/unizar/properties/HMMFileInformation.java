package es.unizar.properties;

import java.io.File;

/**
 * Paths for HMM.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class HMMFileInformation {

	public static final File file = new File("");
	public static final String PATH = file.getAbsolutePath() + File.separatorChar + "src" + File.separatorChar + "test"
			+ File.separatorChar + "resources" + File.separatorChar + "HMM" + File.separatorChar;

	public static final String OBSERVATIONS_PATH = PATH + "observations.txt";
	public static final String HMM_PATH = PATH + "hmm_model.dat";
	public static final String STOPWORDS_PATH = PATH + "stopwords.txt";
}
