/*
 * @(#)Context.java  1.0.0  3/08/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation.hybrid.votingstrategy;

import org.apache.mahout.cf.taste.recommender.Recommender;

/**
 * Information about the voting strategy.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class DataStrategy {

    private Recommender recommender;
    private float coefficient;

    public DataStrategy(Recommender recommender, float coefficient) {
        this.recommender = recommender;
        this.coefficient = coefficient;
    }

    public Recommender getRecommender() {
        return recommender;
    }

    public float getCoefficient() {
        return coefficient;
    }

    public void setRecommender(Recommender recommender) {
        this.recommender = recommender;
    }

    public void setCoefficient(float coefficient) {
        this.coefficient = coefficient;
    }
}
