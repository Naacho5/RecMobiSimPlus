/*
 * @(#)Context.java  1.0.0  13/10/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation.contextaware;

import java.util.List;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;

import es.unizar.recommendation.SVDBasedRecommendation;
import es.unizar.recommendation.contextaware.filter.FilterDBDataModelByContext;
import es.unizar.userprofileandcontextmanager.DBDataModel;
import es.unizar.userprofileandcontextmanager.DBDataModelFilteredByContext;

/**
 * Pre-filtering based recommendations.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class PrefilteringBasedRecommendation extends FilteringBasedRecommendation {

	private List<String> context;
	private DBDataModelFilteredByContext dataModelFilteredByContext;

	public PrefilteringBasedRecommendation(DBDataModel dataModel, List<String> context, double similarityThreshold) throws Exception {
		super(dataModel, similarityThreshold);
		this.context = context;
		// Filtering by context
		FilterDBDataModelByContext filterByContext = new FilterDBDataModelByContext(dataModel, context, similarityThreshold);
		this.dataModelFilteredByContext = filterByContext.getDataModelFilteredByContext();
		setRecommender(new SVDBasedRecommendation(getDataModelFilteredByContext(), getNumFeatures(), getInitialSteps()));
	}

	@Override
	public List<RecommendedItem> recommend(long userID, int howMany) throws TasteException {
		return getRecommender().recommend(userID, howMany);
	}

	@Override
	public float estimatePreference(long userID, long itemID) throws TasteException {
		return getRecommender().estimatePreference(userID, itemID);
	}

	// Gets and sets:
	public DBDataModelFilteredByContext getDataModelFilteredByContext() {
		return dataModelFilteredByContext;
	}

	public void setDataModelFilteredByContext(DBDataModelFilteredByContext dataModelFilteredByContext) {
		this.dataModelFilteredByContext = dataModelFilteredByContext;
	}

	public List<String> getContext() {
		return context;
	}

	public void setContext(List<String> context) {
		this.context = context;
	}
}
