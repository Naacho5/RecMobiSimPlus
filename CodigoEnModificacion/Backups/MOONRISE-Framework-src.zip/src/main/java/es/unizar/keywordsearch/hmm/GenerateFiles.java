/*
 * @(#)Context.java  1.0.0  13/10/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.keywordsearch.hmm;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import es.unizar.keywordsearch.preprocessing.PreprocessingText;
import es.unizar.properties.HMMFileInformation;

/**
 * Generates the necessary files to apply Viterbi Algorithm.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class GenerateFiles {

    private PreprocessingText preprocessing;

    public GenerateFiles() {
        this.preprocessing = new PreprocessingText();
    }

    public void generateFiles(List<String> databasePaths) throws SQLException, FileNotFoundException, IOException {
        generateFileByState(databasePaths);
        generateObservationFile();
        generateHMMFile();
    }

    private void generateFileByState(List<String> databasePaths) throws SQLException, FileNotFoundException, IOException {
        GenerateFileByState generateFileByState = new GenerateFileByState(databasePaths);
        generateFileByState.generateFileByFeature();
    }

    private void generateObservationFile() throws FileNotFoundException, IOException {
        String observationFilePath = HMMFileInformation.OBSERVATIONS_PATH;
        States stateArray[] = States.values();
        LinkedList<String> pathSeveralFiles = new LinkedList<String>();
        for (int i = 0; i < stateArray.length; i++) {
            String state = stateArray[i].name();
            String itemType = preprocessing.preprocessingText(state.split("_")[0], HMMFileInformation.STOPWORDS_PATH);
            String feature = preprocessing.preprocessingText(state.split("_")[1], HMMFileInformation.STOPWORDS_PATH);
            String statePreprocessed = itemType + "_" + feature;
            pathSeveralFiles.add(HMMFileInformation.PATH + statePreprocessed + ".txt");
        }
        GenerateObservationsFile cof = new GenerateObservationsFile();
        cof.generateObservationsFileFromSeveralFiles(observationFilePath, pathSeveralFiles);
    }

    private void generateHMMFile() throws FileNotFoundException, IOException, SQLException {
        GenerateHMMFile chmm = new GenerateHMMFile();
        chmm.generateHMMModelFile(HMMFileInformation.HMM_PATH, HMMFileInformation.OBSERVATIONS_PATH, HMMFileInformation.PATH);
    }
}
