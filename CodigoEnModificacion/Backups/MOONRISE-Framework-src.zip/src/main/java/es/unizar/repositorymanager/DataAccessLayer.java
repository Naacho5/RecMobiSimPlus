/*
 * @(#)Context.java  1.0.0  27/09/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.repositorymanager;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.mahout.cf.taste.common.TasteException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.util.VariableWeight;

/**
 * Access to the data from a database.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class DataAccessLayer extends DBConnection implements DataAccess {

	private static final Logger log = LoggerFactory.getLogger(DataAccessLayer.class);

	/**
	 * Constructor.
	 *
	 * @param dbURL
	 *            Database URL.
	 */
	public DataAccessLayer(String dbURL) {
		super(dbURL);
	}

	/**
	 * Gets a ResultSet with the information related to an item.
	 *
	 * @param itemId
	 *            Item identifier.
	 * @param columnLabel
	 *            A list with the columns of interest.
	 * @return ResultSet.
	 */
	@Override
	public ResultSet getItemData(long itemId, List<String> columnLabel) {
		ResultSet resultSet = null;
		String subQuery = "item." + columnLabel.get(0);
		for (int i = 1; i < columnLabel.size(); i++) {
			subQuery += ",item." + columnLabel.get(i);
		}
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT " + subQuery + " FROM item WHERE item.id_item = " + itemId);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultSet;
	}

	/**
	 * Gets a list with all the item identifiers.
	 *
	 * @return A list with all the item identifiers.
	 */
	public List<Integer> getItemIDs() {
		ResultSet resultSet = null;
		List<Integer> listOfIdItems = new LinkedList<Integer>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT id_item FROM item");
			while (resultSet.next()) {
				listOfIdItems.add(resultSet.getInt("id_item"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listOfIdItems;
	}

	/**
	 * Gets the number of items.
	 *
	 * @return Number of items.
	 */
	public int getNumberOfItems() {
		int numberOfItems = 0;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			ResultSet resultSet = statement.executeQuery("SELECT count(id_item) as ItemCount FROM item");
			numberOfItems = resultSet.getInt("ItemCount");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return numberOfItems;
	}

	/**
	 * Gets a list with the item names.
	 *
	 * @return A list with the item names.
	 */
	public List<String> getItemTypes() {
		ResultSet resultSet = null;
		List<String> itemNamesList = new LinkedList<String>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT DISTINCT type FROM item");
			while (resultSet.next()) {
				itemNamesList.add(resultSet.getString("type"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return itemNamesList;
	}

	/**
	 * Gets a list with the feature names.
	 *
	 * @return A list with the feature names.
	 */
	public List<String> getFeatureNames() {
		ResultSet resultSet = null;
		List<String> featureNamesList = new LinkedList<String>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT DISTINCT name FROM feature");
			while (resultSet.next()) {
				featureNamesList.add(resultSet.getString("name"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return featureNamesList;
	}

	/**
	 * Gets a list with the values of the item features.
	 *
	 * @return A list with the values of the item features.
	 */
	public List<String> getFeatureValues() {
		ResultSet resultSet = null;
		List<String> ValuesFromItemFeaturesList = new LinkedList<String>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT DISTINCT value FROM item_feature");
			while (resultSet.next()) {
				ValuesFromItemFeaturesList.add(resultSet.getString("value"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ValuesFromItemFeaturesList;
	}

	/**
	 * Gets a list with the item values from the feature name.
	 *
	 * @param nameFeature
	 *            The feature name.
	 * @return A list with the item values from the feature name.
	 */
	public List<String> getFeatureValueFromFeatureName(String nameFeature) {
		ResultSet resultSet = null;
		List<String> itemValueFromFeatureList = new LinkedList<String>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT DISTINCT value FROM item_feature WHERE name == '" + nameFeature + "'");
			while (resultSet.next()) {
				itemValueFromFeatureList.add(resultSet.getString("value"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return itemValueFromFeatureList;
	}

	/**
	 * Gets the number of features.
	 *
	 * @return Number of features.
	 */
	public int getNumberOfFeatures() {
		int numberOfFeatures = 0;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			ResultSet resultSet = statement.executeQuery("SELECT Count(name) as FeatureCount FROM feature");
			numberOfFeatures = resultSet.getInt("FeatureCount");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return numberOfFeatures;
	}

	/**
	 * Gets the feature names of an item.
	 *
	 * @param itemId
	 *            Item identifier.
	 * @return ResultSet.
	 */
	@Override
	public ResultSet getFeatureNamesFromItem(long itemId) {
		ResultSet resultSet = null;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT name FROM item_feature WHERE item_feature.id_item= " + itemId);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultSet;
	}

	/**
	 * Gets a ResultSet with the information related to an user.
	 *
	 * @param userId
	 *            User identifier.
	 * @param columnLabel
	 *            A list with the columns of interest.
	 * @return ResultSet.
	 */
	@Override
	public ResultSet getUserData(long userId, List<String> columnLabel) {
		ResultSet resultSet = null;
		try {
			String subQuery = "user." + columnLabel.get(0);
			for (int i = 1; i < columnLabel.size(); i++) {
				subQuery += ", user." + columnLabel.get(i);
			}
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT " + subQuery + " FROM user WHERE user.id_user = " + userId);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultSet;
	}

	/**
	 * Gets a list with all the user identifiers.
	 *
	 * @return A list with all the user identifiers.
	 */
	public long[] getUserIDs() {
		ResultSet resultSet = null;
		long[] userIDs = new long[getNumberOfUsers()];
		int i = 0;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT id_user FROM user");
			while (resultSet.next()) {
				userIDs[i] = resultSet.getInt("id_user");
				i++;
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userIDs;
	}

	/**
	 * Gets the number of users.
	 *
	 * @return Number of users.
	 */
	public int getNumberOfUsers() {
		int numberOfUsers = 0;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			ResultSet resultSet = statement.executeQuery("SELECT count(id_user) as UserCount FROM user");
			numberOfUsers = resultSet.getInt("UserCount");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return numberOfUsers;
	}

	/**
	 * Gets the users, items and ratings.
	 *
	 * @return ResultSet.
	 */
	@Override
	public List<String> getUserItemRating() {
		List<String> list = new LinkedList<>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			ResultSet resultSet = statement.executeQuery("SELECT id_user,id_item,rating FROM user_item_context");
			while (resultSet.next()) {
				long userID = resultSet.getLong(1);
				long itemID = resultSet.getLong(2);
				float rating = resultSet.getLong(3);
				list.add(userID + ";" + itemID + ";" + rating);
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	/**
	 * Gets the users, items and ratings.
	 *
	 * @return ResultSet.
	 */
	@Override
	public List<String> getUserItemRatingFrom(long userID) {
		List<String> list = new LinkedList<>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			ResultSet resultSet = statement.executeQuery("SELECT id_user,id_item,rating FROM user_item_context WHERE id_user==" + userID);
			while (resultSet.next()) {
				long userId = resultSet.getLong(1);
				long itemId = resultSet.getLong(2);
				float rating = resultSet.getLong(3);
				list.add(userId + ";" + itemId + ";" + rating);
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	/**
	 * Gets the users, items, contexts and ratings for a specific user.
	 *
	 * @return ResultSet.
	 */
	@Override
	public List<String> getUserItemContextRatingFor(long userID) {
		ResultSet resultSet = null;
		List<String> list = new LinkedList<>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			//
			resultSet = statement.executeQuery("SELECT id_user,id_item,id_context,rating FROM user_item_context WHERE id_user==" + userID + " ORDER BY rating DESC");
			while (resultSet.next()) {
				long userId = resultSet.getLong(1);
				long itemId = resultSet.getLong(2);
				long context = resultSet.getLong(3);
				float rating = resultSet.getLong(4);
				list.add(userId + ";" + itemId + ";" + context + ";" + rating);
			}

		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public List<String> getUserItemContextRatingRandomFor(long userID) {
		ResultSet resultSet = null;
		List<String> list = new LinkedList<>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			//
			resultSet = statement.executeQuery("SELECT DISTINCT id_user,id_item,id_context,rating FROM user_item_context WHERE id_user==" + userID + " ORDER BY RANDOM()");
			while (resultSet.next()) {
				long userId = resultSet.getLong(1);
				long itemId = resultSet.getLong(2);
				long context = resultSet.getLong(3);
				float rating = resultSet.getLong(4);
				list.add(userId + ";" + itemId + ";" + context + ";" + rating);
			}

		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	// SELECT id_user,id_item,id_context,rating FROM user_item_context WHERE
	// id_user==176 ORDER BY RANDOM() LIMIT 10;

	/**
	 * Gets the users, items, contexts and ratings.
	 *
	 * @return ResultSet.
	 */
	@Override
	public ResultSet getUserItemContextRating() {
		ResultSet resultSet = null;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT id_user,id_item,id_context,rating FROM user_item_context");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultSet;
	}

	/**
	 * Gets a ResultSet with the user opinion about an item.
	 *
	 * @param userId
	 *            User identifier.
	 * @param itemId
	 *            Item identifier.
	 * @return ResultSet.
	 */
	@Override
	public ResultSet getOpinionFor(long userId, long itemId) {
		ResultSet resultSet = null;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT opinion FROM user_item_context WHERE user_item_context.id_user = " + userId + " AND user_item_context.id_item = " + itemId);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultSet;
	}

	/**
	 * Gets the context related to an user and item.
	 *
	 * @param userId
	 *            User identifier.
	 * @param itemId
	 *            Item identifier.
	 * @return ResultSet.
	 */
	@Override
	public ResultSet getContextFor(long userId, long itemId) {
		ResultSet resultSet = null;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT variable.value " + "FROM user_item_context, variable, context_variable " + "WHERE user_item_context.id_user = " + userId + " AND user_item_context.id_item = " + itemId + " AND user_item_context.id_context = context_variable.id_context AND context_variable.id_variable = variable.id_variable");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultSet;
	}

	/**
	 * Gets the context ID related to an user and item.
	 *
	 * @param userId
	 *            User identifier.
	 * @param itemId
	 *            Item identifier.
	 * @return ResultSet.
	 */
	@Override
	public long getContextIDFor(long userId, long itemId) {
		ResultSet resultSet = null;
		long contextID = 0;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT user_item_context.id_context " + "FROM user_item_context, variable, context_variable " + "WHERE user_item_context.id_user = " + userId + " AND user_item_context.id_item = " + itemId + " AND user_item_context.id_context = context_variable.id_context AND context_variable.id_variable = variable.id_variable");
			contextID = resultSet.getLong(1);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return contextID;
	}

	/**
	 * Gets the context ID from a list of context values.
	 *
	 * @param currentContextValues
	 *            A list of current context values.
	 * @return long.
	 */
	@Override
	public long getContextIDFor(List<Integer> currentContextValues) {
		ResultSet resultSet = null;
		long contextID = 0;
		String values = String.valueOf(currentContextValues.get(0));
		for (int i = 1; i < currentContextValues.size(); i++) {
			values += "," + currentContextValues.get(i);
		}
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT id_context FROM context_variable WHERE id_variable  IN (" + values + ") GROUP BY id_context HAVING COUNT(id_variable) = " + currentContextValues.size());
			contextID = resultSet.getLong(1);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return contextID;
	}

	/**
	 * Gets the number of instances of the user-item-context-rating.
	 *
	 * @return The number of instances of the user-item-context-rating.
	 */
	public int getNumberOfInstances() {
		int numberOfInstances = 0;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			ResultSet resultSet = statement.executeQuery("SELECT count(*) as InstanceCount FROM user_item_context");
			numberOfInstances = resultSet.getInt("InstanceCount");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return numberOfInstances;
	}

	/**
	 * Gets a HashMap with the number of items by user. The key is the user.
	 *
	 * @return A HashMap with the number of items by user.
	 */
	public Map<Long, Integer> getHashWithNumberItemsByUser() {
		Map<Long, Integer> hashWithNumberItemsByUser = new TreeMap<Long, Integer>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			ResultSet resultSet = statement.executeQuery("SELECT id_user, count(id_item) AS ItemCount FROM user_item_context GROUP BY id_user");
			while (resultSet.next()) {
				hashWithNumberItemsByUser.put(resultSet.getLong("id_user"), resultSet.getInt("ItemCount"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return hashWithNumberItemsByUser;
	}

	/**
	 * Gets a list with the context variable names.
	 *
	 * @return A list with the context variable names.
	 */
	public List<String> getVariableNames() {
		ResultSet resultSet = null;
		List<String> variableNames = new LinkedList<String>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT name FROM variable_name");
			while (resultSet.next()) {
				variableNames.add(resultSet.getString("name"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return variableNames;
	}

	/**
	 * Gets the variable name from a variable value.
	 *
	 * @param variableValue
	 *            The variable value.
	 * @return The variable name from a variable value.
	 */
	public List<String> getVariableNameFromVariableValue(String variableValue) {
		List<String> variableNames = new LinkedList<String>();
		ResultSet resultSet = null;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT DISTINCT name FROM variable WHERE variable.value='" + variableValue + "'");
			while (resultSet.next()) {
				variableNames.add(resultSet.getString("name"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return variableNames;
	}

	/**
	 * Gets a list with the possible values of a context variable.
	 *
	 * @param variableName
	 *            The name of the a variable.
	 * @return A list with the possible values of a context variable.
	 */
	public List<String> getPossibleVariableValues(String variableName) {
		ResultSet resultSet = null;
		List<String> possibleVariableValues = new LinkedList<String>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT value FROM variable WHERE name='" + variableName + "'");
			while (resultSet.next()) {
				possibleVariableValues.add(resultSet.getString("value"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return possibleVariableValues;
	}

	/**
	 * Gets a list with the names and values of context variables from userID and itemID.
	 *
	 * @param userID
	 *            The user identifier.
	 * @param itemID
	 *            The item identifier.
	 * @return A list with the names and values of context variables from userID and itemID.
	 */
	public List<String> getVariableNameAndValue(long userID, long itemID) {
		ResultSet resultSet = null;
		List<String> variableNameAndValue = new LinkedList<String>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT name, value " + "FROM variable, context_variable,user_item_context " + "WHERE user_item_context.id_user='" + userID + "' and user_item_context.id_item='" + itemID + "' " + "and user_item_context.id_context=context_variable.id_context and variable.id_variable=context_variable.id_variable");
			while (resultSet.next()) {
				variableNameAndValue.add(resultSet.getString("name") + "__" + resultSet.getString("value"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return variableNameAndValue;
	}

	/**
	 * Gets a list with the names and weights of context variables.
	 *
	 * @return A list with the names and weights of context variables.
	 */
	public List<String> getVariableNameAndWeight(long userID) {
		ResultSet resultSet = null;
		List<String> variableNameAndWeight = new LinkedList<String>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT name, weight FROM user_variable_name WHERE id_user=" + userID);
			while (resultSet.next()) {
				variableNameAndWeight.add(resultSet.getString("name") + "__" + resultSet.getString("weight"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return variableNameAndWeight;
	}

	/**
	 * Set a weight of the name of a variable. The others weights are updated automatically.
	 *
	 * @param variableName
	 *            Variable name.
	 * @param currentWeight
	 *            Current weight.
	 */
	public void setOneWeight(String variableName, double currentWeight) {
		ResultSet resultSetOldWeight = null;
		ResultSet resultSetAllWeights = null;
		double oldWeight = 0;
		double rest = 0;
		double sumWeight = 0;
		double restTemp = 0;
		double currentValue = 0;
		TreeMap<String, Double> listWeights = new TreeMap<String, Double>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSetOldWeight = statement.executeQuery("SELECT weight FROM user_variable_name WHERE name='" + variableName + "'");
			oldWeight = resultSetOldWeight.getDouble("weight");
			resultSetOldWeight.close();
			statement.close();
			connection.close();
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			statement.executeUpdate("UPDATE user_variable_name SET weight=" + currentWeight + " WHERE name='" + variableName + "'");
			statement.close();
			connection.close();
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			resultSetAllWeights = statement.executeQuery("SELECT name,weight FROM user_variable_name WHERE name != '" + variableName + "'");
			while (resultSetAllWeights.next()) {
				listWeights.put(resultSetAllWeights.getString("name"), resultSetAllWeights.getDouble("weight"));
			}
			resultSetAllWeights.close();
			statement.close();
			connection.close();
			for (Map.Entry<String, Double> entry : listWeights.entrySet()) {
				String variable = entry.getKey();
				sumWeight += listWeights.get(variable);
			}
			if (currentWeight > oldWeight) {
				rest = currentWeight - oldWeight;
				restTemp = sumWeight - rest;
			} else {
				rest = oldWeight - currentWeight;
				restTemp = sumWeight + rest;
			}
			for (Map.Entry<String, Double> entry : listWeights.entrySet()) {
				String variable = entry.getKey();
				currentValue = (listWeights.get(variable) * restTemp) / sumWeight;
				// Connection to the DB
				Class.forName(SQLITE);
				connection = DriverManager.getConnection(dbURL);
				statement = connection.createStatement();
				// Query
				statement.executeUpdate("UPDATE user_variable_name SET weight=" + currentValue + " WHERE name='" + variable + "'");
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Set all the weights of the variables.
	 *
	 * @param listContextVariableWeight
	 *            List with the weights of the context variables.
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public void setAllWeight(List<VariableWeight> listContextVariableWeight) throws ClassNotFoundException, SQLException {
		try {
			for (int i = 0; i < listContextVariableWeight.size(); i++) {
				VariableWeight contextVariableWeight = listContextVariableWeight.get(i);
				// Connection to the DB
				Class.forName(SQLITE);
				connection = DriverManager.getConnection(dbURL);
				statement = connection.createStatement();
				// Query
				statement.executeUpdate("UPDATE user_variable_name SET weight=" + contextVariableWeight.weight + " WHERE name='" + contextVariableWeight.variableName + "'");
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Determine the distance between two variable values that are similar
	 *
	 * @param variableValueX
	 * @param variableValueY
	 * @return
	 */
	public double distanceSoftVariableValues(String variableValueX, String variableValueY) {
		double distance = -1;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			ResultSet resultSet = statement.executeQuery("SELECT A.distance FROM variable_variable A INNER JOIN variable F ON A.variable1=F.id_variable WHERE F.value='" + variableValueX + "' UNION SELECT A.distance FROM variable_variable A INNER JOIN variable F ON A.variable2=F.id_variable WHERE F.value='" + variableValueY + "'");
			distance = resultSet.getDouble(1);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return distance;
	}

	/**
	 * Gets the user radius of action, according to the current transport way.
	 *
	 * @param profileId
	 *            The profile identifier.
	 * @param transportWayValue
	 *            The value of variable transport way.
	 * @return The user radius of action, according to the current transport way.
	 */
	public long getRadius(long userID, String transportWayValue) {
		long radius = 0;
		ResultSet resultSet = null;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT distance FROM distance, user, ca_profile, ca_profile_attribute WHERE ca_profile.id_ca_profile=distance.id_ca_profile and distance.id_ca_profile=user.id_ca_profile and user.id_user=" + userID + " and ca_profile_attribute.transportway='" + transportWayValue + "' and distance.id_ca_profile_attribute=ca_profile_attribute.id_ca_profile_attribute");
			radius = resultSet.getInt(1);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return radius;
	}

	/**
	 * The item latitude.
	 *
	 * @param itemID
	 *            Item identifier.
	 * @return The item latitude.
	 */
	public long getItemLatitude(long itemID) {
		long latitude = 0;
		ResultSet resultSet = null;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT latitude_gps FROM item WHERE id_item=" + itemID);
			latitude = resultSet.getInt(1);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return latitude;
	}

	/**
	 * The item longitude.
	 *
	 * @param itemID
	 *            Item identifier.
	 * @return The item longitude.
	 */
	public long getItemLongitude(long itemID) {
		long latitude = 0;
		ResultSet resultSet = null;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT longitude_gps FROM item WHERE id_item=" + itemID);
			latitude = resultSet.getInt(1);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return latitude;
	}

	/**
	 * Gets the maximum rating value.
	 *
	 * @return The maximum rating value.
	 */
	public float getMaximumRating() {
		float maximumRating = 0;
		ResultSet resultSet = null;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			resultSet = statement.executeQuery("SELECT MAX (rating) FROM user_item_context");
			maximumRating = resultSet.getInt(1);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return maximumRating;
	}

	/**
	 * Gets the number of item features.
	 *
	 * @return The number of item features.
	 */
	public int getNumberItemFeatures() {
		int numFeatures = 0;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			ResultSet resultSet = statement.executeQuery("SELECT Count(name) FROM feature");
			numFeatures = resultSet.getInt(1);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return numFeatures;
	}

	/**
	 * Gets the feature names and values of an item.
	 *
	 * @param itemId
	 *            Item identifier.
	 * @return The features of an item.
	 * @throws TasteException
	 */
	public List<String> getNamesAndValuesOfFeaturesFromItem(long itemID) throws TasteException {
		List<String> listFeatures = new LinkedList<String>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			ResultSet resultSet = statement.executeQuery("SELECT name, value FROM item_feature WHERE item_feature.id_item=" + itemID);
			while (resultSet.next()) {
				listFeatures.add(resultSet.getString("name") + "__" + resultSet.getString("value"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listFeatures;
	}

	/**
	 * Gets a list with all the feature names.
	 *
	 * @return List with all the feature names.
	 */
	public List<String> getItemFeatureNames() {
		List<String> listFeatures = new LinkedList<String>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			ResultSet resultSet = statement.executeQuery("SELECT value FROM item_feature");
			while (resultSet.next()) {
				listFeatures.add(resultSet.getString("value"));
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listFeatures;
	}

	/**
	 * Gets a list with the items not seen by the user, and also are above of predefined threshold.
	 * 
	 * @param userID
	 *            User identification.
	 * @param itemsSeen
	 *            List of items seen by the user.
	 * @param thresholdRecommendation
	 *            Predefined threshold.
	 * @return
	 */
	public List<String> getItemsNotSeenTakingAccountThreshold(long userID, List<String> itemsSeen, float thresholdRecommendation) {
		List<String> list = new LinkedList<>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();

			// Query
			ResultSet resultSet = statement.executeQuery("SELECT id_user,id_item,rating FROM user_item_context WHERE id_user==" + userID + " and rating >=" + thresholdRecommendation);
			while (resultSet.next()) {
				long userId = resultSet.getLong(1);
				long itemId = resultSet.getLong(2);
				float rating = resultSet.getLong(3);
				list.add(userId + ";" + itemId + ";" + rating);
			}
			// Remove the items seen
			for (int i = 0; i < itemsSeen.size(); i++) {
				String userItemRating = itemsSeen.get(i);
				list.remove(userItemRating);
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	/**
	 * Gets a ResultSet with the user rating about an item.
	 *
	 * @param userId
	 *            User identifier.
	 * @param itemId
	 *            Item identifier.
	 * @param contextId
	 *            Context identifier.
	 * @return ResultSet.
	 */
	@Override
	public float getPreferenceFor(long userId, long itemId, long contextId) {
		float rating = 0;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			rating = statement.executeQuery("SELECT rating FROM user_item_context WHERE id_user==" + userId + " AND id_item==" + itemId + " AND id_context==" + contextId).getFloat("rating");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return rating;
	}

	public List<Long> getItemsOrderByRoom() {
		ResultSet resultSet = null;
		List<Long> list = new LinkedList<>();
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			//
			resultSet = statement.executeQuery("SELECT id_item FROM item_feature WHERE name='Room' ORDER BY cast(value as unsigned)");
			while (resultSet.next()) {
				long itemId = resultSet.getLong(1);
				list.add(itemId);
			}
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
}
