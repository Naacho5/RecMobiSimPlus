/*
 * @(#)Context.java  1.0.0  13/10/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation.contextaware.pull;

import java.util.List;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;

import es.unizar.recommendation.contextaware.ContextAwareRecommendation;
import es.unizar.recommendation.contextaware.filter.FilterDBDataModelsByItemType;
import es.unizar.userprofileandcontextmanager.DBDataModel;

/**
 * Allows to apply the pull-based filtering.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class PullBasedRecommendation {

	private DBDataModel dataModelFilteredByItemType;
	private String itemType;
	private ContextAwareRecommendation recommender;

	public PullBasedRecommendation(String userQuery, List<String> databasePaths, ContextAwareRecommendation recommender) throws Exception {
		// Filtering by item type
		FilterDBDataModelsByItemType filterItemType = new FilterDBDataModelsByItemType(userQuery, databasePaths);
		setDataModelFilteredByItemType(filterItemType.getDataModelFilteredByItemType());
		this.itemType = filterItemType.itemType;
		this.recommender = recommender;
		recommender.setDataModel(getDataModelFilteredByItemType());
		
	}

	public List<RecommendedItem> recommend(long userID, int howMany) throws TasteException {
		return getRecommender().recommend(userID, howMany);
	}

	public float estimatePreference(long userID, long itemID) throws TasteException {
		return getRecommender().estimatePreference(userID, itemID);
	}

	// Gets and sets:
	public DBDataModel getDataModelFilteredByItemType() {
		return dataModelFilteredByItemType;
	}

	public void setDataModelFilteredByItemType(DBDataModel dataModelFilteredByItemType) {
		this.dataModelFilteredByItemType = dataModelFilteredByItemType;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public ContextAwareRecommendation getRecommender() {
		return recommender;
	}

	public void setRecommender(ContextAwareRecommendation recommender) {
		this.recommender = recommender;
	}
}
