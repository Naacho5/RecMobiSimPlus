/*
 * @(#)Context.java  1.0.0  8/04/15
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI-ARTIGAS, SERGIO <silarri[3]unizar.es>
 *  TRILLO LADO, RAQUEL <raqueltl[3]unizar.es>
 *  GUERRA, FRANCESCO <francesco.guerra[3]unimore.it>
 */
package es.unizar.keywordsearch.hmm;

import be.ac.ulg.montefiore.run.jahmm.ForwardBackwardCalculator;
import be.ac.ulg.montefiore.run.jahmm.Hmm;
import be.ac.ulg.montefiore.run.jahmm.ObservationInteger;
import be.ac.ulg.montefiore.run.jahmm.OpdfInteger;
import be.ac.ulg.montefiore.run.jahmm.OpdfIntegerFactory;
import be.ac.ulg.montefiore.run.jahmm.ViterbiCalculator;
import be.ac.ulg.montefiore.run.jahmm.io.HmmReader;
import be.ac.ulg.montefiore.run.jahmm.io.HmmWriter;
import be.ac.ulg.montefiore.run.jahmm.io.OpdfIntegerReader;
import be.ac.ulg.montefiore.run.jahmm.io.OpdfReader;
import be.ac.ulg.montefiore.run.jahmm.io.OpdfWriter;
import be.ac.ulg.montefiore.run.jahmm.learn.BaumWelchLearner;
import be.ac.ulg.montefiore.run.jahmm.learn.KMeansLearner;
import be.ac.ulg.montefiore.run.jahmm.toolbox.KullbackLeiblerDistanceCalculator;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import org.apache.commons.lang.StringUtils;

/**
 *
 * @author María del Carmen Rodríguez-Hernández
 */
public class KeywordSearchHMM {

    private static final DecimalFormat OBS_FORMAT = new DecimalFormat("##.#####");
    private String featuresLocation;
    private String hmmFileName;
    private Map<String, Integer> words = new HashMap<String, Integer>();

    /**
     *
     * @param featuresLocation
     * @param hmmFileName
     */
    public KeywordSearchHMM(String featuresLocation, String hmmFileName) {
        this.featuresLocation = featuresLocation;
        this.hmmFileName = hmmFileName;
    }

    /**
     * Set the features location
     *
     * @param featuresLocation
     */
    public void setFeaturesLocation(String featuresLocation) {
        this.featuresLocation = featuresLocation;
    }

    /**
     * Set the HMM file name
     *
     * @param hmmFileName
     */
    public void setHmmFileName(String hmmFileName) {
        this.hmmFileName = hmmFileName;
    }

    /**
     * Builds an HMM from a formatted file describing the HMM. The format is
     * specified by the Jahmm project, and it has utility methods to read and
     * write HMMs from and to text files.
     *
     * @return a HMM
     * @throws Exception if one is thrown.
     */
    public Hmm<ObservationInteger> buildFromHmmFile() throws Exception {
        File hmmFile = new File(hmmFileName);
        if (!hmmFile.exists()) {
            throw new Exception("HMM File: " + hmmFile.getName() + " does not exist");
        }
        FileReader fileReader = new FileReader(hmmFile);
        OpdfReader<OpdfInteger> opdfReader = new OpdfIntegerReader();
        Hmm<ObservationInteger> hmm = HmmReader.read(fileReader, opdfReader);
        return hmm;
    }

    /**
     * Utility method to save an HMM into a formatted text file describing the
     * HMM. The format is specified by the Jahmm project, which also provides
     * utility methods to write a HMM to the text file.
     *
     * @param hmm the HMM to write.
     * @throws Exception if one is thrown.
     */
    public void saveToFile(Hmm<ObservationInteger> hmm) throws Exception {
        FileWriter fileWriter = new FileWriter(hmmFileName);
        // we create our own impl of the OpdfIntegerWriter because we want
        // to control the formatting of the opdf probabilities. With the 
        // default OpdfIntegerWriter, small probabilities get written in 
        // the exponential format, ie 1.234..E-4, which the HmmReader does
        // not recognize.
        OpdfWriter<OpdfInteger> opdfWriter = new OpdfWriter<OpdfInteger>() {
            @Override
            public void write(Writer writer, OpdfInteger opdf) throws IOException {
                String s = "B [";
                for (int i = 0; i < opdf.nbEntries(); i++) {
                    s += OBS_FORMAT.format(opdf.probability(new ObservationInteger(i))) + " ";
                }
                writer.write(s + "]\n");
            }
        };
        HmmWriter.write(fileWriter, opdfWriter, hmm);
        fileWriter.flush();
        fileWriter.close();
    }

    /**
     * Given the HMM, returns the probability of observing the sequence of the
     * keywords specified in the query. Uses the Forward-Backward algorithm to
     * compute the probability.
     *
     * @param keywords the sentence to check.
     * @param hmm a reference to a prebuilt HMM.
     * @return the probability of observing this sequence.
     * @throws Exception if one is thrown.
     */
    public double getObservationProbability(String keywords, Hmm<ObservationInteger> hmm) throws Exception {
        String[] tokens = tokenizeSentence(keywords);
        List<ObservationInteger> observations = getObservations(tokens);
        ForwardBackwardCalculator fbc = new ForwardBackwardCalculator(observations, hmm);
        return fbc.probability();
    }

    /**
     * Given an HMM and an untagged sentence, tags each word with the part of
     * speech it is most likely to belong in. Uses the Viterbi algorithm.
     *
     * @param sentence the sentence to tag.
     * @param hmm the HMM to use.
     * @return a tagged sentence.
     * @throws Exception if one is thrown.
     */
    public String tagSentence(String sentence, Hmm<ObservationInteger> hmm) throws Exception {
        String[] tokens = tokenizeSentence(sentence);
        List<ObservationInteger> observations = getObservations(tokens);
        StringBuilder stateSequence = new StringBuilder();
        ViterbiCalculator vc = null;
        try {
            long TInicio = System.currentTimeMillis();
            vc = new ViterbiCalculator(observations, hmm);
            long TFin = System.currentTimeMillis();
            long tiempo = TFin - TInicio;
            System.out.println("Model creation time (in milliseconds): " + tiempo);
            int[] ids = vc.stateSequence();
            StringBuilder tagBuilder = new StringBuilder();
            for (int i = 0; i < ids.length; i++) {
                stateSequence.append((States.values()[ids[i]]).name()).append(" ");
                tagBuilder.append(tokens[i]).append("/").append((States.values()[ids[i]]).name()).append(" ");
            }
        } catch (IllegalArgumentException e) {
            stateSequence.append("other");
        }
        //return tagBuilder.toString();
        return stateSequence.toString();
    }

    /**
     * Given an existing HMM, this method will send in a List of sentences from
     * a possibly different untagged source, to refine the HMM.
     *
     * @param sentences the List of sentences to teach.
     * @return a HMM that has been taught using the observation sequences.
     * @throws Exception if one is thrown.
     */
    public Hmm<ObservationInteger> teach(List<String> sentences) throws Exception {
        if (words == null || words.size() == 0) {
            loadWordsFromDictionary();
        }
        OpdfIntegerFactory factory = new OpdfIntegerFactory(words.size());
        List<List<ObservationInteger>> sequences = new ArrayList<List<ObservationInteger>>();
        for (String sentence : sentences) {
            List<ObservationInteger> sequence = getObservations(tokenizeSentence(sentence));
            sequences.add(sequence);
        }
        KMeansLearner<ObservationInteger> kml = new KMeansLearner<ObservationInteger>(States.values().length, factory, sequences);
        Hmm<ObservationInteger> hmm = kml.iterate();
        // refine it with Baum-Welch Learner
        BaumWelchLearner bwl = new BaumWelchLearner();
        Hmm<ObservationInteger> refinedHmm = bwl.iterate(hmm, sequences);
        return refinedHmm;
    }

    /**
     * Convenience method to compute the distance between two HMMs. This can be
     * used to stop the teaching process once more teaching is not producing any
     * appreciable improvement in the HMM, ie, the HMM converges. The caller
     * will need to match the result of this method with a number based on
     * experience.
     *
     * @param hmm1 the original HMM.
     * @param hmm2 the HMM that was most recently taught.
     * @return the difference measure between the two HMMs.
     * @throws Exception if one is thrown.
     */
    public double difference(Hmm<ObservationInteger> hmm1, Hmm<ObservationInteger> hmm2) throws Exception {
        KullbackLeiblerDistanceCalculator kdc = new KullbackLeiblerDistanceCalculator();
        return kdc.distance(hmm1, hmm2);
    }

    /**
     *
     * @param sentence
     * @return
     */
    public String[] tokenizeSentence(String sentence) {
        String[] tokens = StringUtils.split(StringUtils.lowerCase(StringUtils.trim(sentence)), " ");
        return tokens;
    }

    /**
     *
     * @param tokens
     * @return
     * @throws Exception
     */
    public List<ObservationInteger> getObservations(String[] tokens) throws Exception {
        if (words == null || words.size() == 0) {
            loadWordsFromDictionary();
        }
        List<ObservationInteger> observations = new ArrayList<ObservationInteger>();
        for (String token : tokens) {
            if (words.get(token) != null) {
                observations.add(new ObservationInteger(words.get(token)));
            }
        }
        return observations;
    }

    /**
     *
     * @throws Exception
     */
    public void loadWordsFromDictionary() throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(featuresLocation));
        String word;
        int seq = 0;
        while ((word = reader.readLine()) != null) {
            words.put(word, seq);
            seq++;
        }
        reader.close();
    }

    /**
     * Deletes item types duplicates.
     *
     * @param sequenceSates Sequence of item types.
     * @return A sequence without item types duplicates.
     */
    public String deleteDuplicates(String sequenceSates) {
        String[] array = sequenceSates.split(" ");
        LinkedList<String> newArray = new LinkedList<String>();
        for (int i = 0; i < array.length; i++) {
            String itemType = array[i];
            if (newArray.isEmpty()) {
                newArray.add(itemType);
            } else {
                if (!newArray.contains(itemType)) {
                    newArray.add(itemType);
                }
            }
        }
        String newSequenceSates = newArray.getFirst();
        for (int i = 1; i < newArray.size(); i++) {
            newSequenceSates += " " + newArray.get(i);
        }
        return newSequenceSates;
    }

    /**
     * Choose an item type.
     *
     * @param sequenceSates Sequence of item types.
     * @return
     */
    public String itemTypeMoreRelevant(String sequenceSates) {
        TreeMap<String, Integer> itemMap = new TreeMap<String, Integer>();
        String[] array = sequenceSates.split(" ");
        for (int i = 0; i < array.length; i++) {
            String item_feature = array[i];
            String item = item_feature.split("_")[0];
            if (itemMap.isEmpty()) {
                itemMap.put(item, 1);
            } else {
                if (itemMap.containsKey(item)) {
                    int c = itemMap.get(item);
                    itemMap.put(item, c++);
                } else {
                    itemMap.put(item, 1);
                }
            }
        }
        return chooseItemType(itemMap);
    }

    private String chooseItemType(TreeMap<String, Integer> itemMap) {
        String itemTypeMoreRelevant = null;
        //The higher value:
        int higher = 0;
        for (Map.Entry<String, Integer> entry : itemMap.entrySet()) {
            String key = entry.getKey();
            Integer value = itemMap.get(key);
            if (value > higher) {
                higher = value;
            }
        }
        LinkedList<String> itemList = new LinkedList<String>();
        for (Map.Entry<String, Integer> entry : itemMap.entrySet()) {
            String key = entry.getKey();
            Integer value = itemMap.get(key);
            if (value == higher) {
                itemList.add(key);
            }
        }

        Random random = new Random();
        if (itemList.size() > 1) {
            int numRandom = random.nextInt(itemList.size());
            itemTypeMoreRelevant = itemList.get(numRandom).split("_")[0];
        } else {
            itemTypeMoreRelevant = itemList.getFirst().split("_")[0];
        }
        return itemTypeMoreRelevant;
    }
}
