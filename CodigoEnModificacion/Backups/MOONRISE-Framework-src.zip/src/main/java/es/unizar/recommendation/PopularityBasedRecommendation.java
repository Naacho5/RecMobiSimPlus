/*
 * @(#)Context.java  1.0.0  27/09/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.apache.mahout.cf.taste.common.Refreshable;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.impl.recommender.AbstractRecommender;
import org.apache.mahout.cf.taste.model.PreferenceArray;
import org.apache.mahout.cf.taste.recommender.CandidateItemsStrategy;
import org.apache.mahout.cf.taste.recommender.IDRescorer;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.userprofileandcontextmanager.DBDataModel;
import es.unizar.util.GenericRecommendedItem;

/**
 * Produces popularity-based recommendations and preference estimates.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class PopularityBasedRecommendation extends AbstractRecommender implements Recommender {

	private static final Logger log = LoggerFactory.getLogger(PopularityBasedRecommendation.class);

	/**
	 * Constructor when a candidate item strategy is to be used.
	 *
	 * @param dataModel
	 *            The data model.
	 * @param candidateItemsStrategy
	 *            The strategy.
	 */
	public PopularityBasedRecommendation(final DBDataModel dataModel, final CandidateItemsStrategy candidateItemsStrategy) {
		super(dataModel, candidateItemsStrategy);

	}

	/**
	 * Default constructor.
	 *
	 * @param dataModel
	 *            The data model.
	 */
	public PopularityBasedRecommendation(final DBDataModel dataModel) {
		super(dataModel);
	}

	@Override
	public List<RecommendedItem> recommend(long userID, int howMany) throws TasteException {
		DBDataModel dataModel = (DBDataModel) getDataModel();
		List<GenericRecommendedItem> candidateItems = new LinkedList<GenericRecommendedItem>();
		List<RecommendedItem> topList = new LinkedList<RecommendedItem>();
		LongPrimitiveIterator itemIDs = dataModel.getItemIDs();
		long itemID = 0;
		while (itemIDs.hasNext()) {
			itemID = itemIDs.nextLong();
			float numberOfPreferences = dataModel.getPreferencesForItem(itemID).length();
			GenericRecommendedItem candidatedItem = new GenericRecommendedItem(itemID, numberOfPreferences);
			candidateItems.add(candidatedItem);
		}
		Collections.sort(candidateItems);
		for (int i = 0; i < howMany; i++) {
			RecommendedItem itemAndNumberOfPreference = candidateItems.get(i);
			itemID = itemAndNumberOfPreference.getItemID();
			// Generate the rating of [1, maximum rating]:
			float value = getRating(itemID);
			// Make sure the value is not accidentally a little outside [-1.0,
			// maximum rating]:
			float maximumRating = dataModel.getMaxPreference();
			if (value < 0.0) {
			} else {
				if (value > maximumRating) {
					value = maximumRating;
				}
			}
			GenericRecommendedItem recommendedItem = new GenericRecommendedItem(itemID, value);
			topList.add(recommendedItem);
		}
		return topList;
	}

	@Override
	public float estimatePreference(long userID, long itemID) throws TasteException {
		float rating = 0;
		try {
			rating = getDataModel().getPreferenceValue(userID, itemID);
		} catch (java.lang.NullPointerException e) {
			rating = getRating(itemID);
		}
		log.debug("Rating estimated:  " + rating);
		return rating;
	}

	@Override
	public void refresh(Collection<Refreshable> alreadyRefreshed) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	private float getRating(long itemID) throws TasteException {
		float add = 0;
		PreferenceArray arrayRatings = getDataModel().getPreferencesForItem(itemID);
		int numberOfRatings = arrayRatings.length();
		for (int i = 0; i < numberOfRatings; i++) {
			add += arrayRatings.getValue(i);
		}
		float value = add / numberOfRatings;
		return value;
	}

	@Override
	public List<RecommendedItem> recommend(long paramLong, int paramInt, IDRescorer paramIDRescorer) throws TasteException {
		// TODO Auto-generated method stub
		return null;
	}
}
