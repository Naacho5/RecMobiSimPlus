package es.unizar.dbmanagement;

import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.repositorymanager.DBConnection;

/**
 * tb: variable, att: id_variable, type, name, value, dynamic, manage_externally
 * 
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class variable extends DBConnection {

	private static final Logger log = LoggerFactory.getLogger(variable.class);

	public variable(String dbURL) {
		super(dbURL);
	}

	public void insertOne(int id, String type, String name, String value, boolean dynamic, boolean manage_externally) {
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			statement.executeUpdate("INSERT INTO variable VALUES('" + id + "','" + type + "','" + name + "','" + value
					+ "','" + dynamic + "','" + manage_externally + "')");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
