/*
 * @(#)Context.java  1.0.0  04/05/15
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI-ARTIGAS, SERGIO <silarri[3]unizar.es>
 *  TRILLO LADO, RAQUEL <raqueltl[3]unizar.es>
 *  GUERRA, FRANCESCO <francesco.guerra[3]unimore.it>
 */
package es.unizar.keywordsearch.hmm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Iterator;
import java.util.LinkedList;

import es.unizar.keywordsearch.preprocessing.PreprocessingText;
import es.unizar.properties.HMMFileInformation;

/**
 *
 * @author María del Carmen Rodríguez-Hernández
 */
public class GenerateObservationsFile {

    private PreprocessingText preprocessing;

    public GenerateObservationsFile() {
        this.preprocessing = new PreprocessingText();
    }

    /**
     * Generates the observation file.
     *
     * @param observationFilePath The observation file path.
     * @param pathSeveralFiles The path of the several files.
     * @throws FileNotFoundException
     * @throws IOException
     */
    public void generateObservationsFileFromSeveralFiles(String observationFilePath, LinkedList<String> pathSeveralFiles) throws FileNotFoundException, IOException {
        LinkedList<String> list = new LinkedList<String>();
        for (int i = 0; i < pathSeveralFiles.size(); i++) {
            String filePath = pathSeveralFiles.get(i);
            BufferedReader br = new BufferedReader(new FileReader(new File(filePath)));
            String line = null;
            while ((line = br.readLine()) != null) {
                list.add(line);
            }
            br.close();
        }

        File observationFile = new File(observationFilePath);
        if (observationFile.exists()) {
            observationFile.delete();
        }
        RandomAccessFile pw = new RandomAccessFile(observationFile, "rw");
        for (Iterator<String> it = list.iterator(); it.hasNext();) {
            String value = it.next();
            pw.writeBytes(value + "\n");
        }

        ManageStates manageStates = new ManageStates();
        for (int i = 0; i < manageStates.itemTypeList.size(); i++) {
            String statePreprocessed = preprocessing.preprocessingText(manageStates.itemTypeList.get(i), HMMFileInformation.STOPWORDS_PATH);
            pw.writeBytes(statePreprocessed + "\n");
        }
        pw.close();
    }
}
