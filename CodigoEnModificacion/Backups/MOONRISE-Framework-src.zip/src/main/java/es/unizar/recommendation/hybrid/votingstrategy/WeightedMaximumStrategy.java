/*
 * @(#)Context.java  1.0.0  3/08/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation.hybrid.votingstrategy;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.mahout.cf.taste.common.TasteException;

/**
 *
 * Maximum of all individual ratings.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class WeightedMaximumStrategy extends AbstractWeightedStrategy {

    public WeightedMaximumStrategy(List<DataStrategy> dataVotingStrategieList) {
        super(dataVotingStrategieList);
    }

    @Override
    public float executeStrategie(long userId, long itemId) {
        float estimate = 0;
        float temp = 0;
        verifyCoefficient();
        DataStrategy dataVotingStrategie = dataVotingStrategieList.get(0);
        try {
            estimate = dataVotingStrategie.getRecommender().estimatePreference(userId, itemId);
        } catch (TasteException ex) {
            Logger.getLogger(WeightedMinimumStrategy.class.getName()).log(Level.SEVERE, null, ex);
        }
        for (int i = 1; i < dataVotingStrategieList.size(); i++) {
            dataVotingStrategie = dataVotingStrategieList.get(i);
            try {
                temp = dataVotingStrategie.getRecommender().estimatePreference(userId, itemId);
            } catch (TasteException ex) {
                Logger.getLogger(WeightedMinimumStrategy.class.getName()).log(Level.SEVERE, null, ex);
            }

            if (temp > estimate) {
                estimate = temp;
            }
        }
        return estimate;
    }
}
