package es.unizar.dbmanagement;

import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.repositorymanager.DBConnection;

/**
 * tb: ca_profile, att: id_ca_profile, name
 * 
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class ca_profile extends DBConnection {
	
	private static final Logger log = LoggerFactory.getLogger(ca_profile.class);

	public ca_profile(String dbURL) throws SQLException {
		super(dbURL);
	}

	public void insertOne(int id, String name) {
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			statement.executeUpdate("INSERT INTO ca_profile VALUES('" + id + "','" + name + "')");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
