package es.unizar.dbmanagement;

import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.repositorymanager.DBConnection;

/**
 * tb: context_variable, att: id_context, id_variable
 * 
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class context_variable extends DBConnection {

	private static final Logger log = LoggerFactory.getLogger(context_variable.class);

	public context_variable(String dbURL) {
		super(dbURL);
	}

	public void insertOne(int id_context, int id_variable) {
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			statement.executeUpdate("INSERT INTO context_variable VALUES('" + id_context + "','" + id_variable + "')");
			// Close connection
			statement.close();
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public String selectIdVariableFromValue(String value) {
		String result = null;
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			result = statement.executeQuery("SELECT id_variable FROM variable WHERE value=='" + value + "'")
					.getString(1);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
}
