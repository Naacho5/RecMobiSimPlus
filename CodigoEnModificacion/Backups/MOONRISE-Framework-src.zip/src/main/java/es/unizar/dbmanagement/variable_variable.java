package es.unizar.dbmanagement;

import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.repositorymanager.DBConnection;

/**
 * tb: variable_variable, att: id_variable1, id_variable2, distance
 * 
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class variable_variable extends DBConnection {

	private static final Logger log = LoggerFactory.getLogger(variable_variable.class);

	public variable_variable(String dbURL) {
		super(dbURL);
	}

	public void insertOne(int id_variable1, int id_variable2, double distance) {
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			statement.executeUpdate("INSERT INTO variable_variable VALUES('" + id_variable1 + "','" + "','"
					+ id_variable2 + "','" + distance + "')");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
