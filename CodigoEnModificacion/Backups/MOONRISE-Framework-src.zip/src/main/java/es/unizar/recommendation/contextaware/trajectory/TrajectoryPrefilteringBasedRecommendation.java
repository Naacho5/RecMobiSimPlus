//package es.unizar.recommendation.contextaware.trajectory;
//
//import java.util.Arrays;
//import java.util.LinkedList;
//import java.util.List;
//
//import org.apache.mahout.cf.taste.common.TasteException;
//import org.apache.mahout.cf.taste.recommender.RecommendedItem;
//
//import es.unizar.recommendation.contextaware.PrefilteringBasedRecommendation;
//
//public class TrajectoryPrefilteringBasedRecommendation {
//	private PrefilteringBasedRecommendation recommender;
//	private TrajectoryStrategy trajectoryStrategy;
//
//	public TrajectoryPrefilteringBasedRecommendation(PrefilteringBasedRecommendation recommender,
//			TrajectoryStrategy trajectoryStrategy) {
//		this.recommender = recommender;
//		setTrajectoryStrategy(trajectoryStrategy);
//	}
//
//	/**
//	 * Gets the items to recommend with its route.
//	 * 
//	 * @param userID
//	 *            Current user.
//	 * @param howMany
//	 *            How many of items to recommend.
//	 * @return The candidates items obtained by the recommendation algorithm.
//	 * @throws TasteException
//	 */
//	public List<RecommendedItem> recommend(long userID, int howMany) throws TasteException {
//		// Candidate items from recommender
//		List<RecommendedItem> candidateItemsFromRecommender = getRecommender().recommend(userID, howMany);
//		List<Long> recommededItems = listRecommendedItemToListLong(candidateItemsFromRecommender);
//
//		// Filter items by floor 4
//		Long[] arrayItemsFloor4 = { 5L, 7L, 9L, 1L, 11L, 22L, 23L, 25L, 27L, 30L, 33L, 37L, 231L, 234L, 39L, 43L, 44L,
//				217L, 222L, 223L, 46L, 52L, 55L, 56L, 209L, 233L, 239L, 61L, 63L, 65L, 66L, 72L, 76L, 77L, 80L, 224L,
//				86L, 94L, 97L, 99L, 100L, 101L, 227L, 102L, 103L, 104L, 105L, 106L, 108L, 109L, 110L, 232L, 114L, 116L,
//				118L, 121L, 218L, 122L, 124L, 127L, 136L, 140L, 142L, 236L, 238L, 143L, 145L, 147L, 151L, 164L, 169L,
//				170L, 171L, 211L, 228L, 182L, 183L, 186L, 190L, 192L, 193L, 199L, 200L, 237L, 201L, 203L, 205L, 207L,
//				229L, 230L };
//		List<Long> itemsFloor4 = Arrays.asList(arrayItemsFloor4);
//		List<Long> recommededItemsOK = new LinkedList<>();
//		for (int i = 0; i < recommededItems.size(); i++) {
//			Long item = recommededItems.get(i);
//			if (itemsFloor4.contains(item)) {
//				recommededItemsOK.add(item);
//			}
//		}
//
//		// Candidate items from graph
//		List<Long> itemTrajectories = getTrajectoryStrategy().getOptimalTrajectory(recommededItemsOK);
//
//		// Combines trajectory obtained of the graph with the candidate items
//		// from recommender.
//		List<RecommendedItem> finalRecommendedItems = new LinkedList<>();
//		for (int i = 0; i < itemTrajectories.size(); i++) {
//			long itemGraph = itemTrajectories.get(i);
//			for (int j = 0; j < candidateItemsFromRecommender.size(); j++) {
//				RecommendedItem itemRecommender = candidateItemsFromRecommender.get(j);
//				if (itemGraph == itemRecommender.getItemID()) {
//					if (finalRecommendedItems.isEmpty()) {
//						finalRecommendedItems.add(itemRecommender);
//					} else {
//						if (!finalRecommendedItems.contains(itemRecommender)) {
//							finalRecommendedItems.add(itemRecommender);
//						}
//					}
//				}
//			}
//		}
//		return finalRecommendedItems;
//	}
//
//	public float estimatePreference(long userID, long itemID) throws TasteException {
//		return getRecommender().estimatePreference(userID, itemID);
//	}
//
//	private List<Long> listRecommendedItemToListLong(List<RecommendedItem> candidateItems) {
//		List<Long> itemList = new LinkedList<>();
//		for (RecommendedItem item : candidateItems) {
//			itemList.add(item.getItemID());
//		}
//		return itemList;
//	}
//
//	public PrefilteringBasedRecommendation getRecommender() {
//		return recommender;
//	}
//
//	public void setRecommender(PrefilteringBasedRecommendation recommender) {
//		this.recommender = recommender;
//	}
//
//	public TrajectoryStrategy getTrajectoryStrategy() {
//		return trajectoryStrategy;
//	}
//
//	public void setTrajectoryStrategy(TrajectoryStrategy trajectoryStrategy) {
//		this.trajectoryStrategy = trajectoryStrategy;
//	}
//
//}
