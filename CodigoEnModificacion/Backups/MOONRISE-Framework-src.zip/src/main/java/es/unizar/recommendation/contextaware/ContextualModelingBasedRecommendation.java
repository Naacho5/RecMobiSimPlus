/*
 * @(#)Context.java  1.0.0  13/10/14
 *
 * MOONRISE
 * Webpage: http://webdiis.unizar.es/~maria/?page_id=250
 * 
 * University of Zaragoza - Distributed Information Systems Group (SID)
 * http://sid.cps.unizar.es/
 *
 * The contents of this file are subject under the terms described in the
 * MOONRISE_LICENSE file included in this distribution; you may not use this
 * file except in compliance with the License.
 *
 * Contributor(s):
 *  RODRIGUEZ-HERNANDEZ, MARIA DEL CARMEN <692383[3]unizar.es>
 *  ILARRI, SERGIO <silarri[3]unizar.es>
 */
package es.unizar.recommendation.contextaware;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;

import es.unizar.userprofileandcontextmanager.DBDataModel;
import es.unizar.util.GenericRecommendedItem;
import weka.classifiers.Classifier;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;

/**
 * Produces contextual modeling-based pull recommendations and preference
 * estimates.
 *
 * @author Maria del Carmen Rodriguez-Hernandez
 */
public class ContextualModelingBasedRecommendation extends ContextAwareRecommendation {

	/**
	 * The classfier.
	 */
	public Classifier classifier;
	/**
	 * The knowledge base of the current user.
	 */
	public Instances userKnowledgeBase;
	/**
	 * The path of the knowledge base (in file format) with the items seen by
	 * the current user.
	 */
	public String knowledgeBasesDirectoryPath;
	/**
	 * The path of the knowledge base (in file format) with the items not seen
	 * by the current user.
	 */
	public static final String ITEMS_NOT_SEEN_BY_USER = "ItemsNotSeenByUser";
	/**
	 * The names of the contextual variables.
	 */
	public List<String> variableNames;

	/**
	 *
	 * @param userQuery
	 *            The user query.
	 * @param databasePaths
	 *            The paths of the all the databases.
	 * @param ifGenerateFiles
	 *            Generates the the observations.txt and hmm.dat files if is
	 *            true.
	 * @param knowledgeBasesDirectoryPath
	 *            The path of the knowledge bases by user.
	 * @param classifier
	 *            The classifier.
	 * @throws Exception
	 */
	public ContextualModelingBasedRecommendation(DBDataModel dataModel, String knowledgeBasesDirectoryPath,
			Classifier classifier) throws Exception {
		super(dataModel);
		this.knowledgeBasesDirectoryPath = knowledgeBasesDirectoryPath;
		// delete everything that is inside a folder.
		deleteDirectory();
		this.variableNames = dataModel.getVariableNames();
		generateKnowledgeBaseFileByUser(knowledgeBasesDirectoryPath);
		this.classifier = classifier;
	}

	/**
	 * Recommends a list of items to the current user.
	 *
	 * @param userID
	 *            The user identifier.
	 * @param howMany
	 *            How items to recommend.
	 * @return A list of items to the current user.
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws TasteException
	 */
	@Override
	public List<RecommendedItem> recommend(long userID, int howMany) throws TasteException {
		List<GenericRecommendedItem> candidateItems = new LinkedList<GenericRecommendedItem>();
		try {
			buildClassifier(knowledgeBasesDirectoryPath, userID);
			generateKnowledgeBaseFileFromItemsNotSeenByUser(userID);
			Instances instancesNotSeen = generateKnowledgeBaseFromItemsNotSeenByUser(knowledgeBasesDirectoryPath);
			instancesNotSeen.setClassIndex(instancesNotSeen.numAttributes() - 1);
			for (int i = 0; i < instancesNotSeen.size(); i++) {
				Instance instance = instancesNotSeen.get(i);
				double classIndex = classifier.classifyInstance(instance);
				float rating = Float.valueOf(instancesNotSeen.classAttribute().value((int) classIndex));
				long itemID = (long) instance.value(instance.numAttributes() - 2);
				GenericRecommendedItem recommendedItem = new GenericRecommendedItem(itemID, (float) rating);
				candidateItems.add(recommendedItem);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return getTopItems(howMany, candidateItems);
	}

	/**
	 * Estimates the preference of the user by the item.
	 *
	 * @param userID
	 *            The user identifier.
	 * @param itemID
	 *            The item identifier.
	 * @return The preference of the user by the item.
	 * @throws TasteException
	 */
	@Override
	public float estimatePreference(long userID, long itemID) throws TasteException {
		float rating = 0;
		try {
			buildClassifier(knowledgeBasesDirectoryPath, userID);

			// Header:
			Attribute att = null;
			ArrayList<Attribute> attinfo = new ArrayList<Attribute>();
			for (int i = 0; i < variableNames.size(); i++) {
				String variableName = variableNames.get(i);
				List<String> possibleValues = dataModel.getPossibleVariableValues(variableNames.get(i));
				att = new Attribute(variableName, possibleValues);
				attinfo.add(att);
			}
			att = new Attribute("item");
			att.setStringValue(String.valueOf(itemID));
			attinfo.add(att);

			int maxPreference = (int) dataModel.getMaxPreference();
			LinkedList<String> possibleClasses = new LinkedList<String>();
			for (int i = 1; i < maxPreference + 1; i++) {
				possibleClasses.add(String.valueOf(i));
			}
			att = new Attribute("class", possibleClasses);
			attinfo.add(att);

			Instances instances = new Instances("name", attinfo, 1);
			instances.setClassIndex(instances.numAttributes() - 1);

			// Data
			List<String> nameAndValueList = dataModel.getVariableNameAndValue(userID, itemID);
			for (int i = 0; i < nameAndValueList.size(); i++) {
				String value = nameAndValueList.get(i).split("__")[1];
				Instance instance = new DenseInstance(instances.numAttributes());
				instances.add(instance);
				instances.instance(0).setValue(i, value);
			}

			instances.instance(0).setValue(instances.numAttributes() - 2, itemID);
			instances.instance(0).setValue(instances.numAttributes() - 1, String.valueOf(2));

			// Classify
			Instance instance = instances.get(0);
			double classIndex = classifier.classifyInstance(instance);
			rating = Float.valueOf(userKnowledgeBase.classAttribute().value((int) classIndex));
		} catch (Exception ex) {
			Logger.getLogger(ContextualModelingBasedRecommendation.class.getName()).log(Level.SEVERE, null, ex);
		}
		return rating;
	}

	private List<RecommendedItem> getTopItems(int howMany, List<GenericRecommendedItem> candidateItems) {
		List<RecommendedItem> topItems = new LinkedList<RecommendedItem>();
		Collections.sort(candidateItems);
		for (int i = 0; i < howMany; i++) {
			RecommendedItem recommendedItem = candidateItems.get(i);
			topItems.add(recommendedItem);
		}
		return topItems;
	}

	/**
	 * Builds the classifier by using the knowledge base of the current user.
	 */
	private void buildClassifier(String knowledgeBasesDirectoryPath, long userID)
			throws FileNotFoundException, IOException {
		this.userKnowledgeBase = generateCurrentUserKnowledgeBase(knowledgeBasesDirectoryPath, userID);
		this.userKnowledgeBase.setClassIndex(userKnowledgeBase.numAttributes() - 1);
		try {
			this.classifier.buildClassifier(userKnowledgeBase);
		} catch (Exception ex) {
			Logger.getLogger(ContextualModelingBasedRecommendation.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	/**
	 * Generates knowledge bases (in file format .arff) by each user.
	 */
	private void generateKnowledgeBaseFileByUser(String knowledgeBasesDirectoryPath)
			throws TasteException, SQLException, FileNotFoundException, IOException {
		LongPrimitiveIterator userIDs = dataModel.getUserIDs();
		int numberOfVariables = variableNames.size();
		int numberOfAttributes = numberOfVariables + 2; // The 2 is to add the
														// item and the class.
		String attributeValuesByInstance[] = new String[numberOfAttributes];
		// Index of attributes by instance
		for (int n = 0; n < numberOfAttributes; n++) {
			attributeValuesByInstance[n] = "?";
		}
		// For each user is created a knowledge base
		while (userIDs.hasNext()) {
			long userID = userIDs.nextLong();
			String fileName = "user" + userID;
			// Create file:
			File userKnowledgeBaseFile = new File(knowledgeBasesDirectoryPath + "/" + fileName + ".arff");
			RandomAccessFile pwFile = new RandomAccessFile(userKnowledgeBaseFile, "rw");

			// Header
			writeHeaderArff(pwFile, fileName);

			// Data:
			pwFile.writeBytes("@DATA \n");
			LongPrimitiveIterator itemIDs = dataModel.getItemIDsFromUser(userID).iterator();
			while (itemIDs.hasNext()) {
				long itemID = itemIDs.nextLong();
				List<String> listOfVariableNamesAndValues = dataModel.getVariableNameAndValue(userID, itemID);
				// A user can vote two identical items.
				int repeat = listOfVariableNamesAndValues.size() / numberOfVariables;
				int i = 0;
				while (repeat != 0) {
					while (i != numberOfVariables) {
						String nameValue = listOfVariableNamesAndValues.remove(0);
						String value = nameValue.split("__")[1];
						attributeValuesByInstance[i] = value;
						i++;
					}
					repeat--;
					i = 0;
					attributeValuesByInstance[numberOfVariables] = String.valueOf(itemID);
					int ratingClass = dataModel.getPreferenceValue(userID, itemID).intValue();
					attributeValuesByInstance[numberOfVariables + 1] = String.valueOf(ratingClass);

					// Write the instance in the file
					String variable = String.valueOf(attributeValuesByInstance[0]);
					for (int j = 1; j < attributeValuesByInstance.length; j++) {
						variable += "," + attributeValuesByInstance[j];
					}
					pwFile.writeBytes(variable + "\n");
				}
			}
		}
	}

	/**
	 * Generates the knowledge bases of the current user. In this case, is used
	 * the knowledge base (in file format .arff created previously).
	 */
	private Instances generateCurrentUserKnowledgeBase(String userKnowledgeBasePath, long userID)
			throws FileNotFoundException, IOException {
		File fileTrain = new File(userKnowledgeBasePath + "/" + "user" + userID + ".arff");
		BufferedReader brTrain = new BufferedReader(new FileReader(fileTrain));
		return new Instances(brTrain);
	}

	/**
	 * Generates a knowledge base with instances containing items that have not
	 * been seen by the current user. In this case, is used the temporal
	 * knowledge base (in file format .arff created previously).
	 */
	private Instances generateKnowledgeBaseFromItemsNotSeenByUser(String userKnowledgeBasePath)
			throws FileNotFoundException, IOException {
		File fileTest = new File(userKnowledgeBasePath + "/" + ITEMS_NOT_SEEN_BY_USER + ".arff");
		BufferedReader brTest = new BufferedReader(new FileReader(fileTest));
		return new Instances(brTest);
	}

	/**
	 * Generates a temporal knowledge base (in file format .arff) with instances
	 * containing items that have not been seen by the current user.
	 */
	private void generateKnowledgeBaseFileFromItemsNotSeenByUser(long currentUserID)
			throws TasteException, SQLException, FileNotFoundException, IOException {
		int numberOfVariables = variableNames.size();
		int numberOfAttributes = numberOfVariables + 2; // The 2 is to add the
														// item and the class.
		// Instance initially sparsed.
		String attributeValuesByInstance[] = new String[numberOfAttributes];
		for (int n = 0; n < numberOfAttributes; n++) {
			attributeValuesByInstance[n] = "?";
		}

		// Create a knowledge base for the items not seen by the current user.
		File knowledgeBaseFile = new File(knowledgeBasesDirectoryPath + "/" + ITEMS_NOT_SEEN_BY_USER + ".arff");
		RandomAccessFile pwFile = new RandomAccessFile(knowledgeBaseFile, "rw");

		// Header
		writeHeaderArff(pwFile, ITEMS_NOT_SEEN_BY_USER);

		// Data:
		pwFile.writeBytes("@DATA \n");
		// For each user is created a knowledge base
		LongPrimitiveIterator allUserIDs = dataModel.getUserIDs();
		LongPrimitiveIterator viewedItems = dataModel.getItemIDsFromUser(currentUserID).iterator();
		while (allUserIDs.hasNext()) {
			long userID = allUserIDs.nextLong();
			// avoid contexts and items of the current user:
			if (userID != currentUserID) {
				LongPrimitiveIterator allItemIDs = dataModel.getItemIDsFromUser(userID).iterator();
				while (allItemIDs.hasNext()) {
					long itemID = allItemIDs.nextLong();
					if (!isViewedItem(itemID, viewedItems)) {
						List<String> listOfVariableNamesAndValues = dataModel.getVariableNameAndValue(userID, itemID);
						// A user can vote two identical items.
						int repeat = listOfVariableNamesAndValues.size() / numberOfVariables;
						int i = 0;
						while (repeat != 0) {
							while (i != numberOfVariables) {
								String nameValue = listOfVariableNamesAndValues.remove(0);
								String value = nameValue.split("__")[1];
								attributeValuesByInstance[i] = value;
								i++;
							}
							repeat--;
							i = 0;
							attributeValuesByInstance[numberOfVariables] = String.valueOf(itemID);
							int ratingClass = dataModel.getPreferenceValue(userID, itemID).intValue();
							attributeValuesByInstance[numberOfVariables + 1] = String.valueOf(ratingClass);

							// Write the instance in the file
							String variable = String.valueOf(attributeValuesByInstance[0]);
							for (int j = 1; j < attributeValuesByInstance.length; j++) {
								variable += "," + attributeValuesByInstance[j];
							}
							pwFile.writeBytes(variable + "\n");
						}
					}
				}
			}
		}
	}

	/**
	 * Write in the header of the file.arff
	 */
	private void writeHeaderArff(RandomAccessFile pwFile, String fileName)
			throws IOException, TasteException, SQLException {
		int numberMaximumOfRating = (int) dataModel.getMaxPreference();
		// Write Header:
		pwFile.writeBytes("@RELATION " + fileName + "\n");
		pwFile.writeBytes("\n");
		for (int i = 0; i < variableNames.size(); i++) {
			String variableName = variableNames.get(i);
			List<String> possibleVariableValues = dataModel.getPossibleVariableValues(variableName);
			String posibleValues = "{" + possibleVariableValues.get(0);
			for (int j = 1; j < possibleVariableValues.size(); j++) {
				posibleValues += "," + possibleVariableValues.get(j);
			}
			posibleValues += "}";
			pwFile.writeBytes("@ATTRIBUTE " + variableName + "	" + posibleValues + "\n");
		}
		pwFile.writeBytes("@ATTRIBUTE " + "item" + "	REAL" + "\n");

		String posibleClasses = "{" + 1;
		for (int i = 2; i < numberMaximumOfRating + 1; i++) {
			posibleClasses += "," + i;
		}
		posibleClasses += "}";
		pwFile.writeBytes("@ATTRIBUTE class" + "	" + posibleClasses + "\n");
		pwFile.writeBytes("\n");
	}

	/**
	 * Delete the folder and the files that are inside.
	 */
	private void deleteDirectory() {
		File directory = new File(knowledgeBasesDirectoryPath);
		if (directory.exists() && directory.isDirectory()) {
			String[] files = directory.list();
			for (int i = 0; i < files.length; i++) {
				File file = new File(knowledgeBasesDirectoryPath + "/" + files[i]);
				file.delete();
			}
		} else {
			directory.mkdir();
		}
	}

	/**
	 * Checks if the item was seen by the current user.
	 */
	private boolean isViewedItem(long itemID, LongPrimitiveIterator viewedItems) {
		boolean isViewed = false;
		while (viewedItems.hasNext()) {
			long itemViewed = viewedItems.nextLong();
			if (itemID == itemViewed) {
				isViewed = true;
				break;
			}
		}
		return isViewed;
	}
}
