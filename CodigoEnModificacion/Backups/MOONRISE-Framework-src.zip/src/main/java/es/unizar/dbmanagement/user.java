package es.unizar.dbmanagement;

import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.unizar.repositorymanager.DBConnection;

/**
 * tb: user, att: id_user
 * 
 * @author Maria del Carmen Rodriguez-Hernandez
 *
 */
public class user extends DBConnection {

	private static final Logger log = LoggerFactory.getLogger(user.class);

	public user(String dbURL) {
		super(dbURL);
	}

	public void insertOne(int id_user, String age, String sex, int city_numeric, String country, int id_ca_profile) {
		try {
			// Connection to the DB
			Class.forName(SQLITE);
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			// Query
			statement.executeUpdate("INSERT INTO user VALUES('" + id_user + "','" + age + "','" + sex + "','"
					+ city_numeric + "','" + country + "','" + id_ca_profile + "')");
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		} finally {
			// Close connection
			try {
				if (statement != null) {
					statement.close();
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
