## KGmomarecommender

### Recommender of the MoMA museum

### constructs Knowledge graph
    - with networkx
    
### constructs embeddings from knowledge graph
    - using karateclub (Deepwalk

### makes recommendations
    - constructs users:
        - draw favorite styles randomly
        - draw for each favorite styles some artworks randomly
    - finding recommendations for a single favorite artwork
        - considering only embeddings from nodes of type ‘artwork’
        - calculates the distances from the favorite artwork to all other artworks 
          (using Cosine distance on the corresponding embeddings)
        - recommend the k most similar artworks 
    - finding recommendations for a certain user (i.e. for her list of favorite artworks) 
        - for each artwork from the user’s favorite list: 
          -> calculate a candidate list of artworks with the corresponding scores 
          -> combine these candidate lists: 
             (scores of artworks that appear in more than one candidate list are 
              added together) 
        - the best k artworks are recommended
    - evaluation:
        - a certain user u may have a list F(u) of her k favorite artworks (e.g. k = 20) 
        - F(u) is split into train and test data
        - it is checked how many of the recommendations from the training data a
          appear in teh test data to calculate precison@k

