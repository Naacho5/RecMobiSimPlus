class Artwork:

    def __init__(self, moma_id, node_id, title, artist_ID, artist, year, style, genre, room):
        self.moma_id = moma_id
        self.node_id = node_id
        self.title = title
        self.artistID = artist_ID
        self.artist = artist
        self.year = year
        self.style = style
        self.genre = genre
        self.room = room

    def __str__(self):
        return 'momaID:' + str(self.moma_id).ljust(10) + 'nodeID:' + str(self.node_id).ljust(7)  \
               + ' artist:' + self.artist.ljust(22) +  ' title:' + self.title[0:20].ljust(25)  \
               + 'style: '+ self.style[0:15].ljust(18) + 'genre:' + self.genre[0:15].ljust(18) +  ' date:' + str(self.year).ljust(8) \
               +  ' room:' + str(self.room).ljust(8)



if __name__ == '__main__':
    a = Artwork(471234, 123, 'Composition 0', 4711, 'Gotthardt Graupner',  1978, 'abstract', 'portrait', 421)
    print(a)