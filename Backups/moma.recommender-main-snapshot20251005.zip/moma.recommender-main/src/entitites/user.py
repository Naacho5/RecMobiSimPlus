import pandas as pd
import random
import src.parameters.params as params
import src.mapping.mapper as mapper
import os

from src.mapping.mapper import Mapper


# for each user a list of her favorite styles is randomly drawn
# for each style artworks are randomly drawn
#      -> RoundRobin is used until a predefined number of artworks is created

class User:
    # get all artworks and styles (of 4th floor)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.abspath(os.path.join(script_dir, "../../"))
    
    # CHANGE FOR ARTWORK DISTRIBUTION
    # Artworks locations in rooms grouped by styles
    # file_path = os.path.join(project_root, 'data/Artworks4thFloor.csv')
    
    # Random distributions of artworks
    
    if params.artwork_location_random == True:
        file_path = os.path.join(project_root, 'data/ArtworksWithRandomRooms.csv')
    else:
        file_path = os.path.join(project_root, 'data/Artworks4thFloor.csv')
    
    # ##################################
    
    artworks = pd.read_csv(file_path, sep=',', dtype=str)
    all_styles = artworks['style'].unique().tolist()    # all styles in dataset
    counter = 0                                         # static counter for user ID
    user_registry = {}                                  # static dictionary with all Users.

    @staticmethod
    def getUser(user_id):
        return User.user_registry[user_id]

    def __init__(self, id = 1, simulation = False, evaluation = False):
        # generate user id:
        #User.counter += 1
        self.id = id
        self.mapper = mapper.Mapper()
        self.favorites = None   # list of favorite artworks
        self.trainingIDs = None
        self.evaluationIDs = None
        self.recommender = None

        # attributes for personal preferences
        # self.my_styles = self.drawMyStyles()

        from src.recommender.recommender import Recommender
        if simulation:
                if self.id == 1:  # follow only user ith id =1
                    self.favorites = self.drawMyFavorites(params.nbOfFavorites)
                    self.recommender = Recommender(self.getFavoritesIDs())
                else: pass
        else:
            self.favorites = self.drawMyFavorites(params.nbOfFavorites)
            if evaluation:
                # bild training and test sets
                split_mark = len(self.favorites) // 2
                self.trainingIDs = self.getFavoritesIDs()[:split_mark]
                self.evaluationIDs = self.getFavoritesIDs()[split_mark:]
                self.recommender = Recommender(self.trainingIDs)
            else:
                self.recommender = Recommender(self.getFavoritesIDs())

    def get_user_data(self):
        return self.user_data

    def drawMyFavorites(self, nbOfFavorites):

        file_path = os.path.join(self.project_root, 'data/generated_ratings_with_item_info.csv')
        ratings_df = pd.read_csv(file_path, sep=',')
           
        #The following line seems to work in Windows.
        #ratings_df = pd.read_csv('..\\RecMobiSim\\SimulatorAndMapEditor\\resources\maps\MoMA_Museum\\items_ratings_predicted.csv', sep=',')
           
        self.user_data = ratings_df[ratings_df['UserId'] == self.id]
        # Calculate the average rating per style
        style_avg_rating = self.user_data.groupby('style')['rating'].mean().sort_values(ascending=False)
        
        
        # Get the top 2 styles with the highest average rating
        top_styles = style_avg_rating.head(3).index
           
        # Filter the data for these top styles
        top_styles_data = self.user_data[self.user_data['style'].isin(top_styles)]
           
        # Find the top 20 ObjectIDs with the highest rating in these styles
        top_n_objects = top_styles_data.sort_values(by='rating', ascending=False).head(nbOfFavorites)
        
        if len(top_n_objects.index) < nbOfFavorites: 
            print('Number of favorites not achieved')
        
        # Extract the relevant columns
        result = top_n_objects[['UserId', 'ObjectID', 'rating', 'style']]
           
        # Retrieves nbOfFavorites items fomr the top-2 styles (highest average ratings)
        my_favoritesIDs = result['ObjectID'].tolist()
        my_favorites = []
        for moma_id in my_favoritesIDs:
            artwork = self.mapper.getArtwork4MoMaID(str(moma_id))
            my_favorites.append(artwork)

        return my_favorites

    def getRecommender(self):
        return self.recommender
        
    def getEvaluationIDs(self):
        return self.evaluationIDs

    def getTrainingIDs(self):
        return self.trainingIDs

    def __str__(self):
        erg = 'user:' + str(self.id) + ' --- favorites -- \n'
        for a in self.favorites:
            erg += str(a) + '\n'
        return erg

    def getFavoritesIDs(self):
        favoritesIDs = []
        for f in self.favorites:
            moma_id = int(f.moma_id)
            favoritesIDs.append(moma_id)
        return favoritesIDs

    def getFavorites(self):
        return self.favorites

if __name__ == '__main__':
    for i in range(1, 4):
        print('\n\n')
        u = User(i)
        print(u)
        #print(u.getFavoritesIDs())

