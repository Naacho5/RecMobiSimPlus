class Recommendation:

    def __init__(self, momaId, nodeId, room, score=0, risk=None):
        self.moma_id = momaId
        self.node_id = nodeId
        self.room = room
        self.score = score
        self.risk = risk

    def __str__(self):
        return ('momaID:' + str(self.moma_id) + '  nodeID:' + str(self.node_id)
                + '   room:' + str(self.room)
                + '   score:' + str(self.score) + '  risk:' + str(self.risk))


if __name__ == '__main__':
    recom = Recommendation(momaId='4711', nodeId=588, room=401, score=0, risk=0)
    print(recom)
