#*************************
#* VirusPropagationModel *
#*************************
# Created: 25 January 2024 (Sergio Ilarri).
# Modified: 9 February 2024 (Sergio Ilarri).
# Based on the COVID-19 Aerosol Transmission Estimator developed by Prof. Jose L Jimenez & Dr. Zhe Peng (Dept. of Chem. & CIRES, Univ. Colorado-Boulder). Available at: https://tinyurl.com/covid-estimator, https://docs.google.com/spreadsheets/d/16K1OQkLD4BjgBdO8ePj6ytf-RpPMlJ6aXFg3PrIQBbQ/edit?pli=1#gid=149784379. Scenario considered: Supermarket ("Supermkt" tab).
# Specific notes for this case:
# Based on a specific supermarket in Boulder, Colorado.
# Horizontal dimensions estimated from Google Maps (using scale), height using pictures from Google Street View (using people present for scale)
# Ventilation rate estimated from ASHRAE standard in Readme page
# Occupancy typical daily average, based on my visits to the space pre-pandemic (may be lower now.
# Other parameters estimated per Readme for this situation
# This is for a supermarket worker. For a customer, change the time spent in the story to e.g. 1 hr, 4 times a week to simulate 1 month

import math
import src.parameters.params as params

class VirusModel:
    def __init__(self):
        self._duration = params.timeInRoom  # Units: min. Value for your situation of interest.
        self._fractionNumberOfPeopleWithMasks = params.fractionNumberOfPeopleWithMasks/100  # Value for your situation. It is applied to everybody for both emission & inhalation. Modify formulas manually if needed.
        self._fractionNumberOfPopulationImmune = params.percentagerOfPopulationImmune/100  # From vaccination or disease (seroprevalence reports), will depend on each location and time, see Readme.
        self._probabilityOfBeingInfective = params.probabilityOfBeingInfective/100  # Very important parameter, specific for each region and time period. For ABSOLUTE results (prob. given the prevalence of disease in the population). See the Readme sheet.

        self._occupancy = 40  # Value for your situation of interest.


        #estimated (googel maps) area on floor 5.900 m^2 =>  approx. 270 m^2 per room
        self._lengthOfRoom = 14 #15.3  # Units: m.
        self._widthOfRoom = 19 # 9.2  # Units: m.
        self._heightOfRoom = 5.5  # Units: m.

        self._pressure = 0.95  # Units: atm. Used only for CO2 calculation.
        self._temperature = 20  # Units: C. Use web converter (https://www.google.com/search?q=fahrenheit+to+c+converter) if needed for F --> C. Used for CO2 calculation, eventually for the survival rate of the virus.
        self._relativeHumidity = 50  # Units: %. Not yet used, but may eventually be used for the survival rate of the virus.
        self._backgroundCO2Outdoors = 415  # Units: ppm. See readme.


        self._numberOfRepetitionsOfEvent = 1  # Units: times. For e.g. multiple class meetings, multiple commutes in public transportation etc.
        self._ventilationWithOutsideAir = 3  # Units: h-1. Value in h-1: Readme: Same as "air changes per hour". Value in L/s/per to compare to guidelines (e.g. ASHRAE 62.1).
        self._decayRateOfTheVirus = 0.62  # Units: h-1. See Readme, can estimate for a given T, RH, UV from DHS estimator.
        self._depositionToSurfaces = 0.3  # Units: h-1. Buonnano et al. (2020), Miller et al. (2020). Could vary 0.24-1.5 h-1, depending on the particle size range.
        self._additionalControlMeasures = 0  # Units: h-1. E.g. filtering of recirc. air, HEPA air cleaner, UV disinfection, etc. See FAQs, Readme for calc for a portable HEPA filter.

        self._infectivePeople = 1  # Units: person. Keep this at one unless you really want to study different cases - see conditional and absolute results.

        self._breathingRateSusceptibles = 0.72  # Units: m3 / h. See Readme sheet - varies a lot with activity level.
        self._relativeBreathingRateFactor = 2.5  # Ratio between the actual and base breathing rates.
        self._co2EmissionRatePerPerson = 0.00675  # Units: L/s (@ 273 K and 1 atm). From tables in the Readme page. This does not affect the infection calculation, only use of CO2 as an indicator, could ignore.
        self._basicQuantaExhalationRate = 18.6  # Units: infectious doses (quanta) h-1. See the Readme sheet.
        self._quantaEnhancementDueToVariants = 2.5  # Units: dimensionless. 1 for the original variant, 2 for Delta, 2.5 for Omicron BA.1, 3.3 for Omicron BA.2. See the Readme file.
        self._quantaEnhancementDueToVocalAndActivity = 5.0  # Units: dimensionless (ratio to breathing). Relative increase in the emission rate due to vocalization and physical activity (compared to breathing).
        self._exhalationMaskEfficiency = 0.5  # 0 if the infective person is not wearing a mask. See the Readme sheet.
        self._inhalationMaskEfficiency = 0.3  # See the Readme sheet.

        self._hospitalizationRate = 0.05  # From news reports. Varies strongly with age and risk factors.
        self._deathRate = 0.005  # From news reports. Varies strongly with age and risk factors (1% typical - Higher for older / at-risk people).
        
    def getLengthOfRoom(self):
        return self._lengthOfRoom

    def setLengthOfRoom(self, lengthOfRoom):
        self._lengthOfRoom = lengthOfRoom

    def getWidthOfRoom(self):
        return self._widthOfRoom

    def setWidthOfRoom(self, widthOfRoom):
        self._widthOfRoom = widthOfRoom

    def getHeightOfRoom(self):
        return self._heightOfRoom

    def setHeightOfRoom(self, height):
        self._heightOfRoom = height

    def getVolumeOfRoom(self):
        """Default value: 766. Units: m^3. Volume, calculated."""
        volumeOfRoom = self.getLengthOfRoom() * self.getWidthOfRoom() * self.getHeightOfRoom()
        return volumeOfRoom

    def getAreaOfRoom(self):
        """Default value: 140. Units: m^2. Volume, calculated."""
        areaOfRoom = self.getLengthOfRoom() * self.getWidthOfRoom()
        return areaOfRoom

    def getPressure(self):
        return self._pressure

    def setPressure(self, pressure):
        self._pressure = pressure

    def getTemperature(self):
        return self._temperature

    def setTemperature(self, temperature):
        self._temperature = temperature

    def getRelativeHumidity(self):
        return self._relativeHumidity

    def setRelativeHumidity(self, relativeHumidity):
        self._relativeHumidity = relativeHumidity

    def getBackgroundCO2Outdoors(self):
        return self._backgroundCO2Outdoors

    def setBackgroundCO2Outdoors(self, backgroundCO2Outdoors):
        self._backgroundCO2Outdoors = backgroundCO2Outdoors

    def getDuration(self):
        return self._duration

    def setDuration(self, duratioNumberOfEvent):
        self._duration = duratioNumberOfEvent

    def getNumberOfRepetitionsOfEvent(self):
        return self._numberOfRepetitionsOfEvent

    def setNumberOfRepetitionsOfEvent(self, numberOfRepetitionsOfEvent):
        self._numberOfRepetitionsOfEvent = numberOfRepetitionsOfEvent

    def getVentilationWithOutsideAir(self):
        return self._ventilationWithOutsideAir

    def setVentilationWithOutsideAir(self, ventilationWithOutsideAir):
        self._ventilationWithOutsideAir = ventilationWithOutsideAir

    def getDecayRateOfTheVirus(self):
        return self._decayRateOfTheVirus

    def setDecayRateOfTheVirus(self, decayRateOfTheVirus):
        self._decayRateOfTheVirus = decayRateOfTheVirus

    def getDepositionToSurfaces(self):
        return self._depositionToSurfaces

    def setDepositionToSurfaces(self, depositionToSurfaces):
        self._depositionToSurfaces = depositionToSurfaces

    def getAdditionalControlMeasures(self):
        return self._additionalControlMeasures

    def setAdditionalControlMeasures(self, additionalControlMeasures):
        self._additionalControlMeasures = additionalControlMeasures

    def getOccupancy(self):
        return self._occupancy

    def setOccupancy(self, totalPeoplePresent):
        self._occupancy = totalPeoplePresent

    def getTotalFirstOrderLossRate(self):
        totalFirstOrderLossRate = (
            self.getVentilationWithOutsideAir() +
            self.getDecayRateOfTheVirus() +
            self.getDepositionToSurfaces() +
            self.getAdditionalControlMeasures()
        )
        return totalFirstOrderLossRate

    def getVentilationRatePerPerson(self):
        ventilationRatePerPerson = (
            self.getVolumeOfRoom() *
            (self.getVentilationWithOutsideAir() + self.getAdditionalControlMeasures()) *
            1000 / 3600 / self.getOccupancy()
        )
        return ventilationRatePerPerson

    def getInfectivePeople(self):
        return self._infectivePeople

    def setInfectivePeople(self, infectivePeople):
        self._infectivePeople = infectivePeople

    def getFractioNumberOfPopulationImmune(self):
        return self._fractionNumberOfPopulationImmune

    def setFractioNumberOfPopulationImmune(self, fractioNumberOfPopulationImmune):
        self._fractionNumberOfPopulationImmune = fractioNumberOfPopulationImmune

    def getSusceptiblePeople(self):
        susceptiblePeople = (self.getOccupancy() - self.getInfectivePeople()) * (1 - self.getFractioNumberOfPopulationImmune())
        return susceptiblePeople

    def getDensityInRoomAreaPerPerson(self):
        densityInRoomAreaPerPerson = self.getAreaOfRoom() / (0.305 * 0.305) / self.getOccupancy()
        return densityInRoomAreaPerPerson

    def getDensityPeoplePerAreaInRoom(self):
        densityPeoplePerAreaInRoom = self.getOccupancy() / self.getAreaOfRoom()
        return densityPeoplePerAreaInRoom

    def getDensityVolumePerPersonInRoom(self):
        densityVolumePerPersonInRoom = self.getVolumeOfRoom() / self.getOccupancy()
        return densityVolumePerPersonInRoom

    def getBreathingRateSusceptibles(self):
        return self._breathingRateSusceptibles
        
    def setBreathingRateSusceptibles(self, breathingRateSusceptibles):
        self._breathingRateSusceptibles = breathingRateSusceptibles

    def getRelativeBreathingRateFactor(self):
        return self._relativeBreathingRateFactor

    def setRelativeBreathingRateFactor(self, relativeBreathingRateFactor):
        self._relativeBreathingRateFactor = relativeBreathingRateFactor

    def getCo2EmissionRatePerPerson(self):
        return self._co2EmissionRatePerPerson

    def setCo2EmissionRatePerPerson(self, co2EmissionRatePerPerson):
        self._co2EmissionRatePerPerson = co2EmissionRatePerPerson

    def getCO2EmissionRateAllPersons(self):
        co2EmissionRateAllPersons = (
                self.getCo2EmissionRatePerPerson() * self.getOccupancy() *
                (1 / self.getPressure()) * (273.15 + self.getTemperature()) / 273.15
        )
        return co2EmissionRateAllPersons

    def getBasicQuantaExhalationRate(self):
        return self._basicQuantaExhalationRate

    def setBasicQuantaExhalationRate(self, basicQuantaExhalationRate):
        self._basicQuantaExhalationRate = basicQuantaExhalationRate

    def getQuantaEnhancementDueToVariants(self):
        return self._quantaEnhancementDueToVariants

    def setQuantaEnhancementDueToVariants(self, quantaEnhancementDueToVariants):
        self._quantaEnhancementDueToVariants = quantaEnhancementDueToVariants

    def getQuantaEnhancementDueToVocalAndActivity(self):
        return self._quantaEnhancementDueToVocalAndActivity
        
    def setQuantaEnhancementDueToVocalAndActivity(self, quantaEnhancementDueToVocalAndActivity):
        self._quantaEnhancementDueToVocalAndActivity = quantaEnhancementDueToVocalAndActivity

    def getQuantaExhalationRateInfected(self):
        quantaExhalationRateInfected = (
            self.getBasicQuantaExhalationRate() * 
            self.getQuantaEnhancementDueToVariants() * 
            self.getQuantaEnhancementDueToVocalAndActivity()
        )
        return quantaExhalationRateInfected

    def getExhalationMaskEfficiency(self):
        return self._exhalationMaskEfficiency

    def setExhalationMaskEfficiency(self, exhalationMaskEfficiency):
        self._exhalationMaskEfficiency = exhalationMaskEfficiency

    def getFractioNumberOfPeopleWithMasks(self):
        return self._fractionNumberOfPeopleWithMasks

    def setFractioNumberOfPeopleWithMasks(self, fractioNumberOfPeopleWithMasks):
        self._fractionNumberOfPeopleWithMasks = fractioNumberOfPeopleWithMasks

    def getInhalationMaskEfficiency(self):
        return self._inhalationMaskEfficiency

    def setInhalationMaskEfficiency(self, inhalationMaskEfficiency):
        self._inhalationMaskEfficiency = inhalationMaskEfficiency

    def getProbabilityOfBeingInfective(self):
        return self._probabilityOfBeingInfective

    def setProbabilityOfBeingInfective(self, probabilityOfBeingInfective):
        self._probabilityOfBeingInfective = probabilityOfBeingInfective

    def getHospitalizationRate(self):
        return self._hospitalizationRate

    def setHospitalizationRate(self, hospitalizationRate):
        self._hospitalizationRate = hospitalizationRate

    def getDeathRate(self):
        return self._deathRate

    def setDeathRate(self, deathRate):
        self._deathRate = deathRate

    def getDuratioNumberOfEventInHours(self):
        return self.getDuration() / 60
        
    #CONDITIONAL result for ONE EVENT: we assume the number of infected people above, and get the results under that assumption.
    #More appropriate to simulate known outbreaks (e.g. choir, restaurant etc.), and an worst-case scenario for regular events (if one is unlucky enough to have infective people in attendance of a given event).
    
    def getNetEmissionRate(self):
        netEmissionRate = (
            self.getQuantaExhalationRateInfected() *
            (1 - self.getExhalationMaskEfficiency() * self.getFractioNumberOfPeopleWithMasks()) *
            self.getInfectivePeople()
        )
        return netEmissionRate

    def getAvgQuantaConcentration(self):
        avgQuantaConcentration = (
            (self.getNetEmissionRate() /
             self.getTotalFirstOrderLossRate() /
             self.getVolumeOfRoom()) *
            (1 - (1 / self.getTotalFirstOrderLossRate() / self.getDuratioNumberOfEventInHours()) *
             (1 - math.exp(-self.getTotalFirstOrderLossRate() * self.getDuratioNumberOfEventInHours())))
        )
        return avgQuantaConcentration

    def getQuantaInhaledPerPerson(self):
        quantaInhaledPerPerson = (
            self.getAvgQuantaConcentration() *
            self.getBreathingRateSusceptibles() *
            self.getDuratioNumberOfEventInHours() *
            (1 - self.getInhalationMaskEfficiency() * self.getFractioNumberOfPeopleWithMasks())
        )
        return quantaInhaledPerPerson

    def getProbabilityOfInfectionOnePersonConditionalResults(self):
        return 1 - math.exp(-self.getQuantaInhaledPerPerson())

    def getProbabilityOfHospitalizationOnePersonConditionalResults(self):
        return self.getProbabilityOfInfectionOnePersonConditionalResults() * self.getHospitalizationRate()

    def getProbabilityOfDeathOnePersonConditionalResults(self):
        return self.getProbabilityOfInfectionOnePersonConditionalResults() * self.getDeathRate()

    def getRatioToRiskOfCarTravelDeathConditionalResults(self):
        return self.getProbabilityOfDeathOnePersonConditionalResults() / 0.0000006

    def getNumberOfCOVIDCasesArisingConditionalResults(self):
        return self.getSusceptiblePeople() * self.getProbabilityOfInfectionOnePersonConditionalResults()

    def getNumberOfHospitalizationsArisingConditionalResults(self):
        return self.getNumberOfCOVIDCasesArisingConditionalResults() * self.getHospitalizationRate()

    def getNumberOfDeathsArisingConditionalResults(self):
        return self.getNumberOfCOVIDCasesArisingConditionalResults() * self.getDeathRate()

    # Airborne Infection Risk Parameters (From Peng et al., 2022).

    def getInfectionRiskParameterH(self):
        infectionRiskParameterH = (
            self.getRelativeBreathingRateFactor() *
            self.getQuantaEnhancementDueToVocalAndActivity() *
            (1 - self.getExhalationMaskEfficiency() * self.getFractioNumberOfPeopleWithMasks()) *
            (1 - self.getInhalationMaskEfficiency() * self.getFractioNumberOfPeopleWithMasks()) *
            self.getDuratioNumberOfEventInHours() * self.getSusceptiblePeople() /
            (self.getTotalFirstOrderLossRate() * self.getVolumeOfRoom()) *
            (1 - (1 - math.exp(-self.getTotalFirstOrderLossRate() * self.getDuratioNumberOfEventInHours())) /
             (self.getTotalFirstOrderLossRate() * self.getDuratioNumberOfEventInHours()))
        )
        return infectionRiskParameterH

    def getRelativeInfectionRiskParameterHr(self):
        relativeInfectionRiskParameterHr = (
            self.getRelativeBreathingRateFactor() *
            self.getQuantaEnhancementDueToVocalAndActivity() *
            (1 - self.getExhalationMaskEfficiency() * self.getFractioNumberOfPeopleWithMasks()) *
            (1 - self.getInhalationMaskEfficiency() * self.getFractioNumberOfPeopleWithMasks()) *
            self.getDuratioNumberOfEventInHours() /
            (self.getTotalFirstOrderLossRate() * self.getVolumeOfRoom()) *
            (1 - (1 - math.exp(-self.getTotalFirstOrderLossRate() * self.getDuratioNumberOfEventInHours())) /
             (self.getTotalFirstOrderLossRate() * self.getDuratioNumberOfEventInHours()))
        )
        return relativeInfectionRiskParameterHr

    # Results for CO2 as an indicator of risk (not needed for infection estimation, can ignore for simplicity).
        
    def getAvgCO2MixingRatio(self):
        avgCO2MixingRatio = (
            (self.getCO2EmissionRateAllPersons() * 3.6 / self.getVentilationWithOutsideAir() / self.getVolumeOfRoom() *
             (1 - (1 / self.getVentilationWithOutsideAir() / self.getDuratioNumberOfEventInHours()) *
              (1 - math.exp(-self.getVentilationWithOutsideAir() * self.getDuratioNumberOfEventInHours())))) * 1000000 + 400
        )
        return avgCO2MixingRatio

    def getAvgCO2Concentration(self):
        avgCO2Concentration = (
            (self.getAvgCO2MixingRatio() - 400) * 40.9 / 1000000 * 44 * 298 / (273.15 + self.getTemperature()) *
            self.getPressure() / 1
        )
        return avgCO2Concentration

    def getExhaledCO2ReinhaledPerPersonFirstComputation(self):
        exhaledCO2ReinhaledPerPersonFirstComputation = (
            self.getAvgCO2Concentration() * self.getBreathingRateSusceptibles() * self.getDuratioNumberOfEventInHours()
        )
        return exhaledCO2ReinhaledPerPersonFirstComputation

    def getExhaledCO2ReinhaledPerPersonMethodSecondComputation(self):
        exhaledCO2ReinhaledPerPersonMethodSecondComputation = (
            (self.getAvgCO2MixingRatio() - 400) * self.getDuratioNumberOfEventInHours()
        )
        return exhaledCO2ReinhaledPerPersonMethodSecondComputation

    def getExhaledCO2ReinhaledPerPersonThirdComputation(self):
        exhaledCO2ReinhaledPerPersonThirdComputation = (
            self.getExhaledCO2ReinhaledPerPersonMethodSecondComputation() / 10000
        )
        return exhaledCO2ReinhaledPerPersonThirdComputation

    def getRatioOfInfectionToExCO2(self):
        ratioOfInfectionToExCO2 = (
            self.getProbabilityOfInfectionOnePersonConditionalResults() /
            self.getExhaledCO2ReinhaledPerPersonThirdComputation()
        )
        return ratioOfInfectionToExCO2

    def getCO2ToInhale1HrFor1PercentInfectionConditionalResults(self):
        co2ToInhale1HrFor1PercentInfectionConditionalResults = (
            (self.getAvgCO2MixingRatio() - self.getBackgroundCO2Outdoors()) * self.getDuratioNumberOfEventInHours() / 1 *
            0.01 / self.getProbabilityOfInfectionOnePersonConditionalResults() + self.getBackgroundCO2Outdoors()
        )
        return co2ToInhale1HrFor1PercentInfectionConditionalResults
    
    #ABSOLUTE result for ONE EVENT: we use the prevalence of the disease in the community to estimate how many infected people may be present in our event, and calculate results based on that.
    #More appropriate for general risk estimation, e.g. in a college classroom, indoor gathering etc., where often infective people will not be present.

    def getNumberOfInfectivePeoplePresent(self):
        # Default value: 0.184. It has to be interpreted statistically.
        # This would be the average over e.g., 100 repetitions of the event in a given location.
        return (self.getInfectivePeople() + self.getSusceptiblePeople()) * self.getProbabilityOfBeingInfective()

    #Absolute results for A GIVEN PERSON & ONE EVENT (using disease prevalence in community).
    
    def getProbabilityOfInfectionOnePersonAbsoluteResults(self):
        return (1 - (1 - self.getProbabilityOfInfectionOnePersonConditionalResults() * self.getProbabilityOfBeingInfective()) ** (self.getOccupancy() - 1))

    def getProbabilityOfHospitalizationOnePersonAbsoluteResults(self):
        return self.getProbabilityOfInfectionOnePersonAbsoluteResults() * self.getHospitalizationRate()

    def getProbabilityOfDeathOnePersonAbsoluteResults(self):
        return self.getProbabilityOfInfectionOnePersonAbsoluteResults() * self.getDeathRate()

    def getRatioToRiskOfCarTravelDeathAbsoluteResults(self):
        # Times larger risk (than traveling the same number of days).
        # See FAQs for a rough estimate of death traveling by car on a given day.
        return self.getProbabilityOfDeathOnePersonAbsoluteResults() / 0.0000006

    #Absolute results for ALL ATTENDEES & ONE EVENT (using disease prevalence in community).

    def getNumberOfCOVIDCasesArisingAbsoluteResults(self):
        # Number of people.
        return (self.getSusceptiblePeople() - self.getInfectivePeople()) * self.getProbabilityOfInfectionOnePersonAbsoluteResults()

    def getNumberOfHospitalizationsArisingAbsoluteResults(self):
        # Number of people.
        return self.getNumberOfCOVIDCasesArisingAbsoluteResults() * self.getHospitalizationRate()

    def getNumberOfDeathsArisingAbsoluteResults(self):
        # Number of people.
        return self.getNumberOfCOVIDCasesArisingAbsoluteResults() * self.getDeathRate()

    def getCO2ToInhale1HrFor1PercentInfectionAbsoluteResults(self):
        # Units: ppm. This is another metric of risk.
        return (self.getAvgCO2MixingRatio() - self.getBackgroundCO2Outdoors()) * self.getDuratioNumberOfEventInHours() / 1 * 0.01 / self.getProbabilityOfInfectionOnePersonAbsoluteResults() + self.getBackgroundCO2Outdoors()

    # ABSOLUTE result for events that are REPEATED MULTIPLE TIMES (e.g. many class meetings during a semester, or a daily commute on public transportation) - Ignore for a single event.
    
    # Absolute results for A GIVEN PERSON & MULTIPLE EVENTS (using disease prevalence in community).

    def getProbabilityOfInfectionOnePersonAbsoluteResultsMultipleEvents(self):
        return 1 - (1 - self.getProbabilityOfInfectionOnePersonAbsoluteResults()) ** self.getNumberOfRepetitionsOfEvent()

    def getProbabilityOfHospitalizationOnePersonAbsoluteResultsMultipleEvents(self):
        return self.getProbabilityOfInfectionOnePersonAbsoluteResultsMultipleEvents() * self.getHospitalizationRate()

    def getProbabilityOfDeathOnePersonAbsoluteResultsMultipleEvents(self):
        return self.getProbabilityOfInfectionOnePersonAbsoluteResultsMultipleEvents() * self.getDeathRate()

    def getRatioToRiskOfCarTravelDeathAbsoluteResultsMultipleEvents(self):
        # Times larger risk (than traveling the same number of days). See FAQs for a rough estimate of death traveling by car on a given day.
        return self.getProbabilityOfDeathOnePersonAbsoluteResultsMultipleEvents() / (0.0000006 * self.getNumberOfRepetitionsOfEvent())

    # Absolute results for ALL ATTENDEES & MULTIPLE EVENTS (using disease prevalence in community).

    def getNumberOfCOVIDCasesArisingAbsoluteResultsMultipleEvents(self):
        # Units: Number of people.
        return (self.getSusceptiblePeople() - self.getInfectivePeople()) * self.getProbabilityOfInfectionOnePersonAbsoluteResultsMultipleEvents()

    def getNumberOfHospitalizationsArisingAbsoluteResultsMultipleEvents(self):
        # Units: Number of people.
        return self.getNumberOfCOVIDCasesArisingAbsoluteResultsMultipleEvents() * self.getHospitalizationRate()

    def getNumberOfDeathsArisingAbsoluteResultsMultipleEvents(self):
        # Units: Number of people.
        return self.getNumberOfCOVIDCasesArisingAbsoluteResultsMultipleEvents() * self.getDeathRate()

    @staticmethod
    def formatS(value):
        formattedValue = VirusModel.getValueAsStringWithoutEnotation(value)
        return formattedValue

    @staticmethod
    def getValueAsStringWithoutEnotation(value):
        formattedValue = "{:.2f}".format(value)
        return formattedValue

    def printAll(self):
        print("Length of Room: {} m".format(self.formatS(self.getLengthOfRoom())))
        print("Width of Room: {} m".format(self.formatS(self.getWidthOfRoom())))
        print("Height of Room: {} m".format(self.formatS(self.getHeightOfRoom())))
        print("Volume of Room: {} m3".format(self.formatS(self.getVolumeOfRoom())))
        print("Area of Room: {} m2".format(self.formatS(self.getAreaOfRoom())))

        print("")
        print("Pressure: {} atm".format(self.formatS(self.getPressure())))
        print("Temperature: {} C".format(self.formatS(self.getTemperature())))
        print("Relative Humidity: {} %".format(self.formatS(self.getRelativeHumidity())))
        print("Background CO2 Outdoors: {} ppm".format(self.formatS(self.getBackgroundCO2Outdoors())))

        print("Duration of Event: {} min".format(self.formatS(self.getDuration())))


        print("Number of Repetitions of Event: {} times".format(self.formatS(self.getNumberOfRepetitionsOfEvent())))
        print("Ventilation With Outside Air: {} h-1".format(self.formatS(self.getVentilationWithOutsideAir())))
        print("Decay Rate of the Virus: {} h-1".format(self.formatS(self.getDecayRateOfTheVirus())))
        print("Deposition to Surfaces: {} h-1".format(self.formatS(self.getDepositionToSurfaces())))
        print("Additional Control Measures: {} h-1".format(self.formatS(self.getAdditionalControlMeasures())))
        print("Total First Order Lost Rate: {} h-1".format(self.formatS(self.getTotalFirstOrderLossRate())))

        print("")
        print("Ventilation Rate Per Person: {} L/s/person".format(self.formatS(self.getVentilationRatePerPerson())))

        print("")

        print("Total People Present: {} persons".format(self.formatS(self.getOccupancy())))

        print("Infective People: {} persons".format(self.formatS(self.getInfectivePeople())))
        print("Percentage of Population Immune: {}%".format(self.formatS(self.getFractioNumberOfPopulationImmune())))
        print("Susceptible People: {} people".format(self.formatS(self.getSusceptiblePeople())))

        print("")
        print("Breathing Rate Susceptibles: {} m3 / h".format(self.formatS(self.getBreathingRateSusceptibles())))
        print("Relative Breathing Rate Factor: {}".format(self.formatS(self.getRelativeBreathingRateFactor())))
        print("CO2 Emission Rate Per Person: {} L/s (@ 273 K and 1 atm)".format(self.formatS(self.getCo2EmissionRatePerPerson())))
        print("CO2 Emission Rate All Persons: {} L/s (@ at actual P & T of room)".format(self.formatS(self.getCO2EmissionRateAllPersons())))

        print("")
        print("Basic Quanta Exhalation Rate: {} infectious doses (quanta) h-1".format(self.formatS(self.getBasicQuantaExhalationRate())))
        print("Quanta Enhancement Due To Variants: {}".format(self.formatS(self.getQuantaEnhancementDueToVariants())))
        print("Quanta Enhancement Due To Vocal And Activity: {}".format(self.formatS(self.getQuantaEnhancementDueToVocalAndActivity())))
        print("Quanta Exhalation Rate (Infected): {} infectious doses (quanta) h-1".format(self.formatS(self.getQuantaExhalationRateInfected())))

        print("")

        print("Exhalation Mask Efficiency: {}%".format(self.formatS(self.getExhalationMaskEfficiency() * 100)))
        print("Fraction of People With Masks: {}%".format(self.formatS(self.getFractioNumberOfPeopleWithMasks() * 100)))
        print("Inhalation Mask Efficiency: {}%".format(self.formatS(self.getInhalationMaskEfficiency() * 100)))
        print("Probability of Being Infective: {}%".format(self.formatS(self.getProbabilityOfBeingInfective() * 100)))


        print("")

        print("")
        print("Hospitalization Rate: {}%".format(self.formatS(self.getHospitalizationRate() * 100)))
        print("Death Rate: {}%".format(self.formatS(self.getDeathRate() * 100)))

        print("")
        print("CONDITIONAL result for ONE EVENT: we assume the number of infected people above, and get the results under that assumption")

        print("")
        print("Net Emission Rate: {}".format(self.formatS(self.getNetEmissionRate())))
        print("Avg Quanta Concentration: {}".format(self.formatS(self.getAvgQuantaConcentration())))
        print("Quanta Inhaled Per Person: {}".format(self.formatS(self.getQuantaInhaledPerPerson())))

        print("")
        print("Conditional Results for A GIVEN PERSON & ONE EVENT (assuming number of infected above, typically 1)")
        print("Probability of Infection (1 person) Conditional Results: {}%".format(self.formatS(self.getProbabilityOfInfectionOnePersonConditionalResults() * 100)))
        print("Probability of Hospitalization (1 person) Conditional Results: {}%".format(self.formatS(self.getProbabilityOfHospitalizationOnePersonConditionalResults() * 100)))
        print("Probability of Death (1 person) Conditional Results: {}%".format(self.formatS(self.getProbabilityOfDeathOnePersonConditionalResults() * 100)))
        print("Ratio to Risk of Car Travel Death Conditional Results: {} times larger risk".format(self.formatS(self.getRatioToRiskOfCarTravelDeathConditionalResults())))

        print("")
        print("Conditional Results for ALL ATTENDEES & ONE EVENT (assuming number of infected above, typically 1)")
        print("Number of COVID Cases Arising Conditional Results: {} people".format(self.formatS(self.getNumberOfCOVIDCasesArisingConditionalResults())))
        print("Number of Hospitalizations Arising Conditional Results: {} people".format(self.formatS(self.getNumberOfHospitalizationsArisingConditionalResults())))
        print("Number of Deaths Arising Conditional Results: {} people".format(self.formatS(self.getNumberOfDeathsArisingConditionalResults())))

        print("")
        print("Airborne Infection Risk Parameters (From Peng et al., 2022)")
        print("Infection Risk Parameter H: {} h2 person / m3".format(self.formatS(self.getInfectionRiskParameterH())))
        print("Relative Infection Risk Parameter Hr: {} h2 / m3".format(self.formatS(self.getRelativeInfectionRiskParameterHr())))

        print("")
        print("Results for CO2 as an indicator of risk (not needed for infection estimation, can ignore for simplicity)")
        print("Avg CO2 Mixing Ratio: {} ppm".format(self.getAvgCO2MixingRatio()))
        print("Avg CO2 Concentration: {} g m-3".format(self.getAvgCO2Concentration()))
        print("Exhaled CO2 Reinhaled Per Person (First Computation): {} grams".format(self.formatS(self.getExhaledCO2ReinhaledPerPersonFirstComputation())))
        print("Exhaled CO2 Reinhaled Per Person (Second Computation): {} ppm * h".format(self.formatS(self.getExhaledCO2ReinhaledPerPersonMethodSecondComputation())))
        print("Exhaled CO2 Reinhaled Per Person (Third Computation): {} %CO2 * h".format(self.formatS(self.getExhaledCO2ReinhaledPerPersonThirdComputation())))
        print("Ratio of Infection to ExCO2: {}%".format(self.formatS(self.getRatioOfInfectionToExCO2())))
        print("CO2 To Inhale 1 Hr For 1 Percent Infection Conditional Results: {} ppm".format(self.formatS(self.getCO2ToInhale1HrFor1PercentInfectionConditionalResults())))

        print("")
        print("ABSOLUTE result for ONE EVENT: we use the prevalence of the disease in the community to estimate how many infected people may be present in our event, and calculate results based on that")

        print("")

        print("N of Infective People Present: {} people".format(self.formatS(self.getNumberOfInfectivePeoplePresent())))

        print("")
        print("Absolute results for A GIVEN PERSON & ONE EVENT (using disease prevalence in community)")
        print("Probability of Infection (1 person) Absolute Results: {}%".format(self.formatS(self.getProbabilityOfInfectionOnePersonAbsoluteResults() * 100)))

        print("Probability of Hospitalization (1 person) Absolute Results: {}%".format(self.formatS(self.getProbabilityOfHospitalizationOnePersonAbsoluteResults() * 100)))
        print("Probability of Death (1 person) Absolute Results: {}%".format(self.formatS(self.getProbabilityOfDeathOnePersonAbsoluteResults() * 100)))
        print("Ratio to Risk of Car Travel Death Absolute Results: {} times larger risk".format(self.formatS(self.getRatioToRiskOfCarTravelDeathAbsoluteResults())))

        print("")
        print("Absolute results for ALL ATTENDEES & ONE EVENT (using disease prevalence in community)")
        print("Number of COVID Cases Arising Absolute Results: {} people".format(self.formatS(self.getNumberOfCOVIDCasesArisingAbsoluteResults())))
        print("Number of Hospitalizations Arising Absolute Results: {} people".format(self.formatS(self.getNumberOfHospitalizationsArisingAbsoluteResults())))
        print("Number of Deaths Arising Absolute Results: {} people".format(self.formatS(self.getNumberOfDeathsArisingAbsoluteResults())))

        print("")
        print("CO2 To Inhale 1 Hr For 1 Percent Infection Absolute Results: {} ppm".format(self.formatS(self.getCO2ToInhale1HrFor1PercentInfectionAbsoluteResults())))

        print("")
        print("ABSOLUTE result for events that are REPEATED MULTIPLE TIMES (e.g. many class meetings during a semester, or a daily commute on public transportation) - Ignore for a single event")

        print("")
        print("Absolute results for A GIVEN PERSON & MULTIPLE EVENTS (using disease prevalence in community)")
        print("Probability of Infection (1 person) Absolute Results Multiple Events: {}%".format(self.formatS(self.getProbabilityOfInfectionOnePersonAbsoluteResultsMultipleEvents() * 100)))
        print("Probability of Hospitalization (1 person) Absolute Results Multiple Events: {}%".format(self.formatS(self.getProbabilityOfHospitalizationOnePersonAbsoluteResultsMultipleEvents() * 100)))
        print("Probability of Death (1 person) Absolute Results Multiple Events: {}%".format(self.formatS(self.getProbabilityOfDeathOnePersonAbsoluteResultsMultipleEvents() * 100)))
        print("Ratio to Risk of Car Travel Death Absolute Results Multiple Events: {} times larger risk".format(self.formatS(self.getRatioToRiskOfCarTravelDeathAbsoluteResultsMultipleEvents())))

        print("")
        print("Absolute results for ALL ATTENDEES & ONE EVENT (using disease prevalence in community)")
        print("Number of COVID Cases Arising Absolute Results Multiple Events: {} people".format(self.formatS(self.getNumberOfCOVIDCasesArisingAbsoluteResultsMultipleEvents())))
        print("Number of Hospitalizations Arising Absolute Results Multiple Events: {} people".format(self.formatS(self.getNumberOfHospitalizationsArisingAbsoluteResultsMultipleEvents())))
        print("Number of Deaths Arising Absolute Results Multiple Events: {} people".format(self.formatS(self.getNumberOfDeathsArisingAbsoluteResultsMultipleEvents())))



    def printSpecifics(self):
        print("Duration: {} min".format(self.formatS(self.getDuration())))
        print("Occupancy: {} persons".format(self.formatS(self.getOccupancy())))
        print()
        #print("Exhalation Mask Efficiency: {}%".format(self.formatS(self.getExhalationMaskEfficiency() * 100)))
        print("Fraction of People With Masks: {}%".format(self.formatS(self.getFractioNumberOfPeopleWithMasks() * 100)))
        print("Fraction of Population Immune: {}%".format(self.formatS(self.getFractioNumberOfPopulationImmune()*100)))
        print("Probability of Being Infective: {}%".format(self.formatS(self.getProbabilityOfBeingInfective() * 100)))
        # print("Inhalation Mask Efficiency: {}%".format(self.formatS(self.getInhalationMaskEfficiency() * 100)))
        print("Probability of Infection (1 person) Absolute Results: {}%".format(self.formatS(self.getProbabilityOfInfectionOnePersonAbsoluteResults() * 100)))
        print("N of Infective People Present: {} people".format(self.formatS(self.getNumberOfInfectivePeoplePresent())))

    def risk_in_percent(self, occupancy = 20, duration = 20):
        self.setDuration(duration)
        self.setOccupancy(occupancy)
        risk = 100* self.getProbabilityOfInfectionOnePersonAbsoluteResults()
        return max(0.0, risk)




if __name__ == "__main__":
    model = VirusModel()
    model.printAll()

    duration = 20
    print('--------------  duration:', duration, '  -----------  ')
    for nbOfPeople in range(0, 220, 20):
        risk = model.risk_in_percent(nbOfPeople, duration)
        print('occupancy:', nbOfPeople, '   risk:', round(risk, 3))

    risk = model.risk_in_percent(100, 10000)
    print()
    print(risk)

    print()
    print()

    occ = 40
    print('--------------  occupancy:', occ, '  -----------  ')
    for dur in range(10, 100, 10):
        risk = model.risk_in_percent(occ, dur)
        print('duration:', dur, '   risk:', round(risk, 3))

    duration = 1
    risk = model.risk_in_percent(occ, duration)
    print()
    print('occupancy:', occ, '  duration:', duration, '   risk:', round(risk, 3) )

    print()
    print('======================')
    model.printSpecifics()
