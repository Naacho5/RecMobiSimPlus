#recommender
nbOfSimilarArtworks = 200                       # the number of similar artworks considered for each artwork (by the method 'calculate_similar_nodes()'
resultSetLength = 20                            # length of the recommendation list (k)


# user profile parameters
nbOfFavorites = 20                             # number of randomly drawn favorites
nbOfStyles = 3                                 # number of randomly drawn favorite styles

# time behavior in rooms
timeToPassRoom = 1                             # in minutes: time a user needs just to pass a room
timeInFrontOfArtwork = 5                       # in minutes: assumed time a user stays in front of an interesting artwork

estimateTimeInRooms = True                     # True: assumes Default
timeInRoom = 20                                # in minutes: depends on user => assumed default time a user stays in a room with interesting artworks


#risk model
fractionNumberOfPeopleWithMasks = 0             # in percent Formerly 5%
probabilityOfBeingInfective = 2                 #in percent
percentagerOfPopulationImmune = 5               #in percent
risk_threshold_in_percent = 0.1                   # don't stay in a room with a risk higher than 1%

artwork_location_random = True
