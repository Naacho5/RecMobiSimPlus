import src.entitites.user


if __name__ == '__main__':
    user = src.entitites.user.User()
    recommender = user.getRecommender()

    # current occupancy in each room
    #     => from simulator
    occupancy = [24, 50, 34, 79, 50, 80, 31, 57, 39, 40,
                 34, 27, 55, 45, 30, 34, 67, 32, 65, 22, 25 ]

    print('####################### RECOMMENDATION  WITHOUT RISK CONSIDERATION ######################')

    print('\n----------------- Tour  ---------------------')
    result_set = recommender.getTour()
    for r in result_set:
        print(r)
    print('--- number of recommendations:', len(result_set))
    print('\nvisted rooms:', recommender.getRooms(result_set))

    print('\n----------------- Path  ---------------------')
    path = recommender.getRecommendationPath(result_set, startRoom=402)
    print('! Path:', path)
    #printPath(result_set, path, occupancy)


    print('\n####################### RECOMMENDATION  WITH RISK CONSIDERATION ######################')
    # current sojourn time in each room:
    #     => from simulator
    duration = [30, 10, 5, 21, 5, 47, 60, 23, 12, 5,
                22, 5, 17, 23, 22, 5, 8, 4, 32, 15, 25 ]

    print('\n----------------- Tour  ---------------------')
    # occupancy = current occupancy in each room
    #       => input of simulator
    #       => for the current location of user the average occupancy after he has entered?
    # duration = vector with duration of stay in every room
    #       => for each room: previous time of stay (from simulator)  + estimated time in front of next artwork
    #       => when leaving a room: sojourn time is set to 0
    result_set = recommender.getTourWithRisk(occupancy, duration)
    for r in result_set:
        print(r)
    print('--- number of recommendations:', len(result_set))
    print('\nvisted rooms:', recommender.getRooms(result_set))

    print('\n--------------- Path  --------------------')
    path = recommender.getRecommendationPath(result_set)
    print('! Path:', path)

    '''
    print('\n####################### DO NOT REVIST ARTWORKS ######################')
    print('\n----------------- Tour  ---------------------')
    yet_visited = result_set[:3]
    result_set = recommender.getTourWithRisk(occupancy, duration, yet_visited)
    for r in result_set:
        print(r)
    print('--- number of recommendations:', len(result_set))
    print('\nvisted rooms:', recommender.getRooms(result_set))

    print('\n--------------- Path  --------------------')
    path = recommender.getRecommendationPath(result_set)
    print('! Path:', path)
    '''

