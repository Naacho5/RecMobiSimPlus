import random

def precision(k):
    nbOfAllArtists = 634
    favorites = []
    for i in range(k):
        n = random.randint(0,nbOfAllArtists)
        favorites.append(n)
    #print('favorites:', favorites)

    recommendations = []
    for i in range(k):
        r = random.randint(0, nbOfAllArtists)
        recommendations.append(r)
    #print('recommendations:', recommendations)

    hits = 0
    for r in recommendations:
        if r in favorites:
            hits += 1
    precision = hits/k
    return precision
    #print()
    #print()


#main
k = 10                   # corresponds to precision@k
nbOfExperiments = 100000

precision_sum = 0
successful_recommendation = 0
for exp in range(nbOfExperiments):
    precision_result = precision(k)
    precision_sum += precision_result
    if precision_result > 0:
        successful_recommendation += 1

print('nbOfExperiments:', nbOfExperiments)
print('number of successful recommendations:', successful_recommendation)
print('k =', k, '   precision@k', precision_sum / nbOfExperiments)