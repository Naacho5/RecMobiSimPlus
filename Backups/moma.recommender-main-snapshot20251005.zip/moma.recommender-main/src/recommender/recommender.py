import src.entitites.user
import src.entitites.artwork
from src.entitites.recommendation import Recommendation
from src.recommender.similarityfinder import SimilarityFinder
from src.mapping.mapper import Mapper
import src.parameters.params as params
import src.pathfinder.floorplan as floorplan
import src.covid_model.virus_model as risk_model

import math
import numpy as np

class Recommender:

    def __init__(self, favoriteIDs):
        self.favoriteIDs = favoriteIDs                 #list of the MoMA IDs of the users favorite artworks
        # init helper objects and result set
        self.similarityFinder = SimilarityFinder()
        self.mapper = Mapper()
        self.model = risk_model.VirusModel()            # virus model from Colorodo university

        # store important results
        self.recommendationScores = {}                  # dictionary {<nodeId> <score>} -- related to all favorites (=score sum) of the user
                                                        # ordered according to score
        self.recommendedArtworks = None
        self.__calculate_scores_and_recommendations()     # calculate scores for all artworks and a sorted list of artworks according to their score

    def setTrainingIDs(self, trainingIDs):
        self.favoriteIDs = trainingIDs

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! WITHOUT RISK !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # key method of this class: calculates the recommended artworks and scores without taking the risk into account
    # invoked in __init__()
    def __calculate_scores_and_recommendations(self):
        # get the similar nodes for each favorite artwork and add multiple scores:
        for moma_id in self.favoriteIDs:
            distances = self.___getDistancesForArtwork(moma_id)
            self.___mergeRecommendationScores(distances)        # add multiple scores of the same recommended artwork into self.recommendationScores{}

        # sort the recommendation scores:
        self.recommendationScores = sorted(self.recommendationScores.items(), key=lambda x: x[1], reverse=True) # makes list from dictionary !!

        # fill the result set of artworks in 'self.recommendedArtworks'
        self.recommendedArtworks = []
        for score in self.recommendationScores:
            artwork = self.getArtworkFromScore(score)
            self.recommendedArtworks.append(artwork)

    def ___getDistancesForArtwork(self, moma_id):
        # scores are related to the graph and work with node ids
        node_id = self.mapper.getNodeID_4_momaID(moma_id)

        # get similar artworks for this node_id (this particular artwork)
        distances = self.similarityFinder.calculate_similarities(node_id)   # distance is dictionary {<nodeId> <score>} - scores are normalized

        # delete nodes with similarity 1.0 (i.e. the artwork itself)
        for dist in distances:
            if dist[1] == 1.0:
                distances.remove(dist)
        return distances

    # add all scores of an artworks (from multiple similar node lists)
    def ___mergeRecommendationScores(self, distances):
        for dist in distances:
            nodeID = dist[0]
            distance  = dist[1]
            #self.recommendationScores = dict(self.recommendationScores)
            if nodeID not in self.recommendationScores.keys():
                self.recommendationScores[nodeID] = distance                # new nodeID not yet in self.recommendationScores
            else:
                self.recommendationScores[nodeID] += distance                # add similarities if artwork with this nodeID has already been recommended

    def getRecommdationsWithoutRisk(self):
        recommended_artworks = self.recommendedArtworks[:params.resultSetLength]
        recommendations = []
        for art in recommended_artworks:
            # rec = Recommendation(art.moma_id, art.node_id, art.room, self.getScoreOfArtwork(art.moma_id))
            rec = Recommendation(art.moma_id, art.node_id, art.room, self.getNormalisedScoreOfArtwork(art.moma_id))
            recommendations.append(rec)
        return recommendations

    # returns path of recommended artworks as list of the rooms to pass
    def getTour(self):
        recommendations = self.getRecommdationsWithoutRisk()
        path = self.getRecommendationPath(recommendations)
        rooms2visit = self.getRooms(recommendations)
        result_set = []
        for room in path:
            for rec in recommendations:
                if rec.room == room and rec.room in rooms2visit:
                    result_set.append(rec)
            if room in rooms2visit:
                rooms2visit.remove(room)
            if len(rooms2visit) == 0: break
        #print('++++++++ length of tour:', len(result_set))
        return result_set

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! WITH RISK !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    # duration als Parameter (default = time for artwork)
    # Einzelrisiko berechnen
    def recommendedArtworksDueToRisk(self, occupancy, duration, already_visited_artworks=[], risk_threshold = 0.15):
        result = []
        i = 0
        while len(result) < params.resultSetLength:
            artwork = self.recommendedArtworks[i]
            
            # print('MoMMA_ID')
            # print(artwork.moma_id)
            
            if str(artwork.moma_id) not in already_visited_artworks:  # put only not-visited artworks into result set
                durationInRoom = duration[artwork.room - 401]
                occ = occupancy[artwork.room - 401]
                #print('---', occupancy, '  --- room:', room,  '   occ:', occupancy[room - 401]  )
                if self.model.risk_in_percent(occ,durationInRoom) < risk_threshold:
                    # print('ADDS ARTWORK')
                    result.append(artwork)
            i += 1
            if i == len(self.recommendedArtworks):
                print('????????????????????????   only ', len(result), 'recommendations possible to fulfill threshold')
                break
        return result

    def getRecommdationsDueToRisk(self, occupancy, duration, already_visited_artworks=[], risk_threshold = 0.15):
        recommended_artworks = self.recommendedArtworksDueToRisk(occupancy, duration, already_visited_artworks, risk_threshold)
        recommendations = []
        #durationInRoom = duration   # !! to adapt !! => vector of durations in every room
        already_visited_Ids = self.getMomaIds(already_visited_artworks)
        for art in recommended_artworks:
            if int(art.moma_id) not in already_visited_Ids:
                durationInRoom = duration[art.room - 401]
                occ = occupancy[art.room - 401]
                risk = self.model.risk_in_percent(occ,durationInRoom)
                # rec = Recommendation(art.moma_id, art.node_id, art.room, self.getScoreOfArtwork(art.moma_id), risk)
                rec = Recommendation(art.moma_id, art.node_id, art.room, self.getNormalisedScoreOfArtwork(art.moma_id), risk)
                recommendations.append(rec)
        return recommendations

    def getTourWithRisk(self, occupancy, duration, already_visited_artworks=[], risk_threshold = 0.15):
        recommendations = self.getRecommdationsDueToRisk(occupancy, duration, already_visited_artworks, risk_threshold)
        path = self.getRecommendationPath(recommendations)
        rooms2visit = self.getRooms(recommendations)
        result_set = []
        for room in path:
            for rec in recommendations:
                if rec.room == room and rec.room in rooms2visit:
                    result_set.append(rec)
            if room in rooms2visit:
                rooms2visit.remove(room)
            if len(rooms2visit) == 0: break
        # print('++++++++ length of tour:', len(result_set))
        return result_set

    def getMomaIds(self, artworks):
        result = []
        for artwork in artworks:
            result.append(int(artwork.moma_id))
        return result

    # !!!!!!!!!!!!!!!!! PATH !!!!!!!!!!!!!!!!!!!!!!
    # returns path of recommended artworks as list of the rooms to pass
    def getRecommendationPath(self, artworks, startRoom=401):
        # get recommended rooms
        roomsWithRecommendations = self.getRooms(artworks)
        #print('rooms with recomms:', roomsWithRecommendations)
        fp = floorplan.Floorplan()
        path = fp.findRoute(startRoom, roomsWithRecommendations)
        return path

    # !!!!!!!!!!!! getter  !!!!!!!!!!!!!!!!!!!!!
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # returns a list of nodeIDs of the recommended artworks in a certain room
    # (an empty list if there are no recommended artworks in that room)

    def getRooms(self, artworks):
        visited_rooms = []
        for artwork in artworks:
            if artwork.room not in visited_rooms:
                visited_rooms.append(int(artwork.room))
        return visited_rooms

    def getArtworkFromScore(self, recommendationScore):
        return self.mapper.getArtwork4NodeID(recommendationScore[0])

    def getRcommendationScores(self):
        return self.recommendationScores

    def getScoreOfArtwork(self, momaId):
        nodeID = self.mapper.getNodeID_4_momaID(momaId)
        for score in self.recommendationScores:
            if score[0]== nodeID:
                return score[1]
        return 'error'
    
    # S_norm = (S-S_min) / (S_max-S_min)
    def getNormalisedScoreOfArtwork(self, momaId):
        nodeID = self.mapper.getNodeID_4_momaID(momaId)
        # 01. Min-Max
        # min = 100000.0
        # max = 0.0
        # scoreToReturn = 0.0
        # for score in self.recommendationScores:
        #     if score[1] < min:
        #         min = score[1]
        #     if score[1] > max:
        #         max = score[1]
        #     if score[0]== nodeID:
        #         scoreToReturn = score[1]
      
        # return (scoreToReturn-min)/(max-min)
    
        # 02. Sigmoid
        # gamma = 5.0
        # for score in self.recommendationScores:
        #     if score[0]== nodeID:
        #         return 1.0/(1 + math.exp(gamma*(score[1]-0.5)))
        # return 'error'
    
        # 03. Log normalisation
        k = 10
        for score in self.recommendationScores:
            if score[0]== nodeID:
                return np.log(1 + k * score[0]) / np.log(1 + k)
        
        return 'null'

# helper function to print the path with the visited artworks:
def printPath(result, path, occcupancy):
   print('Path:', path)
   print('\nPATH WITH ROOMS AND ARTWORKS:')
   previousPath = []
   for room in path:
       idx = int(room) - 401
       occ = occupancy[idx]
       if room not in previousPath:
           previousPath.append(room)
           artworks = recommender.getArtworksInRoom(room, result)
       else: artworks = []
       if len(artworks) > 0:
           print(room, '(occupancy:', occ, '):', artworks)
       else:
           print(room, '(occupancy:', occ, '):   pass!')



if __name__ == '__main__':
    user = src.entitites.user.User()
    print(user)

    recommender = user.getRecommender()

    # current occupancy in each room
    occupancy = [24, 50, 34, 79, 50, 80, 31, 57, 39, 40,
                 34, 27, 55, 45, 30, 34, 67, 32, 65, 22, 25 ]

    print('####################### RECOMMENDATION  WITHOUT RISK CONSIDERATION ######################')

    print('\n----------------- Tour  ---------------------')
    result_set = recommender.getTour()
    for r in result_set:
        print(r)
    print('--- number of recommendations:', len(result_set))
    print('\nvisted rooms:', recommender.getRooms(result_set))

    print('\n----------------- Path  ---------------------')
    path = recommender.getRecommendationPath(result_set)
    print('! Path:', path)
    #printPath(result_set, path, occupancy)


    print('\n####################### RECOMMENDATION  WITH RISK CONSIDERATION ######################')
    # current sojourn time in each room:
    duration = [30, 10, 5, 21, 5, 47, 60, 23, 12, 5,
                 22, 5, 17, 23, 22, 5, 8, 4, 32, 15, 25 ]

    print('\n----------------- Tour  ---------------------')
    # occupancy = current occupancy in each room
    #       => input of simulator
    #       => for the current location of user the average occupancy after he has entered?
    # duration = vector with duration of stay in every room
    #       => for each room: previous time of stay (from simulator)  + estimated time in front of next artwork
    #       0> when leaving a room: sojourn time is set to 0
    result_set = recommender.getTourWithRisk(occupancy, duration)
    for r in result_set:
        print(r)
    print('--- number of recommendations:', len(result_set))
    print('\nvisted rooms:', recommender.getRooms(result_set))

    print('\n--------------- Path  --------------------')
    path = recommender.getRecommendationPath(result_set)
    print('! Path:', path)

    '''
    print('\n####################### DO NOT REVIST ARTWORKS ######################')
    print('\n----------------- Tour  ---------------------')
    yet_visited = result_set[:3]
    result_set = recommender.getTourWithRisk(occupancy, duration, yet_visited)
    for r in result_set:
        print(r)
    print('--- number of recommendations:', len(result_set))
    print('\nvisted rooms:', recommender.getRooms(result_set))

    print('\n--------------- Path  --------------------')
    path = recommender.getRecommendationPath(result_set)
    print('! Path:', path)
    '''

