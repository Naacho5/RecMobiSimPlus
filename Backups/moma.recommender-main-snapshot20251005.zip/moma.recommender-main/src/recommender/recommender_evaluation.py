from src.entitites.user import User
from src.recommender.recommender import Recommender
import src.parameters.params as params


def createAndEvaluateNewUser(userId):
    user = User(id=userId, simulation= False, evaluation=True)
    #print('--- evaluation ---', user.getEvaluationIDs())
    #print('--- training ---', user.getTrainingIDs())

    # print(user.getFavoritesIDs())

    # calculate recommendations
    recommender = user.getRecommender()
    recommendations = recommender.getTour()
    recommendationIDs = recommender.getMomaIds(recommendations)
    #print('recommendationIds:', recommendationIDs)

    #evaluate results:
    precision = calculatePrecision(recommendationIDs, user.getEvaluationIDs())
    
    avg_rating = calculate_avg_rating(user, recommendationIDs)
    
    return precision, avg_rating

def calculate_avg_rating(user, recommendationIDs):
    user_data = user.get_user_data()
    gt_rating = 0.0
    for r in recommendationIDs:       
        #print(user.user_data.loc[user_data['ObjectID'] == r, 'rating'].values[0])
        gt_rating += user.user_data.loc[user_data['ObjectID'] == r, 'rating'].values[0] # Ground truth rating
    return gt_rating/len(recommendationIDs)

def calculatePrecision(recommendationIDs, evaluationIDs):
    nbOfHits = 0
    for r in recommendationIDs:
        if r in evaluationIDs:
            #print('  ***', r)
            nbOfHits += 1
    precision = nbOfHits / len(recommendationIDs)
    print('number of recommendations:  k =', len(recommendationIDs), '   number of hits:', nbOfHits, '  precision@k:', precision)
    return precision


if __name__ == '__main__':
    numberOfExperiments = 5
    experiment_counter = 0

    avg_precision = 0.0
    overall_avg_rating = 0.0
    for i in range(1, numberOfExperiments):
        experiment_counter += 1
        print('\n **** experiment ', experiment_counter, ':')
        precision, avg_rating = createAndEvaluateNewUser(i)
        avg_precision += precision
        overall_avg_rating += avg_rating
        print('average precision', round(avg_precision / experiment_counter, 4))
        print('average rating', round(overall_avg_rating / experiment_counter, 4))

    print()
    print('##################### EVALUATION RESULT ################################')
    print('!!!!!!!! result: final average precision', round(avg_precision / experiment_counter, 4))
    print('!!!!!!!! result: final overall average rating', round(overall_avg_rating / experiment_counter, 4))
    print('from', params.resultSetLength, 'recommendations are', round(params.resultSetLength * avg_precision / experiment_counter, 4), 'relevant!')