import numpy as np
import random
import scipy
from sklearn.preprocessing import normalize

from src.mapping.mapper import Mapper
import src.parameters.params as params


class SimilarityFinder:
    #  calculates distance to all other embeddings (using Euclidean or Cosine distance)
    #  - recommends the k mot similar nodes
    # provides functions to calculate Euclidean and Cosine distances

    def __init__(self):
        self.mapper = Mapper()
        self.most_similar_nodes = None    # key = dictionary nodeID, value = similarity to given node

    #returns dictionary {<nodeId> <score>} with similarity distance as value
    def calculate_similarities(self, of_node_id):
        given_embedding = self.mapper.getEmbeddingOfNodeID(of_node_id)

        # calculate the distances between the given embedding and all other embeddings
        similarities = {}
        for node_id in self.mapper.artwork_embeddings:
            embedding = self.mapper.artwork_embeddings[node_id]     #get embedding
            similarities[node_id] = self.euclidian_distance(given_embedding, embedding)

        similarities = self.normalize_distances(similarities)  # identical vector = 1 , most different = 0
        # Sort the distances in decreasing order (regarding attribute x[1] and get the k most similar embeddings (default 200)
        self.most_similar_nodes = sorted(similarities.items(), key=lambda x: x[1], reverse=True)#[:params.nbOfSimilarArtworks]

        return self.most_similar_nodes


    def euclidian_distance(self, e1, e2):
        return np.linalg.norm(e1 - e2)

    def normalize_distances(self, dictionary):
        max_distance = max(dictionary.values())
        min_distance = min(dictionary.values())
        # subtracts normalized distance from 1 to get: best score = 1 and worst score = 0:
        scaled_distances = {key: 1 - (distance - min_distance) / (max_distance - min_distance) for key, distance in dictionary.items()}
        return scaled_distances

    # !!! not used !!!!!!
    # in interval [-1,1] with 1 identical, 0 orthogonal, -1 opposite
    def cosine_similarity(self, e1, e2):
        dot_product = np.dot(e1, e2)
        norm_vector1 = np.linalg.norm(e1)
        norm_vector2 = np.linalg.norm(e2)
        similarity = dot_product / (norm_vector1 * norm_vector2)
        return similarity
    ##############################
    def printResult(self):
        print("The most similar embeddings to the given embedding are:")
        for node_id, similarity in self.most_similar_nodes:
            print("node ID: {}, distance: {}".format(node_id, round(similarity, 4)))
            print(self.mapper.getArtwork4NodeID(node_id))
            print()

    # draw random artwork id -> for this id recommendations should be calculated
    def getRandomNodeId(self):
        node_ids = list(self.mapper.artwork_embeddings.keys())
        random.seed()
        nbOfartworks = len(self.mapper.artwork_embeddings)
        idx = random.randint(0, nbOfartworks-1)
        return node_ids[idx]       # = artwork id in graph


if __name__ == '__main__':
    sf = SimilarityFinder()

    # pick a random artwork id and get similar embeddings
    id = sf.getRandomNodeId()
    print('id:', id)

    erg = sf.calculate_similarities(id)
    sf.printResult()

    '''
    cosine_distances = [cosine_distance for _, cosine_distance in erg]
    normalized_distances = normalize([cosine_distances], norm='l2')
    normalized_list_of_tuples = [(id, normalized_distances[0][i]) for i, (id, _) in enumerate(erg)]
    '''


    max = erg[0][1]
    min = erg[0][1]
    for e in erg:
       if e[1] > max:
           max = e[1]
       if e[1] < min:
           min = e[1]
    print('min:', min, '   max:', max)

import numpy as np

def cosine_similarity(vector1, vector2):
    dot_product = np.dot(vector1, vector2)
    norm_vector1 = np.linalg.norm(vector1)
    norm_vector2 = np.linalg.norm(vector2)
    similarity = dot_product / (norm_vector1 * norm_vector2)
    return similarity

