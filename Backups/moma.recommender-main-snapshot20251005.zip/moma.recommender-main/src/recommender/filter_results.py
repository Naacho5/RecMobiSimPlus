import random

from src.entitites.user import User
from src.recommender.recommender import Recommender
import src.parameters.params as params
import src.covid_model.virus_model as risk_model
from src.mapping.mapper import Mapper

# data class for one artwork
class ArtworkData:
    def __init__(self, moma_id, room, occupancy= 0, score = 0, duration = 0, risk = 0, risk_score = 0):
        self.moma_id = moma_id
        self.room = room
        self.duration = duration
        self.occupancy = occupancy
        self.score = score
        self.risk = risk

    def __str__(self):
        return 'moma_id:' + str(self.moma_id).ljust(7) \
            + '   room:' + str(self.room) + '  occupancy:' + str(self.occupancy).ljust(4) \
            + '   duration:'  + str(self.duration).ljust(6) \
            + '  score:' + str(round(self.score,4)).ljust(16)  + '  risk:' + str(round(self.risk, 6)).ljust(22)
           # + '   risk_score:' +  str(round(self.reward(self.score, self.risk), 4)


# class contains list with infos (scores and risks) over all artworks
class RecommendationListBuilder:

    @staticmethod
    def factory_method(occupancy):
        #create user with recommendations
        user = User()
        rec = user.getRecommender()

        score_list = rec.getRcommendationScores()  # list of sorted scores <node_id, score> pairs (size: about 600
        return RecommendationListBuilder(score_list, occupancy)

    #score_list is the list of all tuples <nodeID, score> for all artworks related to a certain user
    def __init__(self, score_list, occupancy):
        self.occupancy = occupancy
        self.normalized_scores = Normalizer.normalize_scores(score_list)
        self.list_of_artwork_data = self.__calculate_scores_and_risks()

    # constructs result: a list of ArtInfo objects for all artworks
    # calculate the risk of each artwork taking the occupancy and the user's duration in the artwork room into account
    def __calculate_scores_and_risks(self):
        mapper = Mapper()
        virus_model = risk_model.VirusModel()
        artworks: list[ArtworkData] = []
        # construct list of Art_info objects
        for s in self.normalized_scores:
            artwork = mapper.getArtwork4NodeID(s[0])
            score = s[1]
            room_nb = artwork.room
            occ = self.occupancy[room_nb - 401]
            duration = params.timeInFrontOfArtwork
            for r in artworks:
                if r.room == room_nb:
                    duration += params.timeInFrontOfArtwork         #increment duration if there is already something interesting in this room
            risk = virus_model.risk_in_percent(occ, duration)
            art_data = ArtworkData(artwork.moma_id, artwork.room, occ, score, duration, risk)  #create data object
            artworks.append(art_data)
        return artworks

    # get the result list considering the highest scores
    def ignore_risk(self):
        score_sorted_list = sorted(self.list_of_artwork_data, key=lambda Art_info: Art_info.score)
        score_sorted_list.reverse()
        return score_sorted_list[:params.resultSetLength]

    # get the result list considering the minimal risks
    def optimze_risk(self):
        score_sorted_list = sorted(self.list_of_artwork_data, key=lambda Art_info: Art_info.risk)
        return score_sorted_list[:params.resultSetLength]

    # construct the result list considering the highest scores as long as the risk threshold is not exceeded
    def accept_risk(self, risk_threshold):
        result_set = []
        i = 0
        while len(result_set) < params.resultSetLength:
            art_data = self.list_of_artwork_data[i]
            room = art_data.room
            if art_data.risk < risk_threshold:
                result_set.append(art_data)
            i += 1
            if i == len(self.list_of_artwork_data):
                print('only ', len(result_set), 'recommendations possible to hold the risk threshold')
                break
        return result_set

    def getTotal_scores_and_risks(self, artwork_data_list):
        score_sum = sum(ai.score for ai in artwork_data_list)
        risk_sum = sum(ai.risk for ai in artwork_data_list)
        #print('score_sum:', round(score_sum, 2), '   risk_sum:', round(risk_sum, 2))
        return score_sum, risk_sum

    def infos(self):
        min_score = min(self.list_of_artwork_data, key=lambda art_info: art_info.score).score
        max_score = max(self.list_of_artwork_data, key=lambda art_info: art_info.score).score
        min_risk = min(self.list_of_artwork_data, key=lambda art_info: art_info.risk).risk
        max_risk = max(self.list_of_artwork_data, key=lambda art_info: art_info.risk).risk
        print('number of artworks infos:', len(self.list_of_artwork_data))
        total_score = sum(obj.score for obj in self.list_of_artwork_data)
        average_score = total_score/len(self.list_of_artwork_data)
        total_risk = sum(obj.risk for obj in self.list_of_artwork_data)
        average_risk = total_risk/len(self.list_of_artwork_data)
        print('min score:', round(min_score, 2), '      max score:', round(max_score, 2), '   average score:', round(average_score, 3) )
        print('min risk:', round(min_risk, 3), '      max risk:', round(max_risk, 2), '   average risk:', round(average_risk, 3) )
        #print('min score_risk:', round(min_score_risk, 4), '      max score_risk:', round(max_score_risk, 4) )
        print('risk threshold:', params.risk_threshold_in_percent)
        print('fraction of people with mask:', params.fractionNumberOfPeopleWithMasks)
        print('fraction of immune people:', params.percentagerOfPopulationImmune, '    fraction of infective people:', params.probabilityOfBeingInfective)
        print('lenght of recommendatino list K:', params.resultSetLength)
        print('----------------------------')
        print()

    @staticmethod
    def experiment(nb_scenarios, nb_users, risk_threshold):
        # variables to calculate averages
        sum_score_ignore = 0
        sum_risk_ignore = 0
        sum_score_optimize = 0
        sum_risk_optimize = 0
        sum_score_accept = 0
        sum_risk_accept = 0

        # iterate over various occupancies
        for scenario in range(nb_scenarios):
            occupancy = Occupancy.get_random_occupancies()
            print('scenario:', scenario, '   --- occupancy:', occupancy)

            # iterate over various users
            for i in range(nb_users):
                # get all artworks with <scores, risk> attributes
                recommendation_candidates = RecommendationListBuilder.factory_method(occupancy)

                # print('############################## ignoring risk')
                result_set = recommendation_candidates.ignore_risk()
                # filter.print_list(result)
                scores_risks = recommendation_candidates.getTotal_scores_and_risks(result_set)
                sum_score_ignore += scores_risks[0]
                sum_risk_ignore += scores_risks[1]

                # print('############################## optimized risk')
                result_set = recommendation_candidates.optimze_risk()
                # filter.print_list(result)
                scores_risks = recommendation_candidates.getTotal_scores_and_risks(result_set)
                sum_score_optimize += scores_risks[0]
                sum_risk_optimize += scores_risks[1]

                # print('############################## accepting risk')
                result_set = recommendation_candidates.accept_risk(risk_threshold)
                scores_risks = recommendation_candidates.getTotal_scores_and_risks(result_set)
                sum_score_accept += scores_risks[0]
                sum_risk_accept += scores_risks[1]
                # print('=============================================== \n\n')

        #calculate average over runs:
        nb_of_experiments = nb_users * nb_scenarios

        #considers average score per recommendation in the result list
        avg_score_ignore = sum_score_ignore / (nb_of_experiments * params.resultSetLength)
        avg_risk_ignore = sum_risk_ignore / nb_of_experiments
        avg_score_optimize = sum_score_optimize / (nb_of_experiments * params.resultSetLength)
        avg_risk_optimize = sum_risk_optimize / nb_of_experiments
        avg_score_accept = sum_score_accept / (nb_of_experiments * params.resultSetLength)
        avg_risk_accept = sum_risk_accept / nb_of_experiments

        RecommendationListBuilder.print_results(avg_score_ignore, avg_risk_ignore, avg_score_optimize, avg_risk_optimize, avg_score_accept, avg_risk_accept)

    def print_results(avg_score_ignore, avg_risk_ignore, avg_score_optimize, avg_risk_optimize, avg_score_accept, avg_risk_accept):
        #calculate differences
        optimal_score = avg_score_ignore
        optimal_risk = avg_risk_optimize

        print()
        print('########################### ignoring risk ####################')
        risk_delta = 100 * (1 / optimal_risk) * (avg_risk_ignore - optimal_risk)
        print('avg score:', round(avg_score_ignore, 2), '    avg risk:', round(avg_risk_ignore , 2))
        print('score delta:', 0.0, '%    risk delta:', round(risk_delta, 2), '%')
        print()

        print('########################### optimze risk #####################')
        score_delta = 100 * (1 / optimal_score) * (avg_score_optimize - optimal_score)
        print('avg score:', round(avg_score_optimize, 2), '    avg risk:', round(avg_risk_optimize, 2))
        print('score delta:', round(score_delta, 2), '%    risk delta:', 0.0, '%')
        print()

        print('########################### accept risk ######################')
        score_delta = 100 * (1 / optimal_score) * (avg_score_accept - optimal_score)
        risk_delta = 100 * (1 / optimal_risk) * (avg_risk_accept - optimal_risk)
        print('avg score:', round(avg_score_accept, 2), '    avg risk:', round(avg_risk_accept, 2))
        print('score delta:', round(score_delta, 2), '%    risk delta:', round(risk_delta, 2), '%')
        print()


class Normalizer:
    @staticmethod
    def normalize_scores(score_list):
        score_values = [sc for _, sc in score_list]  # list of all score values for a certain user
        min_score = min(score_values)
        max_score = max(score_values)
        normalized_score_list = [(id, (score - min_score) / (max_score - min_score)) for id, score in score_list]
        #print('number of scores:', len(normalized_score_list))
        return normalized_score_list

class Occupancy:
    @staticmethod
    def get_random_occupancies():
        min_occupancy = 20
        max_occupancy = 70
        number_of_rooms = 21
        ocupancies = []
        for i in range(number_of_rooms):
            occ = random.randint(min_occupancy, max_occupancy)
            ocupancies.append(occ)
        return ocupancies



if __name__ == "__main__":
    nb_of_scenarios = 2
    nb_users = 10
    risk_acceptance_threshold = 0.1

    RecommendationListBuilder.experiment(nb_of_scenarios, nb_users, risk_acceptance_threshold)
