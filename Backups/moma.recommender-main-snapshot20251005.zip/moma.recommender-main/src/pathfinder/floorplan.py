import networkx as nx
from networkx.algorithms.approximation import traveling_salesman_problem

class Floorplan:

    def __init__(self):
        self.floorplan = nx.Graph()
        self.constructMoMAgraph()
        self.entry = 401
        self.exit = 421

    def constructMoMAgraph(self):
        # Add room nodes to the graph
        self.floorplan.add_nodes_from([401, 402, 403, 404, 405, 406, 407, 408, 409, 410,
                                       411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421])

        # Add edges to the graph
        self.floorplan.add_edges_from([(401, 402), (402, 403), (403, 404), (404, 405),
                                       (405, 407), (407, 408), (408, 409), (408, 410), (408, 409), (410, 412), (412, 411), (412, 413), (412, 414),
                                       (405, 406), (406, 415), (415, 416), (415, 417), (415, 418), (418, 419), (419, 420), (420, 421)
                                       ])


    def findRoute(self, start_node, desired_nodes):
        visiting_route = self.findVisitingRoute(start_node, desired_nodes)
        exit_route = self.findRouteToExit(visiting_route[-1])
        return visiting_route + exit_route


    def findVisitingRoute(self, start_node, desired_nodes):
        if start_node in desired_nodes:
            desired_nodes.remove(start_node)
        desired_nodes = [start_node] + desired_nodes
        visiting_route = None
        if len(desired_nodes) > 1:
            circle_tour = traveling_salesman_problem(self.floorplan, nodes=desired_nodes)
            #print("circle tour:", circle_tour)
            visiting_route = self.goNotBack(circle_tour, desired_nodes)
        else:
            visiting_route = desired_nodes
        #print('Visting route:', visiting_route)
        return visiting_route

    def findRouteToExit(self, last_visited_node):
        route_to_exit = []
        if  last_visited_node != self.exit:
            nodes_to_exit = [last_visited_node, self.exit]   # exit route must pass these two nodes
            route_to_exit = traveling_salesman_problem(self.floorplan, nodes=nodes_to_exit)
            route_to_exit = self.goNotBack(route_to_exit, nodes_to_exit)  # get rid of circle route
            #print('route to exit:', route_to_exit)
        if len(route_to_exit) > 0:
            route_to_exit = route_to_exit[1:]
        return route_to_exit


    # cuts the circle_route when all desired nodes are visited - helper method
    def goNotBack(self, circle_tour, desired_nodes):
        route = []
        for n in circle_tour:
            route.append(n)
            if n in desired_nodes:
                desired_nodes.remove(n)
                if len(desired_nodes) == 0: break
        return route


if __name__ == '__main__':
    fp = Floorplan()
    desired_nodes = [404, 402, 411] #
    print('desired nodes:', desired_nodes)
    #desired_nodes =  [412, 406, 401, 417]
    #desired_nodes = []
    #desired_nodes = [421, 401, 406]
    #print(fp.findRoute(fp.entry, desired_nodes))
    print(fp.findRoute(402, desired_nodes))