import networkx as nx
from karateclub import DeepWalk
import time
import pickle

class GraphEmbedder:
    # reads graphml file
    # creates embedding (using DeepWalk with default values
    # stores embeddings as pickle object

    def __init__(self):
        self.graph_original = nx.read_graphml('../../graph/momaGraph.graphml')
        self.graph = nx.convert_node_labels_to_integers(self.graph_original)   # required for calculating embeddings
        self.node_embeddings = None

        print('Graph Data:')
        print('--- total number of graph nodes:', self.graph.number_of_nodes())
        print('--- total number of graph edges:', self.graph.number_of_edges())
        print()

    def calculateEmbeddings(self):
        print('*** start embedding')
        model = DeepWalk()
        model.fit(self.graph)
        self.node_embeddings = model.get_embedding()    # returns dictionary with node IDs as keys'
        print('*** embedding calculated')
        self.saveEmbeddings()

    def saveEmbeddings(self):
        embeddingFile = open('../../embeddings/embeddings.pkl', 'bw')
        pickle.dump(self.node_embeddings, embeddingFile)
        embeddingFile.close()


    def printOutAllNodes(self):
        keys = self.graph.nodes.keys()
        for k in keys:
            print('---', k, self.graph.nodes[k])
        print()

    #############################
    #############################
    def main(self):
        #self.printOutAllNodes()

        start_time = time.time()
        self.calculateEmbeddings()                # calculate embeddings
        end_time = time.time()
        execution_time = end_time - start_time
        print()
        print('===============')
        print(f"Execution time: {execution_time} seconds\n\n")


if __name__ == '__main__':
    ge = GraphEmbedder()
    ge.main()

