import pandas as pd
import networkx as nx
import utils

import os
import src.parameters.params as params

class GraphBuilder:
    # takes ../../db/csv4KnowledgeGraph/Artworks4thFloor.csv data (i.e. filtered MoMA data)
    # and "../../db/csv4KnowledgeGraph/Artists.csv"
    # builds networkx graph and stores it as graphml file
    # creates the following nodes
    #  - artworks, artists, departments, classifications, periods, floors, rooms
    #  - creates the corresponding relations

    def __init__(self):
        self.graph = nx.Graph()

        script_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.abspath(os.path.join(script_dir, "../../"))
        if params.artwork_location_random == True:
            file_path = os.path.join(project_root, 'data/ArtworksWithRandomRooms.csv')
        else:
            file_path = os.path.join(project_root, 'data/Artworks4thFloor.csv')
            
            
        df = pd.read_csv(file_path, sep=',', dtype=str)
        selected_features = ['ObjectID', 'Title', 'ConstituentID', 'Artist', 'Date', 'Classification', 'Department', 'style', 'genre', 'floor', 'room']  # ConstituentID is artistID
        self.artworks = df[selected_features]
        #self.artworks.dropna(subset=['genre'], inplace=True)
        #self.artworks.to_csv("../../db/csv4KnowledgeGraph/Artworks4thFloor.csv")

        self.__listOfArtworksNodes = []
        self.__listOfArtistsNodes = []

        # relations of artworks
        self.__relations_artworks_artists = []
        self.__relations_artworks_departments = []
        self.__relations_artworks_classifications = []
        self.__relations_artworks_periods = []
        self.__relations_artworks_styles = []
        self.__relations_artworks_genres = []
        self.__relations_artworks_rooms = []

        # relations of artists
        self.__relations_artist_artist = []

        self.__PRINT_OUT = False                   # True => prints all generated nodes

    def constructGraph(self):
        self.__process_artwork_file()
        self.__process_artist_file()
        self.__process_artist_relation()
        self.__makeGraph()
        self.__safeGraph()

    #!!!!!!!!!!!!!! process artworks  !!!!!!!!!!!!!!!!!!!!!!!
    # used to sample artworks for reducing the number of artworks (i.e. the graph size)
    def __process_artwork_file(self):
        # enumerations
        self.createDepartmentNodes()
        self.createClassificationNodes()
        self.createPeriodNodes()
        self.createStyleNodes()
        self.createGenreNodes()
        self.createRoomNodes()

        # create artwork nodes
        for i in range(len(self.artworks)):
            row = self.artworks.iloc[i]
            if not row.isnull().any() and row['genre'] != 'Nothing':
                self.createArtworkNode(row)
                self.createArtworkRelations(row)

    def createDepartmentNodes(self):
        department_nodes = []
        departments = self.artworks['Department'].unique().tolist()
        for d in departments:
            d_node = (d, {'type': 'department', "name": d})
            if self.__PRINT_OUT:
                print(d_node)
            department_nodes.append(d_node)
        self.__addNodes2Graph('departments', department_nodes)

    def createClassificationNodes(self):
        classification_nodes = []
        classifications = self.artworks['Classification'].unique().tolist()
        for c in classifications:
            c_node = (c, {'type': 'classification', "name": c})
            if self.__PRINT_OUT:
                print(c_node)
            classification_nodes.append(c_node)
        self.__addNodes2Graph('classifcations', classification_nodes)

    def createStyleNodes(self):
        style_nodes = []
        styles = self.artworks['style'].unique().tolist()
        for s in styles:
            s_node = (s, {'type': 'style', "name": s})
            if self.__PRINT_OUT:
                print(s_node)
            style_nodes.append(s_node)
        self.__addNodes2Graph('styles', style_nodes)

    def createGenreNodes(self):
        genre_nodes = []
        genres = self.artworks['genre'].unique().tolist()
        for g in genres:
            g_node = (g, {'type': 'genre', "name": g})
            if self.__PRINT_OUT:
                print(g_node)
            genre_nodes.append(g_node)
        self.__addNodes2Graph('genres', genre_nodes)

    def createPeriodNodes(self):
        periods = ['1900', 'twenties', 'thirties', 'fourties', 'fifties','sixties', 'seventies', 'eighties', 'ninties', 'current']
        period_nodes = []
        for p in periods:
            p_node = (p, {'type': 'period', "name": p})
            if self.__PRINT_OUT:
                print(p_node)
            period_nodes.append(p_node)
        self.__addNodes2Graph('periods', period_nodes)

    def createRoomNodes(self):
        rooms = ['401', '402', '403', '404', '405','406', '407', '408', '409', '410', '411','412','413','414','415','416','417','418','419','420','421']
        room_nodes = []
        for r in rooms:
            r_node = (r, {'type': 'room', "nr": r})
            if self.__PRINT_OUT:
                print(r_node)
            room_nodes.append(r_node)
        self.__addNodes2Graph('rooms', room_nodes)

    def createArtworkNode(self, row):
        artwork_node = (row['ObjectID'], {'type': 'artwork',
                                           'ObjectID': row['ObjectID'],
                                          "title": row['Title'] ,
                                          "date": row['Date'],
                                          "artistID": row['ConstituentID'],
                                          "artist": row['Artist'],
                                          "classification": row['Classification'],
                                          "department": row['Department'],
                                          "style": row['style'],
                                          "genre": row['genre'],
                                          "room": row['room']
                                          })
        if self.__PRINT_OUT:
            print(artwork_node)
        self.__listOfArtworksNodes.append(artwork_node)

    def createArtworkRelations(self, row):
        artID= row['ObjectID']

        #relation to artist
        artistID = row['ConstituentID']
        edge = (artID, artistID, {'type': 'relation', "relationtype": 'fromArtist'})
        self.__relations_artworks_artists.append(edge)

        #relation to department
        departmentID = row['Department']
        edge = (artID, departmentID, {'type': 'relation', "relationtype": 'isInDepartment'})
        self.__relations_artworks_departments.append(edge)

        #relation to classification
        classificationID = row['Classification']
        edge = (artID, classificationID, {'type': 'relation', "relationtype": 'isClassifiedAs'})
        self.__relations_artworks_classifications.append(edge)

        #relation to period
        periodID = utils.map_year_to_period(row['Date'])    # map year to one out of 10 periods
        edge = (artID, periodID, {'type': 'relation', "relationtype": 'fromPeriod'})
        self.__relations_artworks_periods.append(edge)

        #relation to style
        styleID = row['style']
        edge = (artID, styleID, {'type': 'relation', "relationtype": 'hasStyle'})
        self.__relations_artworks_styles.append(edge)

        #relation to genre
        genreID = row['genre']
        edge = (artID, genreID, {'type': 'relation', "relationtype": 'hasGenre'})
        self.__relations_artworks_genres.append(edge)

        #relation to room
        roomID = row['room']
        edge = (artID, roomID, {'type': 'relation', "relationtype": 'locatedInRoom'})
        self.__relations_artworks_rooms.append(edge)

    #!!!!!!!  process artists !!!!!!!!!!!!!!!!!!!!!
    def __process_artist_file(self):
        df = pd.read_csv("../../data/Artists.csv", dtype=str)
        selectedFeatures = ['ConstituentID', 'DisplayName', 'Nationality', 'Gender', 'BeginDate', 'EndDate']
        artists = df[selectedFeatures]

        # fill graph object
        for i in range(len(artists)):
            row = artists.iloc[i]
            if not row.isnull().any():                              # skip if the row contains null values
                self.createArtistNode(row)
        self.__addNodes2Graph('artists', self.__listOfArtistsNodes)

    def createArtistNode(self, row):
        artist_node = (row['ConstituentID'],
                       {'type': 'artist',
                        "name": row['DisplayName'],
                        "nationality": row['Nationality'],
                        "gender": row['Gender'],
                        "born": row['BeginDate'],
                        "died": row['EndDate']}
                       )
        if self.__PRINT_OUT:
            print(artist_node)
        self.__listOfArtistsNodes.append(artist_node)

    #!!!!!!!  process artist relations !!!!!!!!!!!!!!!!!!!!!
    def __process_artist_relation(self):
        df = pd.read_csv("../../data/artistRelations.csv", dtype=str)
        selectedFeatures = ['fromArtistId', 'toArtistId']
        artists_relations = df[selectedFeatures]

        for i in range(len(artists_relations)):
            row = artists_relations.iloc[i]
            fromArtist = row['fromArtistId']
            toArtist = row['toArtistId']
            edge = (fromArtist, toArtist, {'type': 'relation', 'relationtype': 'relatedArtist'})
            #print('#####', edge)
            self.__relations_artist_artist.append(edge)

    ##############################################################
    def __addNodes2Graph(self, type, nodeList):
        print('# Store:{} as graph node'.format(type))
        print('**** number of {}'.format(type), len(nodeList))
        self.graph.add_nodes_from(nodeList)
        print()

    def __addEdges2Graph(self, fromNodeType, toNodeType, edgeList):
        print('Store edges from {} to {}'.format(fromNodeType, toNodeType))
        print('number of edges:', len(edgeList))
        self.graph.add_edges_from(edgeList)
        print()

    def __makeGraph(self):
        print("Saving graph as graphML file ...")
        self.__addNodes2Graph('artworks', self.__listOfArtworksNodes)
        self.__addEdges2Graph('artworks', 'artists', self.__relations_artworks_artists)
        self.__addEdges2Graph('artworks', 'departments', self.__relations_artworks_departments)
        self.__addEdges2Graph('artworks', 'classification', self.__relations_artworks_classifications)
        self.__addEdges2Graph('artworks', 'period', self.__relations_artworks_periods)
        self.__addEdges2Graph('artworks', 'styles', self.__relations_artworks_styles )
        self.__addEdges2Graph('artworks', 'genres', self.__relations_artworks_genres)
        self.__addEdges2Graph('artworks', 'rooms', self.__relations_artworks_rooms)
        self.__addEdges2Graph('artists', 'artists', self.__relations_artist_artist)

    def __safeGraph(self):
        nx.write_graphml(self.graph, '../../graph/momaGraph.graphml')
        print('--- total number of graph nodes:', self.graph.number_of_nodes())
        print('--- total number of graph edges:', self.graph.number_of_edges())
        print("Finished saving graph as graphML file ...")

if __name__ == '__main__':
    dl = GraphBuilder()
    dl.constructGraph()