def map_year_to_period(year):
    try:
        year = int(year)
    except:
        print('error: string could not mapped to int')
        return "unknown"
    if year < 1920:
        return '1900'
    elif year < 1930:
        return 'twenites'
    elif year < 1940:
        return 'thirties'
    elif year < 1950:
        return 'fourties'
    elif year < 1960:
        return 'fifties'
    elif year < 1970:
        return 'sixties'
    elif year < 1980:
        return 'seventies'
    elif year < 1990:
        return 'eighties'
    elif year < 2000:
        return 'ninties'
    else:
        return 'new'


def makeXMLcompatible(my_string):
    try:
        my_string = my_string.encode('utf-8').decode('unicode_escape')
        my_string = my_string.replace('\x1f', '')
        my_string = my_string.replace('\s', '')
        my_string = my_string.replace('\P', '')
        my_string = my_string.replace('\(', '')
        my_string = my_string.replace('\ ', '')
        my_string = my_string.replace('\\', ' ')
        return my_string.rstring()
    except:
        return str(my_string)