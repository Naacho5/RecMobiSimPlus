# Import necessary libraries
import agentpy as ap
import random
import networkx as nx
import matplotlib.pyplot as plt

import src.pathfinder.floorplan as floorplan

import visitor as visitor

import os
import time
from datetime import datetime


# Define a class for the MuseumSimulation
class MuseumSimulation(ap.Model):
    
    VISUAL_DEBUG = False
    
    def setup(self):
        """
        Set up the simulation with a museum, visitors, and parameters.
        """
        
        # Create visitors
        self.visitors = ap.AgentList(self, self.p.n_visitors, visitor.Visitor)
        self.visitors.set_state(visitor.Visitor.START)
        
        self.floorplan = floorplan.Floorplan()
        
        
        # Data collection for monitored visitors (initially empty list)
        self.monitored_visitors_data = []

        # print(f"{len(self.visitors)} visitors created.")
        
        # Cambiar esta línea para crear un grafo en formato de cuadrícula (por ejemplo, 3x3)
        # self.museum_graph = nx.grid_2d_graph(3, 3)  # Crea una cuadrícula de 3x3
        self.museum_graph = self.floorplan.floorplan
        
        # Añadir esta línea para definir posiciones fijas
        # Mantener un layout de tipo "spring" fijo
        self.pos = nx.spring_layout(self.museum_graph, seed=42)  # Definir layout una vez con una semilla para mantenerlo fijo



    def step(self):
        """
        Simulate one step of the model where each visitor moves through one room.
        """
        # print('\n\n')
        # print('###################################################################')
        # print(f"\nStep {self.t + 1} - Visitors moving through rooms")
        
        occupancies = self.calculate_occupancies(self.floorplan)
        
        # print(occupancies)
        
        self.visitors.update_state()
        self.visitors.move(self.calculate_occupancies(self.floorplan))
        
        if self.VISUAL_DEBUG:
            self.draw()
        # for visitor in self.visitors:
        #     visitor.move()
            
        
    
    def end(self):
        """
        Finalize the simulation and record the results.
        """
        total_time_spent = sum(visitor.time_spent for visitor in self.visitors)
        avg_time_per_visitor = total_time_spent / len(self.visitors)
        self.record('average_time_per_visitor', avg_time_per_visitor)
        self.record('monitored_visitors', self.monitored_visitors_data)
        print("\nSimulation ended.")
        # print(f"Average time per visitor: {avg_time_per_visitor}")
        # print("Monitored visitors data recorded:", self.monitored_visitors_data)

        

    def calculate_occupancies(self, plan):
        rooms = list(plan.floorplan.nodes())
        
        # Let's create an empty dict for occupancies nad initialize with 0
        occupancies = [0]*len(rooms)
        #for r in rooms:
        #    print('Room -> ' + str(r))
        #    occupancies[r - 401] = 0
        
        
        # Let's calculate occupacy by iterating all agents
        # print(occupancies)
        
        for v in self.visitors:
            # print('Current room -> ' + v.current_room)
            occupancies[int(v.current_room) - 401] += 1
        
        # print(occupancies)
        
        return occupancies

    def draw(self):
        # Dibujar el grafo del museo
        # pos = nx.spring_layout(self.floorplan.floorplan)  # Posiciones para los nodos
        plt.figure(figsize=(8, 6))
        
        # Dibujar nodos (salas) usando las posiciones fijas
        nx.draw_networkx_nodes(self.museum_graph, self.pos, node_size=500, node_color='lightblue', label='Salas')
        
        # Dibujar aristas (conexiones entre salas) usando las posiciones fijas
        nx.draw_networkx_edges(self.museum_graph, self.pos, width=1.5, alpha=0.7, edge_color='gray')
        
        # # Dibujar nodos (salas)
        # nx.draw_networkx_nodes(self.floorplan.floorplan, pos, node_size=500, node_color='lightblue', label='Rooms')
        
        # # Dibujar aristas (conexiones entre salas)
        # nx.draw_networkx_edges(self.floorplan.floorplan, pos, width=1.5, alpha=0.7, edge_color='gray')
        
        # Dibujar los agentes en las salas
        visitor_pos = {node: 0 for node in self.floorplan.floorplan.nodes}
        for visitor in self.visitors:
            visitor_pos[visitor.current_room] += 1
        
        # for node, count in visitor_pos.items():
        #     if count > 0:
        #         plt.text(self.pos[node][0], self.pos[node][1] + 0.05, str(count), fontsize=12, ha='center', color='red')
        
        # Si queremos todos los ids de los visitors en cada sala:
        #  ***********************************************************************
        # Recopilar los identificadores de los agentes que están en cada sala
        visitor_pos = {node: [] for node in self.museum_graph.nodes}
        for visitor in self.visitors:
            if visitor.id == 1: # Para visualizar sólo el visitor 1 (Monitorizado)
                visitor_pos[visitor.current_room].append(visitor.id)
        
        # Dibujar los identificadores de los agentes en cada nodo
        for node, visitor_ids in visitor_pos.items():
            if visitor_ids:
                plt.text(self.pos[node][0], self.pos[node][1] + 0.05, f'{", ".join(map(str, visitor_ids))}', fontsize=10, ha='center', color='red')
        
        #  ***********************************************************************
        
        # Si queremos la ocupación de cada sala:
        #  ***********************************************************************
        # Dibujar los agentes en las salas
        
        # for node, count in visitor_pos.items():
        #     if count > 0:
        #         plt.text(self.pos[node][0], self.pos[node][1] + 0.05, str(count), fontsize=12, ha='center', color='red')

        #  ***********************************************************************
        
        # Dibujar etiquetas de nodos
        nx.draw_networkx_labels(self.museum_graph, self.pos, font_size=10, font_color='black')

        plt.title('Visitor distribution at MoMA')
        plt.axis('off')
        plt.show()
 
# Define parameters for the simulation
parameters = {
    'n_visitors': ap.Values(10,50,100,200,500),#ap.Values(10,50,100,200,500,1000), #,5000,10000),    # Number of visitors
    # 'n_visitors': ap.Values(5000),
    'monitor_visitors': True,  # Whether to monitor visitors
    # 'monitor_ratio': 0.5,      # Percentage of visitors to monitor
    # 'seed': 1,
    'random': False, #ap.Values(False, True),             # Artworks and rooms are chosen randomly
    'steps': 1000,              # Number of steps (minutes) in the simulation
    'time_per_step': 1,         # Time passed during one step of the simulation (in minutes)
    'risk_aware': ap.Values(True, False),         # True if risk-aware flag activated; False a.o.c Only False/True if random is activated
    'risk_threshold': 0.1 #ap.Values(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.5, 2.0, 5.0)
}


t_initial = time.time()
# Run the simulation manually
sample = ap.Sample(parameters)
exp = ap.Experiment(MuseumSimulation, sample, iterations=5, record = True)
# model = MuseumSimulation(parameters)
results = exp.run()
# results = model.run()

################################################
# model.setup()
# for _ in range(parameters['steps']):
#     model.step()
#     model.draw()
################################################
    
# Let's save variables to a results file
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(script_dir, "../../"))

today = datetime.today()
date = today.strftime('%Y_%m_%d-%I-%M-%S_%p')
file_path = os.path.join(project_root, 'results/results_' + date + '.csv')
results.variables.Visitor.to_csv(file_path)

t_end = time.time()

print(results.variables.Visitor)
print('Elapsed time --> ' + str(t_end - t_initial))

# for i in range(100):
#     model.step()
#     model.draw()

# Retrieve and display results
# average_time_per_visitor = results.variables.get('average_time_per_visitor', None)
# monitored_visitors_data = results.variables.get('monitored_visitors', [])

# Check if the variables were recorded properly and display them
# if average_time_per_visitor is not None:
#     print("\nFinal Results:")
#     print("Average time per visitor:", average_time_per_visitor)
# else:
#     print("\nAverage time per visitor was not recorded.")

# print("Monitored visitors data:", monitored_visitors_data)