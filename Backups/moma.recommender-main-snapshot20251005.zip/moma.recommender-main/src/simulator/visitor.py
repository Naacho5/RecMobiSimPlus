#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 30 14:47:01 2024

@author: rhermoso
"""

import agentpy as ap
import pandas as pd
import random

import src.parameters.params as params
import src.mapping.mapper as mapper
import src.covid_model.virus_model as risk_model

from src.entitites.user import User
from src.recommender.recommender import Recommender
from src.pathfinder.floorplan import Floorplan


import os

# Define a class for Visitors
class Visitor(ap.Agent):
    
    user_registry = {}        
    
    # Possible states for Visitors
    START = 0
    ON_WAY = 1
    STARING_AT_ARTWORK = 2
    WAITING_NEW_ARTWORK = 3
    STOP = 4
    

    
    
    def setup(self):
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.abspath(os.path.join(script_dir, "../../"))
        
        if params.artwork_location_random == True:
            file_path = os.path.join(project_root, 'data/ArtworksWithRandomRooms.csv')
        else:
            file_path = os.path.join(project_root, 'data/Artworks4thFloor.csv')
        # file_path = os.path.join(project_root, "data/Artworks4thFloor.csv")
        
        # Pasted from interface.py
        self.model_user = User(self.id, simulation=True, evaluation=False)
        # self.favorites = self.drawMyFavorites(params.nbOfFavorites)  # list of moma_ids
        # self.r = Recommender(model_user.id, model_user.getFavoritesIDs())

        # Visitor.counter += 1
        # self.id = Visitor.counter
        # self.model_user.id = self.id
        self.model_user.mapper = mapper.Mapper()
        self.state = self.START
        self.time_remaining_for_current_artwork= 0
        self.goal_room = 0
        self.goal_artwork = None
        self.floorplan = Floorplan()
        self.already_visited_artworks = []
        self.current_path = []
        self.artworks = pd.read_csv(file_path, sep=',', dtype=str)
        self.visited_artworks = []
        
        self.durations = [0]*len(list(self.floorplan.floorplan.nodes()))
        
        # if self.p.risk_aware:
        self.risk_model = risk_model.VirusModel()
        
        
        # all_styles = self.artworks['style'].unique().tolist()    # all styles in dataset
        # attributes for personal preferences
        #self.my_styles = self.drawMyStyles()
        
        # User.user_registry[self.id] = self      #register user object

        
        """
        Initialize a visitor with a profile (slow, medium, fast) and monitoring status.
        This method is called when the agent is created.
        """
        self.profile = random.choice(['slow', 'medium', 'fast'])
        if self.model_user.id == 1:
            self.is_monitored = True
        else:
            self.is_monitored = False
        # self.is_monitored = self.p.monitor_visitors and random.random() < self.p.monitor_ratio
        self.current_room = self.model_user.artworks.sample()['room'].iloc[0] # Random room at start
        self.time_spent = 0
        self.time_spent_for_current_artwork = 0
        # print(f"Visitor {self.id} initialized with profile: {self.profile}, monitored: {self.is_monitored} in room: {self.current_room}")

    def time_in_room(self):
        """
        Determine the time the visitor spends in the current room based on their profile, only to see
        an artwork
        """
        if self.profile == 'slow':
            return random.randint(8, 12)
            # return random.randint(1, 5)
        elif self.profile == 'medium':
            return random.randint(5, 7)
            # return random.randint(1, 5)
        else:
            return random.randint(2, 4)
            # return random.randint(1, 5)
    
    def set_state(self, new_state):
        self.state = new_state
    
    def update_state(self):
        self.time_spent += 1
        if (self.state == self.START) or (self.state == self.STOP):
            # self.state = self.WAITING_NEW_ARTWORK
            pass
        else:
            if self.state == self.ON_WAY:
                # print(str(self.current_room) + ' - ' + str(self.goal_room))
                if self.current_room == int(self.goal_room):
                    # print(' ******************** CHANGES !!! ********************')
                    self.state = self.STARING_AT_ARTWORK
                    self.already_visited_artworks.append(self.goal_artwork)
                    self.time_remaining_for_current_artwork = self.time_in_room()
                    
                    self.visited_artworks.append(self.goal_artwork) # XXX
                    # if self.is_monitored:
                    #     print('Visited -> ')
                    #     print(self.visited_artworks)
                
            else:                
                if self.state == self.STARING_AT_ARTWORK:
                    # if self.time_spent_for_current_artwork == 0:
                        
                        # self.state = self.WAITING_NEW_ARTWORK
                    self.time_spent_for_current_artwork += 1
                    self.time_remaining_for_current_artwork -= 1
                    # if self.is_monitored:
                    #     print(f'--- Time remaining in room {self.current_room} {self.time_remaining_for_current_artwork}')
                    if self.time_remaining_for_current_artwork == 0:
                        self.state = self.WAITING_NEW_ARTWORK
                        # print('WATING NEW ARTWORK')
         
        # print('+++ Visitor ' + str(self.id) + ' is has state ' + str(self.state))
       
        
    def update_durations(self):
        estimated_time_in_any_room = self.time_in_room()
        [x + estimated_time_in_any_room for x in self.durations] # Sums the estimated time for any room. Current room must contain time in t-1 + estimated, rest only estimated
        for i in range(0,len(self.durations)):
            self.durations[i] += estimated_time_in_any_room
        # print('+++++ Updates durations')
        # print(self.durations)
        
    # Returns the goal room, the next room in the path and the goal artwork to visit
    def next_room(self, occupancies = [], durations = []):
        
        if (self.is_monitored) and (not self.p.random):
            # self.model_user.recommender.getRecommendedArtworks()  # calculate recommendations and the scores !
            
            # New version according to last changes by Jürgen
            self.update_durations()
            
            if not self.p.random:
                if self.p.risk_aware:
                    result = self.model_user.recommender.getTourWithRisk(occupancies, self.durations, risk_threshold = self.p.risk_threshold)
                else:
                    result = self.model_user.recommender.getTour()
            # else:
            #     result = self.model_user.artworks.sample(n = params.resultSetLength)
            # print(result)
            
            goal_room = None
            # print(result)
            recommended_artwork = result[0]
            i = 0
            new_result = []
            for r in result:
                # print('Next room -> ')
                # print(type(r.moma_id)) # Type str
                # print(r.moma_id)
                if not (r.moma_id in self.visited_artworks):
                    # print('********** ENTRA')
                    new_result = result[i:]
                    recommended_artwork = r
                    break
                i += 1

            # print('Artworks recommended -> ' + str(len(new_result)))
            # for r in new_result:
            #     print(r)
            

            # print('Visited --> ')
            # for a in self.already_visited_artworks:
            #     print(a)
            
            if not new_result:
               # Visitor has already visited all interesting artworks (STOPS here)
               # print('User has already visited all interesting artworks (STOPS here)')
               self.model.stop()
            
            
            self.current_path = self.model_user.recommender.getRecommendationPath(new_result, startRoom = int(self.current_room))
            # print('! Path:', self.current_path)
            
            # XXX Saves the PREDICTED risk in a room for a user
            # self.predicted_risk = self.model_user.recommender.getRiskInRoom(result[0].room, occupancies, [result[0]]) 
            
            # print('Recommended room --> ' + str(recommended_artwork.room))
            
            # Let's calculate the distance from the current room to the goal room
            distance = 0
            for r in self.current_path:
                # print('##### r -> ' + str(r) + ', recommended_artwork_room -> ' + str(recommended_artwork.room))
                if not (r == recommended_artwork.room):
                    distance += 1
                else:
                    break
            
            self.predicted_risk = self.risk_model.risk_in_percent(occupancies[recommended_artwork.room - 401], self.durations[recommended_artwork.room - 401])
            # self.predicted_risk = self.model_user.recommender.getRiskInRoom(recommended_artwork.room, occupancies, [new_result[0]]) 
            # print('Predicted risk -> ' + str(self.predicted_risk))
            # Let's empty estimated durations for other rooms
            for i in range(len(self.durations)):
                if i != recommended_artwork.room - 401:
                    self.durations[i] = 0
            
            
            self.predicted_room = recommended_artwork.room
            self.current_occupancy = occupancies
            self.distance_to_cover = distance
            self.n_visitors = self.p.n_visitors
            self.risk_aware = self.p.risk_aware
            self.risk_threshold = self.p.risk_threshold
            self.score = recommended_artwork.score
            
            user_data = self.model_user.get_user_data()
            self.rating = user_data[user_data['ObjectID'] == int(recommended_artwork.moma_id)]['rating'].values[0]
            # print(self.rating)
            # print('*** ' + recommended_artwork.moma_id)
            # .query("ObjectID = 'recommended_artwork.moma_id'")['rating']
            
            self.record('risk_aware')
            self.record('risk_threshold')
            self.record('n_visitors')
            self.record('predicted_risk')
            self.record('score')
            self.record('predicted_room')
            self.record('rating')
            self.record('distance_to_cover')
            self.record('current_occupancy')
            
            return recommended_artwork.room, self.current_path[0], recommended_artwork.moma_id
        
        else:
            random_artwork = self.artworks.sample(n=1)
            goal_room = random_artwork['room'].iloc[0]            
            self.current_path = self.floorplan.findRoute(int(self.current_room), [int(goal_room)])

            # self.predicted_risk = self.model_user.recommender.getRiskInRoom(goal_room, occupancies, [random_artwork['ObjectID']]) 
            # self.predicted_room = goal_room
            # self.current_occupancy = occupancies
            # self.record('predicted_risk')
            # self.record('predicted_room')
            # self.record('current_occupancy')
            
            
            if self.is_monitored:
                self.update_durations()
                self.predicted_room = goal_room
                
                distance = 0
                for r in self.current_path:
                    # print('##### r -> ' + str(r) + ', recommended_artwork_room -> ' + str(recommended_artwork.room))
                    if not (r == goal_room):
                        distance += 1
                    else:
                        break
                
                # print('Room occupancy: ' + str(occupancies[int(goal_room) - 401]))
                # print('Room sojourn time: ' + str(self.durations[int(goal_room) - 401]))
                self.predicted_risk = self.risk_model.risk_in_percent(occupancies[int(goal_room) - 401], self.durations[int(goal_room) - 401])    
                
                for i in range(len(self.durations)):
                    if i != (int(goal_room) - 401):
                        self.durations[i] = 0
                
                self.current_occupancy = occupancies
                self.distance_to_cover = distance
                self.n_visitors = self.p.n_visitors
                self.risk_aware = self.p.risk_aware
                
                user_data = self.model_user.get_user_data()
                # pd.set_option('display.max_colwidth', None)
                # print(user_data)
                # print('*** Random arwork ***')
                # print(random_artwork)
                # print('*** user_data[ObjectID]')
                # print(user_data['ObjectID'])
                self.rating = user_data[user_data['ObjectID'] == int(random_artwork['ObjectID'].iloc[0])]['rating'].values[0]
                
                # print(self.rating)
                
                self.record('risk_aware')
                self.record('n_visitors')
                self.record('predicted_risk')
                self.record('predicted_room')
                self.record('rating')
                self.record('distance_to_cover')
                self.record('current_occupancy')
            
            return goal_room, self.current_path[0], random_artwork['ObjectID'].iloc[0]
            
        
    
    def move(self, occupancies = []):
        """
        Simulate visitor moving through the museum rooms.
        """
        # if self.current_room < len(self.p.museum_rooms):
        # time_in_room = self.time_in_room()
        # self.time_spent += time_in_room
        
        # print(f"Visitor {self.id} moved to {self.p.museum_rooms[self.current_room].name} "
        #       f"and spent {time_in_room} minutes there. Total time spent so far: {self.time_spent} minutes.")
        
        if self.is_monitored:
            if (self.state == self.WAITING_NEW_ARTWORK) or (self.state == self.START):
                self.goal_room, new_room, self.goal_artwork = self.next_room(occupancies) # Recommendation + path
                del(self.current_path[0])
                self.state = self.ON_WAY
            else:
                if self.state == self.ON_WAY:
                    new_room = self.current_path[0]
                    del(self.current_path[0])
                else:
                    new_room = self.current_room
            
                
            # Recording monitored visitor data
            # monitored_data = {
            #     'id': self.id,
            #     'profile': self.profile,
            #     'room': self.p.museum_rooms[self.current_room].name,
            #     'time_spent': time_in_room
            # }
            # # Record monitored visitor data into the simulation
            # self.model.monitored_visitors_data.append(monitored_data)
            # print(f"Visitor {self.id} data recorded: {monitored_data}")
            
        else:
            if (self.state == self.WAITING_NEW_ARTWORK) or (self.state == self.START):
                #self.goal_room = self.next_room(random.choice((list)self.floorplan.floorplan.neighbors(self.current_room)))
                
                # self.current_path = self.floorplan.findRoute(self.current_room, [self.goal_room])
                
                self.goal_room, new_room, self.goal_artwork = self.next_room()
                
                if len(self.current_path) > 0:
                    new_room = self.current_path[0]
                    del(self.current_path[0])
                    
                self.state = self.ON_WAY
            else:
                if self.state == self.ON_WAY:
                    new_room = self.current_path[0]
                    del(self.current_path[0])
                
                else:
                    new_room = self.current_room
            
        # print('*** Visitor ' + str(self.id) + ' moves from ' + str(self.current_room) + ' to ' + str(new_room))    
        self.current_room = new_room
            
    
            
            
            
            
            