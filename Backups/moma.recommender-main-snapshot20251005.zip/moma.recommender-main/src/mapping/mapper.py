import networkx as nx
import pickle
from src.entitites.artwork import Artwork
import os

class Mapper:
    # reads graphml Knowledge Graph
    #   - converts node labels to integer
    # considers only artwork embeddings
    # provides mapping functions
    #    - between momaID and nodeID
    #    - between embedding and nodeID
    #    - between nodeID and node data

    def __init__(self):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.abspath(os.path.join(script_dir, "../../"))
        # graph
        file_path = os.path.join(project_root, "graph/momaGraph.graphml")
        graph_original = nx.read_graphml(file_path)

        self.graph = nx.convert_node_labels_to_integers(graph_original)  # required for calculating embeddings

        # embeddings
        file_path = os.path.join(project_root, "embeddings/embeddings.pkl")
        embeddingFile = open(file_path, 'rb')
        self.node_embeddings = pickle.load(embeddingFile)
        self.artwork_embeddings = {}
        self.artworks = []

        self.getEmbeddingsAndArtworks()
        self.id_mapper = self.createIdMappings()

    def getEmbeddingsAndArtworks(self):
        #artwork_embeddings = {}
        for node in self.graph.nodes():
            try:
                if 'type' in self.graph.nodes[node].keys():
                    if self.graph.nodes[node]['type'] == 'artwork':
                        # store embedding in dictionary with nodeId as key
                        self. artwork_embeddings[node] = self.node_embeddings[node]
                        self.registerArtwork(node)
            except:
                pass

    def registerArtwork(self, artwork_node):
        momaId = self.graph.nodes[artwork_node]['ObjectID']
        node_Id = artwork_node
        title = self.graph.nodes[artwork_node]['title']
        artist_ID = self.graph.nodes[artwork_node]['artistID']
        artist = self.graph.nodes[artwork_node]['artist']
        year = artist_ID = self.graph.nodes[artwork_node]['date']
        style = self.graph.nodes[artwork_node]['style']
        genre = self.graph.nodes[artwork_node]['genre']
        room = int(self.graph.nodes[artwork_node]['room'])
        artwork = Artwork(momaId, node_Id, title, artist_ID, artist, year, style, genre, room)
        self.artworks.append(artwork)


    # creates a dictionary with moma_id as key and graph node_id as value
    def createIdMappings(self):
        map = {}
        for node in self.graph.nodes():
            if 'type' in self.graph.nodes[node].keys():
                if self.graph.nodes[node]['type'] == 'artwork':
                    moma_id = int(self.graph.nodes[node]['ObjectID'])
                    map[moma_id] = node
        dict(sorted(map.items(), key = lambda item: item[0]))
        return map


    ############################
    # mapping embeddings <-> data
    def getNodeIDofEmbedding(self, query_embedding):
        for node in self.graph.nodes():
            embedding = self.node_embeddings[node]
            if (embedding == query_embedding).all():
                return node

    def getEmbeddingOfNodeID(self, nodeID):
        try:
            embedding = self.artwork_embeddings[nodeID]
        except:
            print('error - no embedding exists for node_id', nodeID)
            return None
        return embedding

    def getMomaID_4_nodeID(self, nodeID):
        return int(self.graph.nodes[nodeID]['ObjectID'])

    def getNodeID_4_momaID(self, objectId):
        objectId = int(objectId)
        try:
            node_id = self.id_mapper[objectId]
        except:
            print('error for moma_id', objectId)
            node_id = 0   # existing artwork
        return node_id


    #returns a dictionary with the node data
    def getDataForNodeID(self, node_id):
        return self.graph.nodes[node_id]

    def getArtwork4NodeID(self, node_id):
        for a in self.artworks:
            if a.node_id == node_id:
                return a
        return None

    # returns a dictionary with the node data
    def getDataForMomaID(self, moma_id):
        node_id = self.getNodeID_4_momaID(moma_id)
        return self.graph.nodes[node_id]

    def getArtwork4MoMaID(self, moma_id):
        for a in self.artworks:
            if a.moma_id == moma_id:
                return a
        return None

if __name__ == '__main__':
    mapper = Mapper()

    '''
    print('Graph Data:')
    print('--- total number of graph nodes:', mapper.graph.number_of_nodes())
    print('--- total number of graph edges:', mapper.graph.number_of_edges())
    print('--- number of artwork embeddings:', len(mapper.artwork_embeddings))
    print('--- number of mappings:', len(mapper.id_mapper))
    print('--- number of artworks:', len(mapper.artworks))
    print()
    '''

    '''
    # test mapping
    myEmbedding = mapper.getEmbeddingOfNodeID(812)
    #print('embedding:', myEmbedding)
    nodeId = mapper.getNodeIDofEmbedding(myEmbedding)
    print('nodeID:', nodeId)
    nodeData = mapper.getDataForNodeID(nodeId)
    print(nodeData)
    artist = mapper.getArtwork4NodeID(nodeId)
    print(artist)
    '''


    print('################### node data')
    objectID = 65985
    nodeId = mapper.getNodeID_4_momaID(objectID)
    print('objectID:', objectID ,'   nodeID', nodeId)
    nodeData = mapper.getDataForNodeID(nodeId)
    print(nodeData)
    '''
    '''

    print('###################')
    nodeID = 812
    objectID = mapper.getMomaID_4_nodeID(nodeID)
    print('objectID:', objectID, '   nodeID', nodeId, objectID)
    data = mapper.getDataForMomaID(objectID)
    print(data)
    '''

    print('################### artworks')
    for a in mapper.artworks:
        print(a)

    print(len(mapper.artworks))
    '''
