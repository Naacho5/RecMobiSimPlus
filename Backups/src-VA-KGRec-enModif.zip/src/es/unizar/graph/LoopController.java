package es.unizar.graph;

public class LoopController {
	boolean stop = false;
}
