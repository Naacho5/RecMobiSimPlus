package es.unizar.controller;

public interface AppListener {
	//public void onOpen();
	public void onClose();
}
